#ifndef MOCK_PLATFORM_H
#define MOCK_PLATFORM_H
#include <stdint.h>
#include <stdarg.h>
#include <stddef.h>
#define PSP_MODULE_INFO(a,b,c,d)
#define PSP_MODULE_KERNEL 0
#define PSP_O_CREAT 1
#define PSP_O_WRONLY 2
#define PSP_O_APPEND 4
typedef int SceUID;
typedef unsigned SceSize;
typedef unsigned SceUInt;
typedef struct {uintptr_t text_addr;unsigned text_size;} SceModule;
int pspSdkSetK1(int);
void prnt(void (*)(void *,int),void *,const char *,va_list);
int sceIoOpen(const char *,int,int);int sceIoWrite(int,const void *,unsigned);int sceIoClose(int);
int sceKernelWaitSema(int,int,SceUInt *);int sceKernelSignalSema(int,int);int sceKernelPollSema(int,int);
int sceKernelCpuSuspendIntr(void);void sceKernelCpuResumeIntr(int);
void sceKernelDcacheWritebackInvalidateRange(void *,unsigned);void sceKernelDcacheInvalidateRange(void *,unsigned);
SceModule *sceKernelFindModuleByName(const char *);
uintptr_t sctrlHENFindFunction(const char *,const char *,uint32_t);
uint32_t _lw(uintptr_t);
int sceKernelIsIntrContext(void);uint64_t sceKernelGetSystemTimeWide(void);int sceKernelDelayThread(unsigned);
int sceKernelGetModel(void);unsigned sceKernelDevkitVersion(void);
int sceKernelCreateSema(const char *,int,int,int,void *);int sceKernelDeleteSema(int);
int sceKernelCreateThread(const char *,int (*)(SceSize,void *),int,int,int,void *);
int sceKernelStartThread(int,int,void *);int sceKernelDeleteThread(int);
#endif
/* Additional FS surface for the stack adapter tests. */
#define PSP_O_RDONLY 8
#define PSP_O_TRUNC 16
int sceIoRead(int,void *,unsigned);int sceIoSync(const char *,int);int sceIoRename(const char *,const char *);int sceIoRemove(const char *);
#define PSP_O_EXCL 32
