#include <stdint.h>
uint64_t sceKernelGetSystemTimeWide(void);
int sceKernelCpuSuspendIntr(void);
void sceKernelCpuResumeIntr(int);
uintptr_t sctrlHENFindFunction(const char *,const char *,uint32_t);
