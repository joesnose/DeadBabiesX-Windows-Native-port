#ifndef EVENT_WAIT_TRACE_H
#define EVENT_WAIT_TRACE_H
#include <stdint.h>
#define EVENT_WAIT_GUARDS 10
static inline int event_wait_context(uint32_t base,uint32_t size,uint32_t hook,const uint32_t *w){
 if(!w||(base&3)||(hook&3)||size<0x74f0||base>0xffffffffu-size||(((base+0x7484)^hook)&0xf0000000u))return 0;
 const uint32_t expected[EVENT_WAIT_GUARDS]={0x27bdffd0,0xafb60028,0x0080b021,0xafb50024,0x00a0a821,0xafb40020,0x0100a021,0xafb3001c,0xafb20018,0x01209021};
 for(unsigned i=0;i<EVENT_WAIT_GUARDS;i++)if(w[i]!=expected[i])return 0;
 return 1;
}
typedef int (*EventWaitReceive)(const void *,unsigned,void *,unsigned,void *,int);
#endif
