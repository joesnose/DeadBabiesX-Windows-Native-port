# Native HID busy setup bound — original audit, 2026-11-10

v0.25 log proves selected0402 and state0 then disconnect3 for NES30 Pro,
without descriptor/init/report. User still freezes entering USB after logical
disconnect. The log does not prove which native wait blocks shutdown.

The inspected HIDSvc setup handler allocates its native context, polls backend
request1 for identity, restores GP, and compares negative result with802F0157.
That exact result waits20000us then repeats indefinitely. Other negative
results take native fallback/cleanup. The native management thread synchronously
executes this job and cannot finish handling shutdown while that loop persists.
This establishes an unbounded-wait exposure, not runtime causation for this unit.

v0.26 guards32 original words/pointers at the setup entry, busy comparison,
GP/argument sequence, delay call/loop, identity-unavailable descriptor request
and native cleanup entry. It redirects
the delay call to an original9-word thunk, and the setup dispatch to a tiny
counter-reset forwarder. 249 waits continue the exact original poll, the250th
branches to the original identity-unavailable fallback. Native identity fields
are zeroed and descriptor request2 proceeds; success can initialize generic
input without PnP identity, failure follows native context release/completion. Native
resource ownership and completion/error logic remain; there is no fake success
or forced native thread termination. Normal identity success never enters the
wait helper. Shared counters belong to the exclusive native setup worker.

The thunk saves/restores SP/RA, leaves saved registers and GP intact, receives
helper's continuation target and restores the loop's native channel argument.
Native GP is restored before the intercepted delay. Compiled new C functions
have no GP writes; dispatch tail-calls original with zero frame, pause frame8.
The extra thunk32 is gone before descriptor parsing resumes. Known pause path
budget with helper allowance824/3072bytes; this is not proof of every indirect
firmware frame. Tiny report callback budget remains separately checked.

Fifteen sanitizer programs pass including per-job original forwarding/budget,
all32 no-write guard mutations and emitted MIPS continuation/fallback register
checks. PSP cross-build/compiled checks pass. Logs defer setup serial/polls/
timeouts to the plugin worker. Hardware USB stability and NES30 input remain
unverified. Do not claim a confirmed fix or ask for repeated old USB freezes.

Original factual offset/ABI audit and own code only; no raw firmware,
disassembly, private user log, address or key is distributed.
