#ifndef ZEEMOTE_HOOKS_H
#define ZEEMOTE_HOOKS_H
#ifndef ZEE_HOOK_HOST_TEST
#include <psploadcore.h>
#endif
typedef void (*ZeeLogger)(const char *,...);
int zeemote_input_install_module(SceModule *module,ZeeLogger logger);
void zeemote_input_log_tick(ZeeLogger logger);
int zeemote_input_ready(void);
#endif
