/* Original Bluetooth USB transport helpers; MIT. */
#ifndef HCI_CORE_H
#define HCI_CORE_H
#include <stdint.h>
#include <stddef.h>
#define HCI_MAX_ACL 1028u
#define HCI_MAX_EVENT 257u
#define HCI_ERR_ARGUMENT (-1001)
#define HCI_ERR_DISCONNECTED (-1002)
#define HCI_ERR_TIMEOUT (-1003)
#define HCI_ERR_PROTOCOL (-1004)
#define HCI_ERR_BUSY (-1005)
#define HCI_ERR_UNSUPPORTED (-1006)
typedef struct { uint8_t event_in,acl_in,acl_out,number; uint16_t event_mps,acl_in_mps,acl_out_mps; } HciEndpoints;
int hci_match_interface(const uint8_t *d,size_t n);
int hci_add_endpoint(HciEndpoints *e,const uint8_t *d,size_t n);
int hci_endpoints_complete(const HciEndpoints *e);
int hci_valid_command(const uint8_t *p,size_t n);
int hci_valid_acl(const uint8_t *p,size_t n);
/* Deframer preserves trailing packets, with bounded memory and no allocation. */
typedef struct { size_t used; uint8_t data[HCI_MAX_ACL*2]; } HciStream;
int hci_stream_feed(HciStream *s,const void *p,size_t n);
/* 0: incomplete; positive: packet size; negative: malformed/capacity error.
 * Caller capacity error retains the packet. Malformed length resets stream. */
int hci_stream_take(HciStream *s,int acl,void *out,size_t cap);
#endif
