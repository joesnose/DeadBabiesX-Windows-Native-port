# Native report-drain stop cooperation, 2026-11-10

v0.29 log confirms the exact GameStick auxiliary suppression applied, but user
reports transitions still hang. VSH read counters stop while gamepad input
reports continue. No new GAME banner follows. This rules out suppression as
a sufficient solution, not every possible native lifecycle problem.

Native report worker waits eventmask30001 and exits if bit1 is set. Composite
dispatch calls read repeatedly after matching/handling packets, including
unmatched IDs, without returning to the worker until the backend read<=0.
The single unnumbered route returns after its handler. This provides a source
explanation for starvation under a continuously active composite producer;
the log does not prove the actual hang instruction.

v0.30 is based on v0.28 (no auxiliary suppression). A guarded JAL read call is
redirected to a small wrapper polling the same native eventbit1 using mode1
OR, without clear. If set, return0 so native drain unwinds; native outer loop
retains its flag and does normal stop/cleanup. Otherwise call the exact native
read once with unchanged context/buffer/capacity and return its result.
Poll errors do not create a shutdown. All15 context words validate caller,
loop, native event-address construction and outer stop check before writes.
No artificial timeout, native setup-wait patch or new radio command.

Original stop request and resource ownership are authoritative. There is no
fake input/connection status or forced thread termination. Deferred counters
contain counts only, no raw data; log flush is not guaranteed during reboot.
Sixteen sanitizer programs cover continuous-producer stop, normal/errors,
noncleared flags/unmodified packet and all guard mutations. PSP compiled drain
frame32; native read/decode paths are sequential. Checked allowance544 of1024
for read path, decoder check separately. Indirect native stack use is not
completely proven. Physical transition/USB fix remains unverified.

Own factual notes/code only; no native firmware/disassembly or private data.
