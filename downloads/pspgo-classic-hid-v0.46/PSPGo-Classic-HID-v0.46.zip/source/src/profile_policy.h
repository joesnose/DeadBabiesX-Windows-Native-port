#ifndef NATIVE_PROFILE_POLICY_H
#define NATIVE_PROFILE_POLICY_H
#include <stdint.h>
#include <string.h>
/* Preserve legacy0602 selection while retaining the generic route for
 * mixed-profile0622 records after native flags accumulate0200. */
static inline int native_saved_hid_mode(unsigned flags){
 return flags==0x0402u||flags==0x0422u||flags==0x0622u;
}
typedef struct {
 int queried,query_result,valid;
 unsigned id,flags;
 int requested_mode,selected_mode;
} NativeProfileDecision;
typedef int (*NativeProfileQuery)(int,void *);
typedef int (*NativeProfileConnect)(int,int);
/* Query the current native record for this request. Never use UI/cache data.
 * A failed/empty/mismatched query preserves the caller's exact mode. */
static inline int native_profile_connect(int slot,int mode,NativeProfileQuery query,
 NativeProfileConnect connect,NativeProfileDecision *decision){
 NativeProfileDecision d={0,0,0,0,0,mode,mode};
 if(mode==0 && slot>=1 && slot<=8 && query){
  uint8_t record[80] __attribute__((aligned(16)))={0};record[0]=0x50;
  d.queried=1;d.query_result=query(slot,record);
  if(d.query_result>=0 && record[0]==0x50 && !record[1] && !record[2] && !record[3]){
   d.id=(unsigned)record[4]|((unsigned)record[5]<<8);
   d.flags=(unsigned)record[72]|((unsigned)record[73]<<8);
   d.valid=d.id==(unsigned)slot;
   if(d.valid && native_saved_hid_mode(d.flags))d.selected_mode=1;
  }
  /* Native records may contain names/addresses. Retain only numeric policy fields. */
  memset(record,0,sizeof(record));
 }
 if(decision)*decision=d;
 return connect(slot,d.selected_mode);
}
#endif
