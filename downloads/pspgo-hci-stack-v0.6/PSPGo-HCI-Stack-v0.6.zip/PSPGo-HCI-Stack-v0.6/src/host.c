/* Original PSP adapter for upstream BTstack. MIT for this file. */
#ifdef HCI_STACK_HOST_TEST
#include "mock_platform.h"
#else
#include <pspkernel.h>
#include <pspsdk.h>
#endif
#include <string.h>
#include "hci.h"
#include "hci_transport.h"
#include "gap.h"
#include "l2cap.h"
#include "btstack_memory.h"
#include "btstack_run_loop.h"
#include "btstack_event.h"
#include "btstack_util.h"
#include "classic/hid_host.h"
#include "classic/btstack_link_key_db.h"
#include "btstack_run_loop_embedded.h"
#include "pspgo_hci.h"
#include "host.h"
#include "input.h"
#define KEY_PATH "ef0:/seplugins/pspgo_ds4_bond.bin"
static void (*receive_packet)(uint8_t,uint8_t *,uint16_t);
static uint8_t rx[HCI_MAX_ACL+16] __attribute__((aligned(64)));
static uint8_t descriptors[2048];
static btstack_packet_callback_registration_t callback;
static bd_addr_t peer;
static int peer_valid,connected,stopped;
static uint16_t hid_cid;
static unsigned pairing_deadline;
static int pairing_open;
/* One explicit, versioned record; no compiler structure padding or key logging.
 * Local address binds a bond to the radio that created it. */
static uint8_t bond[42],local[6];
static int bond_valid;
static uint32_t crc(const uint8_t *p,unsigned n){uint32_t c=~0u;for(unsigned i=0;i<n;i++){c^=p[i];for(unsigned j=0;j<8;j++)c=(c>>1)^((0u-(c&1))&0xedb88320u);}return ~c;}
static void db_open(void){
 int k1=pspSdkSetK1(0);SceUID fd=sceIoOpen(KEY_PATH,PSP_O_RDONLY,0);bond_valid=0;
 if(fd>=0){int n=sceIoRead(fd,bond,sizeof(bond));uint8_t extra;int tail=sceIoRead(fd,&extra,1);sceIoClose(fd);
  if(n==42&&tail==0&&!memcmp(bond,"D4B1",4)&&little_endian_read_32(bond,38)==crc(bond,38))bond_valid=1;
 }pspSdkSetK1(k1);
}
static void db_local(bd_addr_t addr){memcpy(local,addr,6);if(bond_valid&&memcmp(bond+4,local,6))bond_valid=0;}
static void db_close(void){}
static int db_get(bd_addr_t addr,link_key_t key,link_key_type_t *type){if(!bond_valid||memcmp(bond+10,addr,6))return 0;memcpy(key,bond+16,16);*type=(link_key_type_t)bond[32];return 1;}
static void db_put(bd_addr_t addr,link_key_t key,link_key_type_t type){
 if(!peer_valid||memcmp(peer,addr,6))return;
 memset(bond,0,sizeof(bond));memcpy(bond,"D4B1",4);memcpy(bond+4,local,6);memcpy(bond+10,addr,6);memcpy(bond+16,key,16);bond[32]=(uint8_t)type;little_endian_store_32(bond,38,crc(bond,38));bond_valid=1;
 int k1=pspSdkSetK1(0);SceUID fd=sceIoOpen(KEY_PATH ".new",PSP_O_WRONLY|PSP_O_CREAT|PSP_O_TRUNC,0600);int ok=0;
 if(fd>=0){ok=sceIoWrite(fd,bond,sizeof(bond))==(int)sizeof(bond);if(sceIoClose(fd)<0)ok=0;}
 if(ok){sceIoSync("ef0:",0);if(sceIoRename(KEY_PATH ".new",KEY_PATH)<0)ok=0;}
 pspSdkSetK1(k1);hci_log(ok?"BOND: saved (key redacted)\n":"BOND: persistence failed; current session only\n");
}
static void db_delete(bd_addr_t addr){if(!bond_valid||memcmp(bond+10,addr,6))return;bond_valid=0;memset(bond,0,sizeof(bond));int k1=pspSdkSetK1(0);sceIoRemove(KEY_PATH);pspSdkSetK1(k1);}
static int db_iter_init(btstack_link_key_iterator_t *it){it->context=NULL;return 1;}
static int db_iter_next(btstack_link_key_iterator_t *it,bd_addr_t addr,link_key_t key,link_key_type_t *type){if(it->context||!bond_valid)return 0;it->context=(void *)1;memcpy(addr,bond+10,6);memcpy(key,bond+16,16);*type=(link_key_type_t)bond[32];return 1;}
static void db_iter_done(btstack_link_key_iterator_t *it){(void)it;}
static const btstack_link_key_db_t key_db={db_open,db_local,db_close,db_get,db_put,db_delete,db_iter_init,db_iter_next,db_iter_done};
/* Single PSP worker owns the embedded run loop. Its wake-ups are polling-only;
 * no interrupt handler accesses run-loop data, so HAL IRQ hooks are no-ops. */
uint32_t hal_time_ms(void){return (uint32_t)(sceKernelGetSystemTimeWide()/1000);}
void hal_cpu_disable_irqs(void){}
void hal_cpu_enable_irqs(void){}
void hal_cpu_enable_irqs_and_sleep(void){sceKernelDelayThread(1000);}
static void transport_init(const void *config){(void)config;}
static int transport_open(void){return pspgoHciGetState()==1?0:-1;}
static int transport_close(void){pspgo_input_clear();return 0;}
static void transport_handler(void (*handler)(uint8_t,uint8_t *,uint16_t)){receive_packet=handler;}
static int transport_send(uint8_t type,uint8_t *packet,int n){
 int r=type==HCI_COMMAND_DATA_PACKET?pspgoHciSendCommand(packet,(unsigned)n,1000):type==HCI_ACL_DATA_PACKET?pspgoHciSendAcl(packet,(unsigned)n,1000):HCI_ERR_UNSUPPORTED;
 if(r!=n){stopped=1;pspgo_input_clear();hci_log("HOST STOP: transmit type=%u result=%d expected=%d\n",type,r,n);return -1;}return 0;
}
/* NULL can_send_packet_now marks a synchronous transport to BTstack. */
static const hci_transport_t transport={"PSP native USB HCI",transport_init,transport_open,transport_close,transport_handler,NULL,transport_send,NULL,NULL,NULL};
static int same_peer(const bd_addr_t addr){return peer_valid&&!memcmp(addr,peer,6);}
static int pair_window(void){return pairing_open&&!bond_valid&&(int32_t)(pairing_deadline-hal_time_ms())>0;}
static void connect_peer(void){
 uint8_t status=hid_host_connect(peer,HID_PROTOCOL_MODE_REPORT,&hid_cid);
 hci_log("HID: outgoing request status=%u\n",status);
}
static void event_handler(uint8_t type,uint16_t channel,uint8_t *p,uint16_t size){
 (void)channel;if(type!=HCI_EVENT_PACKET||size<2||size<(unsigned)p[1]+2)return;
 bd_addr_t addr;uint8_t event=p[0];
 switch(event){
 case BTSTACK_EVENT_STATE:
  if(size<3)break;
  if(btstack_event_state_get_state(p)==HCI_STATE_WORKING){
   hci_log("HOST: HCI working; L2CAP/SDP/HID initialized\n");
   if(bond_valid){memcpy(peer,bond+10,6);peer_valid=1;connect_peer();}
   else {pairing_open=1;pairing_deadline=hal_time_ms()+60000;gap_inquiry_start(8);hci_log("PAIR: 60-second window; DS4 SHARE+PS\n");}
  }break;
 case GAP_EVENT_INQUIRY_RESULT:
  if(peer_valid||!pair_window())break;
  /* EIR PnP identity is required, rather than trusting a generic device name. */
  if(size<27||!gap_event_inquiry_result_get_device_id_available(p)||gap_event_inquiry_result_get_device_id_vendor_id_source(p)!=2||gap_event_inquiry_result_get_device_id_vendor_id(p)!=0x054c)break;
  {unsigned product=gap_event_inquiry_result_get_device_id_product_id(p);if(product!=0x05c4&&product!=0x09cc)break;}
  gap_event_inquiry_result_get_bd_addr(p,peer);peer_valid=1;gap_inquiry_stop();connect_peer();break;
 case GAP_EVENT_INQUIRY_COMPLETE:
  if(!peer_valid&&pair_window())gap_inquiry_start(8);break;
 case HCI_EVENT_PIN_CODE_REQUEST:
  if(size<8)break;
  hci_event_pin_code_request_get_bd_addr(p,addr);gap_pin_code_negative(addr);hci_log("PAIR: legacy PIN rejected; SSP required\n");break;
 case HCI_EVENT_USER_CONFIRMATION_REQUEST:
  if(size<12)break;
  hci_event_user_confirmation_request_get_bd_addr(p,addr);
  if(same_peer(addr)&&(pair_window()||bond_valid))gap_ssp_confirmation_response(addr);else gap_ssp_confirmation_negative(addr);break;
 case HCI_EVENT_HID_META:
  if(size<3)break;
  switch(p[2]){
  case HID_SUBEVENT_INCOMING_CONNECTION:
   if(size<14)break;
   hid_subevent_incoming_connection_get_address(p,addr);
   if(same_peer(addr)&&hid_subevent_incoming_connection_get_status(p)==0)hid_host_accept_connection(hid_subevent_incoming_connection_get_hid_cid(p),HID_PROTOCOL_MODE_REPORT);
   else hid_host_decline_connection(hid_subevent_incoming_connection_get_hid_cid(p));break;
  case HID_SUBEVENT_CONNECTION_OPENED:
   if(size<14)break;
   if(hid_subevent_connection_opened_get_status(p)){pspgo_input_clear();hci_log("HID: connection failed status=%u\n",hid_subevent_connection_opened_get_status(p));break;}
   hid_subevent_connection_opened_get_bd_addr(p,addr);if(!same_peer(addr)){hid_host_disconnect(hid_subevent_connection_opened_get_hid_cid(p));break;}
   connected=1;hid_cid=hid_subevent_connection_opened_get_hid_cid(p);hci_log("HID: control and interrupt channels open\n");
   break;
  case HID_SUBEVENT_DESCRIPTOR_AVAILABLE:
   if(size<6)break;
   if(connected&&hid_subevent_descriptor_available_get_status(p)==0){
    /* Feature 0x02 requests DS4 full Bluetooth reports. */
    hci_log("HID: descriptor available; feature request status=%u\n",hid_host_send_get_report(hid_cid,HID_REPORT_TYPE_FEATURE,2));
   }break;
  case HID_SUBEVENT_REPORT:
   if(size<7)break;
   if(connected){const uint8_t *report=hid_subevent_report_get_report(p);unsigned n=hid_subevent_report_get_report_len(p);Ds4State state;
    if(report>=p&&report<=p+size&&n<=(unsigned)(p+size-report)&&n>1&&report[0]==0xa1&&ds4_decode_bt(report+1,n-1,&state)==0){
     if(pspgo_input_install()==0)pspgo_input_update(&state);
    }
   }break;
  case HID_SUBEVENT_CONNECTION_CLOSED:connected=0;hid_cid=0;pspgo_input_clear();hci_log("HID: disconnected; input neutral\n");break;
  default:break;
  }break;
 default:break;
 }
}
void pspgo_radio_preflight(void);
void pspgo_host_run(void){
 pspgo_radio_preflight();
 hci_log("HOST WAIT: no radio configuration changes; waiting for actual HCI attachment\n");
 while(pspgoHciGetState()!=1)sceKernelDelayThread(1000000);
 btstack_memory_init();btstack_run_loop_init(btstack_run_loop_embedded_get_instance());hci_init(&transport,NULL);
 hci_set_link_key_db(&key_db);l2cap_init();hid_host_init(descriptors,sizeof(descriptors));hid_host_register_packet_handler(event_handler);
 callback.callback=event_handler;hci_add_event_handler(&callback);
 gap_ssp_set_io_capability(SSP_IO_CAPABILITY_NO_INPUT_NO_OUTPUT);gap_ssp_set_auto_accept(0);gap_ssp_set_authentication_requirement(SSP_IO_AUTHREQ_MITM_PROTECTION_NOT_REQUIRED_GENERAL_BONDING);gap_set_bondable_mode(1);gap_set_security_level(LEVEL_2);gap_set_minimal_service_security_level(LEVEL_2);
 gap_set_local_name("PSP Go DS4 Host");gap_discoverable_control(0);gap_connectable_control(1);
 hci_log("HOST START: HCI attached; starting BTstack\n");hci_power_control(HCI_POWER_ON);
 while(!stopped&&pspgoHciGetState()==1){
  int r=pspgoHciReadEvent(rx+4,HCI_MAX_EVENT,1);
  if(r>0)receive_packet(HCI_EVENT_PACKET,rx+4,(uint16_t)r);else if(r!=HCI_ERR_TIMEOUT){hci_log("HOST STOP: event read %d\n",r);break;}
  r=pspgoHciReadAcl(rx+4,HCI_MAX_ACL,1);
  if(r>0)receive_packet(HCI_ACL_DATA_PACKET,rx+4,(uint16_t)r);else if(r!=HCI_ERR_TIMEOUT){hci_log("HOST STOP: ACL read %d\n",r);break;}
  if(pairing_open&&(bond_valid||(int32_t)(pairing_deadline-hal_time_ms())<=0)){
   pairing_open=0;gap_set_bondable_mode(0);gap_inquiry_stop();hci_log("PAIR: discovery/pairing window closed\n");
  }
  btstack_run_loop_embedded_execute_once();
 }
 pspgo_input_clear();hci_log("HOST STOP: input neutral; full restart required\n");
}
