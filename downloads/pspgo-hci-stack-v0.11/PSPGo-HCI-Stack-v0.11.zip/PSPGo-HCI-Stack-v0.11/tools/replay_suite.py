#!/usr/bin/env python3
"""Offline audit of v0.9 diagnostic text; never opens a device or modifies logs.

Checks captured response headers, not unlogged bytes or physical write effects.
Usage: python tools/replay_suite.py /path/to/pspgo_hci_transport.log
"""
import json
from pathlib import Path
import re
import sys

def audit(text):
    pending = None
    results = []
    for line in text.splitlines():
        m = re.search(r'SUITE key=([0-9a-f]{4}) op=([45]) SET .* words=(\d+) seq=(\d+) begin', line)
        if m:
            pending = dict(key=int(m[1], 16), words=int(m[3]), sequence=int(m[4]))
        elif pending is not None:
            m = re.search(r'SUITE native=([0-9a-f]{8}) outer=([0-9a-f]{4})', line)
            if m:
                pending['native'] = int(m[1], 16)
                pending['outer'] = int(m[2], 16)
            m = re.search(r'SUITE ACK buffer\[0\.\.4\]=((?:[0-9a-f]{4} ?){5})', line)
            if m:
                p = [int(x, 16) for x in m[1].split()]
                pending['header_success'] = (pending.get('native') == 1 and
                    pending.get('outer') == 0 and p == [1, pending['words'], pending['sequence'], 0x7003, 0])
            m = re.search(r'SUITE ACK buffer\[5\.\.8\]=((?:[0-9a-f]{4} ?){4})', line)
            if m:
                p = [int(x, 16) for x in m[1].split()]
                pending['printed_fields_match'] = p == [pending['key'], 1, 8, 1]
                results.append(pending)
                pending = None
    if pending is not None:
        raise ValueError('incomplete SET capture')
    return {'captured_sets': len(results),
            'matching_success_headers': sum(r.get('header_success', False) for r in results),
            'matching_printed_fields': sum(r['printed_fields_match'] for r in results),
            'full_response_extent_verified': False,
            'effective_write_proven': False}

if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    print(json.dumps(audit(Path(sys.argv[1]).read_text()), indent=2))
