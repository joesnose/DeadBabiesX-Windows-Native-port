# CSR PS-store semantics audit

Date: 2026-11-09. Independent offline analysis; no hardware commands executed.

## Confirmed selector facts

BlueZ's original [bccmd.c](https://github.com/bluez/bluez/blob/5.50/tools/bccmd.c)
defines PSRAM as 0x0008, maps selectors 1/2/4/8 to psi/psf/psrom/psram, and
defaults `psset` to PSRAM while defaulting `psget` to selector zero. Its
`cmd_memtypes` passes a store selector to varid 0x3012, then reads a separate
memory-type result. Its `memorytostr` interprets type 2 as transient RAM.

Therefore the earlier identification of store 8 and memory-type 2 was correct.
Do not replace write selector 8 with zero as a supposed RAM correction.

CSR's manufacturer document, *BCCMD Commands*, bcore-sp-005Pe, sections 10.3
and 10.15, agrees. Section 10.3's tables distinguish read and write defaults:

| Operation | Selector | Meaning |
| --- | --- | --- |
| GET | 8 | PSRAM only |
| GET | 0 | Search PSRAM, PSI, PSF, PSROM in precedence order |
| SET | 8 | Write PSRAM |
| SET | 0 | Select PSI when writable, otherwise PSRAM |

The document was examined as indexed manufacturer text at the
[manual mirror](https://manualzz.com/doc/24213785/csr-bluecore-electronics-bccmd-commands-user-manual).
The read default is thus not interchangeable with a guaranteed volatile write.

## Same-value writes and reboot behavior

I found no authoritative statement that a PSRAM write equal to a lower-layer
value is automatically elided or deleted. Neither the examined BlueZ client
nor the examined manufacturer description establishes such a rule. That
explanation remains speculation, not a reason to reclassify the failed readback
as successful storage.

The manufacturer describes PSRAM surviving its warm-reset mechanism and
disappearing after other resets, including power loss and cold reset. It also
describes initialization-time configuration requiring a write followed by warm
reboot. Thus a full power cycle is a recovery concept, not an activation method
for a volatile override that needs to survive initialization. This is a family
behavior, not a validated PSP Go mode-switch procedure.

An unchanged default value after writing that same value cannot reveal whether
a layer acquired an entry. A later cold startup also cannot establish whether
the prior volatile write worked: either result may have been lost on reset.

## Sony request 0x70: what was actually established

The examined private BSMan BD_ADDR reader sends native message 0x70 with a
50-byte payload containing BCCMD GETREQ, varid 0x7003, PS key 1, length 4,
and default store. Its generic dispatcher copies the request ID, length, and
payload into a transmit packet and submits it to BSMCDC. Those functions do
not establish a Sony-specific PS-store selector translation.

No radio-side VM executable or equivalent mapping implementation was available
for this audit. Consequently request 0x70's radio-side handling cannot be
claimed to preserve or rewrite every PS operation merely from those host
functions. The existing protocol-consistent SET success headers are useful
evidence of an acknowledged operation, but immediate store-8 outer 0x0050 is
still unresolved. The 0x0050 outer status must not be assigned a standard
inner-BCCMD error meaning without evidence.

## Practical conclusion

The suite did not use the wrong RAM selector. The confirmed parser defect is
the expected response type, covered in PROTOCOL-AUDIT.md. Security, bootmode
mapping, Sony-specific radio handling, and same-value optimization are separate
hypotheses; none is proven to explain all observations. A useful next read-only
implementation would distinguish key presence/size via documented PS_Size or
PS_Next from value retrieval, with bounded calls and no inference that outer
errors mean absence. It should also record security/bootmode information when
readable. This report does not authorize or perform such device calls.
