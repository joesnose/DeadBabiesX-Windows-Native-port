#ifndef DRAIN_STOP_PLAN_H
#define DRAIN_STOP_PLAN_H
#include <stdint.h>
#include <string.h>
#define DRAIN_STOP_WORDS 15
static const unsigned drain_stop_offsets[DRAIN_STOP_WORDS]={0xe2c,0xe6c,0xe70,0xe74,0xe78,0xe7c,0xee4,0xee8,0x688,0x6a8,0x6ac,0x6bc,0x6d4,0x6d8,0xf58};
static inline void drain_stop_expected(uint32_t b,uint32_t w[DRAIN_STOP_WORDS]){
 uint32_t ef=b+0x4ed0;
 const uint32_t v[DRAIN_STOP_WORDS]={0x27bdffb0,0x03a02821,
  0x0c000000u|(((b+0xf58)>>2)&0x3ffffff),0x24060040,0x18400025,0x8fbf0048,
  0x08000000u|(((b+0xe6c)>>2)&0x3ffffff),0x02002021,
  0x3c020000u|((ef+0x8000u)>>16),0x24500000u|(ef&0xffff),0x8e04000c,0x34450001,
  0x30c70001,0x14e0001d,0x27bdffe0};
 memcpy(w,v,sizeof(v));
}
static inline int drain_stop_plan(uint32_t b,uint32_t size,uint32_t hook,const uint32_t c[DRAIN_STOP_WORDS],uint32_t *word){
 if(!c||!word||(b|hook)&3||size<0x4ec4||b>0xffffffffu-size||b>0xffffffffu-0x4ee0u||
    ((b+0xe74)&0xf0000000u)!=(hook&0xf0000000u))return -1;
 uint32_t expected[DRAIN_STOP_WORDS];drain_stop_expected(b,expected);
 if(memcmp(c,expected,sizeof(expected)))return -1;
 *word=0x0c000000u|((hook>>2)&0x3ffffff);return 0;
}
#endif
