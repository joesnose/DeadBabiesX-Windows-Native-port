#ifndef HID_SETUP_PLAN_H
#define HID_SETUP_PLAN_H
#include <stdint.h>
#include <string.h>
#define HID_SETUP_GUARDS 32
#define HID_SETUP_WORDS 9
static const unsigned hid_setup_offsets[HID_SETUP_GUARDS]={
 0x76c,0x7a8,0x7b4,0x874,0x878,0x87c,0x880,0x884,0x888,0x88c,0x890,
 0xa04,0xa08,0xa0c,0xa10,0x4e38,0x7c8,0x7cc,0x7d0,0x7d4,0x7d8,0x7e8,0x7ec,0x858,0x894,0x898,0x8d4,0x8dc,0x8e0,0x8ec,0x8f0,0x8f4};
static inline int hid_setup_jump(uint32_t pc,uint32_t target,uint32_t *word){
 if((pc|target)&3||((pc+4)&0xf0000000u)!=(target&0xf0000000u))return -1;
 *word=0x08000000u|((target>>2)&0x03ffffffu);return 0;
}
static inline void hid_setup_expected(uint32_t b,uint32_t w[HID_SETUP_GUARDS]){
 const uint32_t literal[HID_SETUP_GUARDS]={
  0x27bdfdb0,0x3c0e802f,0x35d30157,0x0040f809,0x00003021,0x03801821,
  0x0200e021,0x04410005,0x24044e20,0x1053005d,0,
  0,0,0,0x8e440000,0,0x8e440004,0x50800006,0xae400004,0,0x8c930158,0,0x02402021,0x03801021,0xa7a00222,0xa7a00220,0x24040002,0x00003021,0x0200f809,0x0260e021,0x1840ffb5,0x8fa60014};
 memcpy(w,literal,sizeof(literal));uint32_t j=0;
 hid_setup_jump(b+0xa04,b+0x4b68,&j);w[11]=j|0x04000000u;
 hid_setup_jump(b+0xa0c,b+0x858,&j);w[13]=j;w[15]=b+0x76c;
 hid_setup_jump(b+0x7d4,b+0x414,&j);w[19]=j|0x04000000u;
 hid_setup_jump(b+0x7e8,b+0x31c,&j);w[21]=j|0x04000000u;
}
typedef struct {uint32_t call,code[HID_SETUP_WORDS];} HidSetupPlan;
/* Busy wait runs on native management thread, not tiny report thread. Native
 * cleanup is retained; no synthetic success or forced thread termination. */
static inline int hid_setup_plan(uint32_t b,uint32_t size,uint32_t thunk,uint32_t helper,
 const uint32_t guard[HID_SETUP_GUARDS],HidSetupPlan *out){
 if(!out||!guard||size<0x4e3c||b>0xffffffffu-size||(b&3))return -1;
 uint32_t expected[HID_SETUP_GUARDS],call,help;
 hid_setup_expected(b,expected);if(memcmp(guard,expected,sizeof(expected)))return -1;
 if(hid_setup_jump(b+0xa04,thunk,&call)||hid_setup_jump(thunk+8,helper,&help))return -1;
 HidSetupPlan p={.call=call|0x04000000u,.code={
  0x27bdffe0,0xafbf001c,help|0x04000000u,0,0x0040c821,0x8fbf001c,
  0x27bd0020,0x03200008,0x8e440000}};
 *out=p;return 0;
}
#endif
