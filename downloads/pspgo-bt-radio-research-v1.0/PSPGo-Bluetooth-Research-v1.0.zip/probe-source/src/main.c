/* PSP Go radio identification probe. MIT licensed. No firmware code included. */
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsysclib.h>
#include <pspsdk.h>
#include <systemctrl.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include "radio_query.h"
PSP_MODULE_INFO("PSPGoRadioResearch",PSP_MODULE_KERNEL,1,0);
#define LOG_PATH "ef0:/seplugins/pspgo_bt_radio.log"
typedef struct {unsigned count;char data[256];} LogBuffer;
static int resident;
static void format_char(void *context,int ch){
 LogBuffer *b=context;
 if(ch==0x200)b->count=0;
 else if(ch>=0&&ch<256&&b->count<sizeof(b->data))b->data[b->count++]=(char)ch;
}
static void log_line(const char *fmt,...){
 LogBuffer b={0,{0}};va_list args;int old=pspSdkSetK1(0);
 va_start(args,fmt);prnt(format_char,&b,fmt,args);va_end(args);
 SceUID fd=sceIoOpen(LOG_PATH,PSP_O_CREAT|PSP_O_WRONLY|PSP_O_APPEND,0666);
 if(fd>=0){if(b.count)sceIoWrite(fd,b.data,b.count);sceIoClose(fd);}pspSdkSetK1(old);
}
typedef struct {uint16_t id,length;const void *data;} Request;
typedef struct {uint16_t id,length,status,reserved;void *data;} Response;
_Static_assert(sizeof(Request)==8,"PSP request ABI");
_Static_assert(sizeof(Response)==12,"PSP response ABI");
static int (*ready)(void);
static int (*transaction)(const Request *,Response *);
static int find_interface(void){
 SceModule *mod=sceKernelFindModuleByName("sceBSMan");
 uint32_t status=sctrlHENFindFunction("sceBSMan","sceBSMan",0xed295515u);
 uint32_t transport=sctrlHENFindFunction("sceBSMan","sceBSMan",0xe1704deeu);
 if(!mod||!status||!transport)return 0;
 uint32_t base=mod->text_addr;
 if(mod->text_size<0x5ebc || status!=base+0x5ea4 || transport!=base+0x385c)return -1;
 uint32_t state_code[6],prologue[4];
 for(unsigned i=0;i<6;i++)state_code[i]=_lw(status+i*4);
 for(unsigned i=0;i<4;i++)prologue[i]=_lw(transport+i*4);
 if(!radio_ready_guard(base,state_code)||
    !radio_transport_guard(base,prologue,_lw(base+0x3940),_lw(base+0x3944)))return -1;
 ready=(void *)(uintptr_t)status;transaction=(void *)(uintptr_t)transport;return 1;
}
static int worker(SceSize args,void *argp){
 (void)args;(void)argp;
 log_line("WAIT: enable Bluetooth in XMB; no controller needed (180 second window)\n");
 int found=0;
 for(unsigned i=0;i<180;i++){
  found=find_interface();
  if(found<0){log_line("STOP: native interface guard mismatch; no query sent\n");return 0;}
  if(found>0 && ready()==1)break;
  if(i==179){log_line("STOP: Bluetooth not ready within window; no query sent\n");return 0;}
  sceKernelDelayThread(1000000);
 }
 log_line("INTERFACE guarded; sending allowlisted metadata GETs once\n");
 for(unsigned i=0;i<RADIO_QUERY_COUNT;i++){
  const RadioQuery *q=&radio_queries[i];uint16_t sequence=(uint16_t)(i+1);
  uint16_t tx[25] __attribute__((aligned(4)));
  uint16_t rx[25] __attribute__((aligned(4)));
  if(radio_query_make(q->varid,q->key,sequence,tx)){log_line("STOP: query builder rejected allowlist\n");return 0;}
  memset(rx,0xa5,sizeof(rx));Request request={0x70,50,tx};Response response={0x170,50,0xffff,0,rx};
  log_line("QUERY %s begin varid=%04x key=%04x\n",q->name,q->varid,q->key);
  int old=pspSdkSetK1(0);int result=transaction(&request,&response);pspSdkSetK1(old);
  if(result<0 || response.status){
   log_line("QUERY %s native=%08x outer_status=%04x\n",q->name,(unsigned)result,response.status);
   log_line("STOP: outer transport rejected; no further queries\n");return 0;
  }
  unsigned status=0,value=0;int parsed=radio_query_parse(rx,sizeof(rx),q->varid,q->key,sequence,&status,&value);
  if(parsed<0){log_line("QUERY %s malformed/mismatched BCCMD response; stopping\n",q->name);return 0;}
  if(parsed)log_line("QUERY %s BCCMD_status=%04x (no value interpreted)\n",q->name,status);
  else log_line("QUERY %s value=%04x (%u)\n",q->name,value,value);
  sceKernelDelayThread(100000);
 }
 log_line("DONE: metadata reads finished; no configuration writes or connection attempts made\n");return 0;
}
int module_start(SceSize args,void *argp){
 (void)args;(void)argp;int model=sceKernelGetModel();unsigned fw=sceKernelDevkitVersion();
 log_line("\nPSP Go radio research 1.0 model=%d devkit=%08x\n",model,fw);
 if(model!=4||(fw!=0x06060010&&fw!=0x06060110)){log_line("STOP: unsupported model/firmware\n");return -1;}
 SceUID id=sceKernelCreateThread("RadioMetadataReader",worker,0x30,8192,0,NULL);
 if(id<0){log_line("STOP: thread creation %08x\n",(unsigned)id);return -1;}
 resident=1;int result=sceKernelStartThread(id,0,NULL);
 if(result<0){resident=0;sceKernelDeleteThread(id);log_line("STOP: thread start %08x\n",(unsigned)result);return -1;}
 return 0;
}
int module_stop(SceSize args,void *argp){
 (void)args;(void)argp;
 /* Refuse unload until reboot: do not race a native transaction or epilogue. */
 return resident?-1:0;
}
