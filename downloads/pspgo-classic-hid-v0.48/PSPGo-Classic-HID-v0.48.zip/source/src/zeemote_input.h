#ifndef ZEEMOTE_INPUT_H
#define ZEEMOTE_INPUT_H
#include "zeemote_hid.h"
typedef struct {unsigned overlay_installed,installed,active,vsh_installed,vsh_reads,reads[4],merged_samples,install_error,guard_index,seen_buttons,motion_seen,last_buttons,lx,ly,min_lx,max_lx,min_ly,max_ly;} ZeeInputStats;
void zee_input_stats(ZeeInputStats *stats);
/* Heavy bounded installation: call only from the owned 8192-byte worker. */
int zee_input_install(void);
int zee_input_install_overlay(void);
void zee_input_update(const ZeeState *state);
void zee_input_clear(void);
/* Refreshes an existing state only; called by the trusted live-session monitor. */
void zee_input_keepalive(void);
#endif
