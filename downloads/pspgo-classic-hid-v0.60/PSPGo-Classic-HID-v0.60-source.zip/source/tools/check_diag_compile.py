#!/usr/bin/env python3
"""Single-file logger stack/retired-diagnostics check."""
import json,sys
from check_hid_stack import functions
f=functions(sys.argv[1])
assert 'boot_marker_tick' not in f and 'diagnostics_tick' not in f
assert f['log_line'][2]<=512 and f['logger_thread'][2]<=2048
print(json.dumps(dict(single_file_logger=True,log_line_frame=f['log_line'][2],logger_frame=f['logger_thread'][2],pass_check=True)))
