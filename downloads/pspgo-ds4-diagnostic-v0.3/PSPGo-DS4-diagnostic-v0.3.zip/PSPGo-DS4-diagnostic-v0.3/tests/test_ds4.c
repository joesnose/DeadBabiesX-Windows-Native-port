#include "ds4_report.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static uint8_t simple[10]={1,128,128,128,128,8,0,0,0,0};
static void neutral(const Ds4State *s){assert(!s->buttons&&s->lx==128&&s->ly==128&&s->rx==128&&s->ry==128&&!s->l2&&!s->r2&&!s->l3&&!s->r3&&!s->touch);}
int main(void){
    Ds4State s;unsigned checks=0;
    assert(ds4_decode_bt(simple,10,&s)==0);neutral(&s);++checks;
    const unsigned hats[]={0x10,0x30,0x20,0x60,0x40,0xc0,0x80,0x90,0};
    for(unsigned h=0;h<9;++h){simple[5]=h;assert(ds4_decode_bt(simple,10,&s)==0&&s.buttons==hats[h]);++checks;}
    const unsigned face[]={0x8000,0x4000,0x2000,0x1000};
    for(unsigned b=0;b<4;++b){simple[5]=8|(0x10<<b);assert(ds4_decode_bt(simple,10,&s)==0&&s.buttons==face[b]);++checks;}
    simple[5]=8;
    const unsigned other[]={0x100,0x200,0x100,0x200,1,8};
    for(unsigned b=0;b<6;++b){simple[6]=1<<b;assert(ds4_decode_bt(simple,10,&s)==0&&s.buttons==other[b]);++checks;}
    simple[6]=0xc0;simple[7]=3;simple[1]=0;simple[2]=255;simple[3]=63;simple[4]=191;simple[8]=255;simple[9]=127;
    assert(ds4_decode_bt(simple,10,&s)==0&&s.buttons==0x10000&&s.l3&&s.r3&&s.touch&&s.lx==0&&s.ly==255&&s.rx==63&&s.ry==191&&s.l2==255&&s.r2==127);++checks;
    uint8_t full[78]={0x11,0xc0,0};memcpy(full+3,simple+1,9);
    /* Fixture CRC independently calculated with Python binascii.crc32, seeded with HIDP 0xa1. */
    full[74]=0xde;full[75]=0xcf;full[76]=0xf4;full[77]=0xd0;
    assert(ds4_decode_bt(full,78,&s)==0&&s.lx==0&&s.ly==255&&s.l3&&s.touch);++checks;
    full[4]^=1;assert(ds4_decode_bt(full,78,&s)<0);neutral(&s);++checks;
    for(size_t n=0;n<78;++n){assert(ds4_decode_bt(full,n,&s)<0);neutral(&s);++checks;}
    full[0]=0x12;assert(ds4_decode_bt(full,78,&s)<0);neutral(&s);++checks;
    simple[5]=15;assert(ds4_decode_bt(simple,10,&s)<0);neutral(&s);++checks;
    assert(ds4_decode_bt(NULL,10,&s)<0);neutral(&s);++checks;
    assert(ds4_decode_bt(simple,10,NULL)<0);++checks;
    printf("PASS: %u DS4 protocol assertions/groups (synthetic reports; no hardware pairing test)\n",checks);
    return 0;
}
