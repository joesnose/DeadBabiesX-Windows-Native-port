#ifndef ZEEMOTE_INPUT_H
#define ZEEMOTE_INPUT_H
#include "zeemote_hid.h"
typedef struct {unsigned installed,active,reads[4],merged_samples;} ZeeInputStats;
void zee_input_stats(ZeeInputStats *stats);
int zee_input_install(void);
void zee_input_update(const ZeeState *state);
void zee_input_clear(void);
/* Refreshes an existing state only; called by the trusted live-session monitor. */
void zee_input_keepalive(void);
#endif
