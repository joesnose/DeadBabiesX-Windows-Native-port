/* Copyright 2026. MIT licensed. Native Linux hidraw; no external libraries. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <glob.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <linux/hidraw.h>
#include <linux/input.h>
#include "pair_report.h"
static void usage(const char *program){
 printf("PSP Go / DS4 USB pairing test (Linux v0.8-linux1)\n"
 "Usage: %s [--device /dev/hidrawN] [--host-file pspgo_ds4_host.txt] [--write]\n"
 "Default: read controller only. --write requires --host-file.\n"
 "--write changes the DS4's saved host and sets its pairing key to zero.\n"
 "It does not provision a key on the PSP or prove Bluetooth connection.\n",program);
}
static int supported(int fd){
 struct stat st;struct hidraw_devinfo info;
 return fstat(fd,&st)==0 && S_ISCHR(st.st_mode) && ioctl(fd,HIDIOCGRAWINFO,&info)==0 &&
  info.bustype==BUS_USB && (uint16_t)info.vendor==0x054c &&
  ((uint16_t)info.product==0x05c4 || (uint16_t)info.product==0x09cc);
}
static int open_controller(const char *path,int write_access){
 int fd=open(path,(write_access?O_RDWR:O_RDONLY)|O_CLOEXEC|O_NOFOLLOW);
 if(fd>=0&&!supported(fd)){close(fd);errno=ENODEV;return -1;}
 return fd;
}
static int read_info(int fd,uint8_t report[64]){
 memset(report,0,64);report[0]=0x12;
 int length=ioctl(fd,HIDIOCGFEATURE(64),report);
 if(length<0){perror("Cannot read DS4 pairing report");return -1;}
 if(length<16||report[0]!=0x12){fprintf(stderr,"Unexpected or short DS4 pairing report\n");return -1;}
 return 0;
}
static int host_file(const char *path,uint8_t address[6]){
 FILE *file=fopen(path,"r");
 if(!file){perror("Cannot open PSP host file");return -1;}
 char text[128];size_t count=fread(text,1,sizeof(text)-1,file);int bad=ferror(file)||!feof(file);fclose(file);
 text[count]='\0';
 if(bad||memchr(text,'\0',count)){fprintf(stderr,"Invalid host file size/content\n");return -1;}
 while(count&&(text[count-1]=='\n'||text[count-1]=='\r'))text[--count]='\0';
 if(parse_address(text,address)){fprintf(stderr,"Host file must contain one Bluetooth address from pspgo_ds4_host.txt\n");return -1;}
 return 0;
}
int main(int argc,char **argv){
 const char *device=NULL,*host=NULL;int write_target=0;
 for(int i=1;i<argc;i++){
  if(!strcmp(argv[i],"--help")){usage(argv[0]);return 0;}
  else if(!strcmp(argv[i],"--write"))write_target=1;
  else if(!strcmp(argv[i],"--device")&&i+1<argc&&!device)device=argv[++i];
  else if(!strcmp(argv[i],"--host-file")&&i+1<argc&&!host)host=argv[++i];
  else {fprintf(stderr,"Unknown/incomplete option: %s\n",argv[i]);usage(argv[0]);return 2;}
 }
 if(write_target&&!host){fprintf(stderr,"--write requires --host-file; no changes made\n");return 2;}
 uint8_t address[6]={0};if(host&&host_file(host,address))return 2;
 int fd=-1;
 if(device){
  fd=open_controller(device,write_target);
  if(fd<0){perror("Cannot open supported USB DS4");return 1;}
 }else{
  glob_t paths={0};int result=glob("/dev/hidraw*",0,NULL,&paths),count=0,denied=0;
  if(result!=0&&result!=GLOB_NOMATCH){fprintf(stderr,"Cannot list hidraw devices\n");globfree(&paths);return 1;}
  for(size_t i=0;i<paths.gl_pathc;i++){
   int candidate=open_controller(paths.gl_pathv[i],write_target);
   if(candidate<0){if(errno==EACCES)denied=1;continue;}
   ++count;if(count==1){fd=candidate;printf("USB controller: %s\n",paths.gl_pathv[i]);}else close(candidate);
  }
  globfree(&paths);
  if(count!=1){
   if(fd>=0)close(fd);
   if(count>1)fprintf(stderr,"Multiple USB DS4s detected. Leave one connected or choose --device. No changes made.\n");
   else fprintf(stderr,"No supported USB DS4 accessible. Check USB data cable and close controller apps.%s\n",denied?" Permission denied on some hidraw devices: see README's udev rule or sudo command.":"");
   return 1;
  }
 }
 uint8_t before[64],after[64];char own[18],old_host[18];
 if(read_info(fd,before)){close(fd);return 1;}
 decode_address(before+1,own);decode_address(before+10,old_host);
 printf("DS4 address: %s\nCurrent paired host: %s\n",own,old_host);
 if(!write_target){printf("Read-only: no changes made. Use --host-file FILE --write to program the PSP target.\n");close(fd);return 0;}
 uint8_t report[23];pairing_report(address,report);
 /* This is the host-target report, never the controller own-address report. */
 int written=ioctl(fd,HIDIOCSFEATURE(sizeof(report)),report);
 if(written!=(int)sizeof(report)){
  if(written<0)perror("Pairing target write failed");else fprintf(stderr,"Short pairing write: %d bytes\n",written);
  fprintf(stderr,"Pairing state may have changed; read the controller again.\n");close(fd);return 1;
 }
 if(read_info(fd,after)){fprintf(stderr,"Write sent but read-back failed; pairing state may have changed.\n");close(fd);return 1;}
 close(fd);
 if(memcmp(before+1,after+1,6)){fprintf(stderr,"Controller identity changed during test. Do not assume success.\n");return 1;}
 for(unsigned i=0;i<6;i++)if(after[10+i]!=address[5-i]){
  fprintf(stderr,"Read-back did not confirm requested target. Do not assume success.\n");return 1;
 }
 char target[18];decode_address(after+10,target);
 printf("USB read-back confirmed PSP target: %s\n"
 "This confirms the saved address only, not Bluetooth authentication or usable controls.\n"
 "Disconnect DS4 USB. Exit PSP USB mode, enable Bluetooth and press PS alone.\n"
 "Reopen Manage Bluetooth Devices afterward to flush the PSP event log.\n",target);
 return 0;
}
