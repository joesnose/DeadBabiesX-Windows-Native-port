/* Original PSP controller merge adapter, MIT. Hooks remain resident until reboot. */
#ifdef ZEE_INPUT_HOST_TEST
#include "zeemote_input_mock.h"
typedef struct {unsigned TimeStamp,Buttons;unsigned char Lx,Ly,Rsrv[6];} SceCtrlData;
void sceKernelDcacheWritebackAll(void);
void sceKernelIcacheInvalidateAll(void);
#else
#include <pspkernel.h>
#include <pspctrl.h>
#include <psploadcore.h>
#include <pspsdk.h>
#include <systemctrl.h>
#endif
#include <string.h>
#include "zeemote_input.h"
#include "controller_entry_plan.h"
static ZeeState remote;
static unsigned last_ms;
static int active,installed;
static unsigned read_counts[4],merged_samples;
static unsigned install_error,guard_index=~0u;
static unsigned seen_buttons,motion_seen,min_lx=255,max_lx,min_ly=255,max_ly;
void zee_input_stats(ZeeInputStats *out){if(!out)return;int irq=sceKernelCpuSuspendIntr();out->installed=installed;out->active=active;memcpy(out->reads,read_counts,sizeof(read_counts));out->merged_samples=merged_samples;out->install_error=install_error;out->guard_index=guard_index;out->seen_buttons=seen_buttons;out->motion_seen=motion_seen;out->last_buttons=remote.buttons;out->lx=remote.lx;out->ly=remote.ly;out->min_lx=min_lx;out->max_lx=max_lx;out->min_ly=min_ly;out->max_ly=max_ly;sceKernelCpuResumeIntr(irq);}
/* Installation errors:1 firmware,2 module,3 address bounds,4 wrapper/alias,
 * 5 module changed,6 entry changed. No controller memory addresses are logged. */
static int install_fail(unsigned error,unsigned index){install_error=error;guard_index=index;return -1;}
typedef int (*Read)(SceCtrlData *,int);
static Read originals[4];
static uint32_t controller_trampolines[4][4] __attribute__((aligned(16)));
static uint32_t code_address(const void *p){
#ifdef ZEE_INPUT_HOST_TEST
 return zee_test_code_address(p);
#else
 return (uint32_t)(uintptr_t)p;
#endif
}
static unsigned now_ms(void){return (unsigned)(sceKernelGetSystemTimeWide()/1000);}
void zee_input_update(const ZeeState *s){int irq=sceKernelCpuSuspendIntr();remote=*s;seen_buttons|=s->buttons;motion_seen|=(s->lx<112?1u:0u)|(s->lx>144?2u:0u)|(s->ly<112?4u:0u)|(s->ly>144?8u:0u);if(s->lx<min_lx)min_lx=s->lx;if(s->lx>max_lx)max_lx=s->lx;if(s->ly<min_ly)min_ly=s->ly;if(s->ly>max_ly)max_ly=s->ly;last_ms=now_ms();active=1;sceKernelCpuResumeIntr(irq);}
void zee_input_keepalive(void){int irq=sceKernelCpuSuspendIntr();if(active)last_ms=now_ms();sceKernelCpuResumeIntr(irq);}
void zee_input_clear(void){int irq=sceKernelCpuSuspendIntr();active=0;memset(&remote,0,sizeof(remote));sceKernelCpuResumeIntr(irq);}
static int merge(unsigned index,SceCtrlData *p,int count){
 int irq_count=sceKernelCpuSuspendIntr();read_counts[index]++;sceKernelCpuResumeIntr(irq_count);
 int result=originals[index](p,count);if(result<=0||result>count||result>64)return result;
 ZeeState s;int irq=sceKernelCpuSuspendIntr();int valid=active&&(unsigned)(now_ms()-last_ms)<1500;s=remote;sceKernelCpuResumeIntr(irq);
 if(!valid)return result;
 irq=sceKernelCpuSuspendIntr();merged_samples+=(unsigned)result;sceKernelCpuResumeIntr(irq);
 for(int i=0;i<result;i++){
  if(index&1)p[i].Buttons&=~s.buttons;else p[i].Buttons|=s.buttons;
  if(s.lx<112||s.lx>144)p[i].Lx=s.lx;
  if(s.ly<112||s.ly>144)p[i].Ly=s.ly;
 }
 return result;
}
static int peek_pos(SceCtrlData *p,int n){return merge(0,p,n);}
static int peek_neg(SceCtrlData *p,int n){return merge(1,p,n);}
static int read_pos(SceCtrlData *p,int n){return merge(2,p,n);}
static int read_neg(SceCtrlData *p,int n){return merge(3,p,n);}
int zee_input_install(void){
 if(installed)return 0;
 unsigned fw=sceKernelDevkitVersion();if(fw!=0x06060010u&&fw!=0x06060110u)return install_fail(1,~0u);
 static const unsigned nids[]={0x3a622550,0xc152080a,0x1f803938,0x60b81f86};
 static const unsigned aliases[]={0x2ba616af,0xe6085c33,0xbe30ced0,0x3a6a612a};
 Read hooks[]={peek_pos,peek_neg,read_pos,read_neg};
 SceModule *module=sceKernelFindModuleByName("sceController_Service");if(!module)return install_fail(2,~0u);
 uint32_t base=module->text_addr,size=module->text_size,entries[4],snapshots[4][8];
 ControllerEntryPlan plans[4];
 for(unsigned i=0;i<4;i++){
  entries[i]=(uint32_t)sctrlHENFindFunction("sceController_Service","sceCtrl",nids[i]);
  uint32_t alias=(uint32_t)sctrlHENFindFunction("sceController_Service","sceCtrl_driver",aliases[i]);
  /* Validate address bounds before any instruction read. */
  if(base>0xffffffffu-size||size<32||entries[i]<base||entries[i]-base>size-32)return install_fail(3,i);
  for(unsigned j=0;j<8;j++)snapshots[i][j]=_lw(entries[i]+j*4);
  if(controller_entry_plan(i,base,size,entries[i],alias,code_address((void *)hooks[i]),
       code_address(controller_trampolines[i]),snapshots[i],&plans[i]))return install_fail(4,i);
 }
 int irq=sceKernelCpuSuspendIntr();
 if(installed){sceKernelCpuResumeIntr(irq);return 0;}
 if(module->text_addr!=base||module->text_size!=size){sceKernelCpuResumeIntr(irq);return install_fail(5,~0u);}
 /* Recheck every entry before modifying any. Refuse prior/unknown hooks. */
 for(unsigned i=0;i<4;i++)for(unsigned j=0;j<8;j++)if(_lw(entries[i]+j*4)!=snapshots[i][j]){
  sceKernelCpuResumeIntr(irq);return install_fail(6,i);
 }
 for(unsigned i=0;i<4;i++){
  memcpy(controller_trampolines[i],plans[i].trampoline,sizeof(plans[i].trampoline));
  originals[i]=(Read)(uintptr_t)controller_trampolines[i];
 }
 for(unsigned i=0;i<4;i++){_sw(plans[i].entry[0],entries[i]);_sw(plans[i].entry[1],entries[i]+4);}
 sceKernelDcacheWritebackAll();sceKernelIcacheInvalidateAll();installed=1;install_error=0;guard_index=~0u;
 sceKernelCpuResumeIntr(irq);return 0;
}
