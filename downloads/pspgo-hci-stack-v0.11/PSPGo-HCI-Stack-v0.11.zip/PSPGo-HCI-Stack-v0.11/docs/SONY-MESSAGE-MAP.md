# Sony PSP Go Bluetooth message and transport map

Original static analysis, 2026-11-09. No hardware calls performed.

## Critical protocol correction

BCCMD GETREQ=0, SETREQ=2, and response=1. A response type of 1 does not distinguish a GET from a SET. Earlier notes interpreting the saved SET replies as GET-style replies must not be used to infer that Sony request 0x70 is read-only. The v0.9 status-zero replies are acknowledgements; they do not independently prove storage or activation.

## Scope and evidence

This map describes the privately captured sceBSMan module loaded at 0x88239200 and sceUsbBSMCDC_Driver loaded at 0x88226700. Offsets are module-relative. Addresses are for locating evidence in local function files, not patch recipes. Decompiler-inferred parameter names and prototypes are not authoritative. Role labels below describe observable use rather than undocumented official command names.

## Management transport

| Module offset | Evidence address | Role |
| --- | --- | --- |
| BSMan +0x3720 | 0x8823C920 | Serializes a native request header (16-bit message ID and byte length), copies payload into an allocated transmit buffer, submits CDC control output, and waits for a selected response message ID. |
| BSMan +0x385C | 0x8823CA5C | Generic synchronous transaction wrapper. |
| BSMan +0x3978 | 0x8823CB78 | Callback-aware transaction variant; its wait selector is not a timeout. |
| BSMan +0x3C08 | 0x8823CE08 | Send-only export NID 9174CBC3: wraps supplied message ID, buffer, and length. No command interpretation is evident here. |
| CDC +0x10B0 | 0x882277B0 | Native management output: USB vendor/interface control request, bmRequestType 0x41, bRequest 1, wValue/wIndex zero. Requires ready state and aligned buffer. |
| CDC +0x1278 | 0x88227978 | Registers native management receive buffer/callback on the stored receive pipe. |
| CDC +0x1C5C | 0x8822835C | Dispatches USB completions to registered callers. |
| BSMan +0x6B1C | 0x8823FD1C | Chains received USB buffer fragments until the native declared length is available and queues the message. |
| BSMan +0x7074 | 0x88240274 | Queues native records and wakes waiters matching the native message ID. |
| BSMan +0x7340 | 0x88240540 | Removes the six-byte native response header (ID/length/status) and copies response payload into the caller's buffer. |

No explicit BCCMD payload rewrite was found in these examined transmit and receive functions. The received BCCMD type word is not the native outer status field. Queue matching is by Sony message ID; caller-level BCCMD sequence validation remains necessary.

## Initialization sequence

BSMan +0x12C8 (0x8823A4C8) performs the examined initialization:

1. Request 0x00, response 0x100, zero-length payload. It handles outer status 0 or 2 as distinct initialization branches and retries status 0x20 within a time window. Their official semantic names are unassigned.
2. Calls CDC state export 58741C10.
3. Request 0x61, response 0x161, retrieves a six-byte native configuration record.
4. If needed, request 0x60, response 0x160, writes a modified six-byte record. The first word is made 0x031E and a bit in the last word is cleared. These are not established HCI feature bits or a radio boot-mode switch.
5. Request 0x63, response 0x163, reads indexed saved-device records for slots 1 through 8.
6. Depending on the initialization branch, uses requests 0x82 and 0x83 to restore device/service state and invokes PSP-side service handlers.
7. Applies a 20-byte parameter record via request 0x72 and starts further service state handling.

BSMan +0x830 (0x88239A30) runs the management event dispatcher after successful initialization. It explicitly switches over indications in 0x262 through 0x273 and dispatches ranges 0x200-0x20F, 0x210-0x21F, 0x220-0x22F, and 0x240-0x24F to separate handlers. This is a Sony service protocol, not a standard HCI event parser.

## Selected native messages

All lengths are bytes; response lengths are caller-provided capacities, not independently measured wire lengths.

| Request | Expected response | Request bytes | Response capacity | Evidence offset in BSMan | Observable use |
| --- | --- | --- | --- | --- | --- |
| 0x00 | 0x100 | 0 | 0 | +0x12C8 | Initialization readiness/branch status |
| 0x60 | 0x160 | 6 | 6 | +0x3CDC, +0x12C8 | Write native configuration record |
| 0x61 | 0x161 | 0 | 6 | +0x3FC4, +0x12C8 | Read native configuration record |
| 0x62 | 0x162 | 34 | 2 | +0x5BA0 | Device/service operation; exact official name unresolved |
| 0x63 | 0x163 | 2 | 80 | +0x4360 | Read indexed saved-device record |
| 0x66 | 0x166 | 2 | 2 | +0x4B64 | Saved-device operation used during initialization cleanup |
| 0x68 | 0x168 | 6 | 4 | +0x2728 | Device-address operation |
| 0x69 | 0x169 | 4 | 4 | +0x2B10 | Native device operation |
| 0x6A | 0x16A | 6 | 6 | +0x2F78 | Native device operation |
| 0x6C | 0x16C | 6 | 6 | +0x46AC | Native device operation |
| 0x6D | 0x16D | 0 | 2 | +0x47F4 | Native operation with service-state bookkeeping |
| 0x6E | 0x16E | 40 | 2 | +0x3194 | Native parameter operation |
| 0x70 | 0x170 | 50 | 50 | +0x412C | Built-in BDADDR read using embedded BCCMD varid 0x7003; experimental BCCMD transactions use this route too |
| 0x72 | 0x172 | 20 | 2 | +0x5AA8 | Native parameter record applied during initialization |
| 0x78 | 0x179 | 6 | 2 | +0x55E0 | Operation followed by indication 0x272 |
| 0x79 | 0x17A | 4 | 4 | +0x34F8 | Device-specific operation; also reached in DS3 setup |
| 0x7B | 0x17C | 4 | 2 | +0x344C | Native device operation |
| 0x7E | 0x17F | 8 | 0 | +0x4D00 | Device-address operation followed by asynchronous result |
| 0x82 | 0x183 | 2 | 4 | +0x12C8 | Reads per-device service state during restoration |
| 0x83 | 0x184 | 2 | 6 | +0x12C8 | Reads further per-service state during restoration |
| 0x84 | 0x185 | 2 | 2 | +0x32F4 | Native operation followed by indication 0x275 |
| 0x87 | 0x188 | 2 | 0 | +0xBE94 | Service-state operation |

The response-ID offset is not uniformly 0x100; several rows above deliberately preserve the actual distinct request/response IDs. Do not guess adjacent commands.

## Data pipes and HID

CDC +0x244 (0x88226944) accepts the Sony/CSR USB identities and checks CDC-style interface classes. CDC +0x388 (0x88226A88) opens management and indexed data endpoints. The data APIs accept a channel index and directly operate on stored USB pipe handles:

| CDC offset | NID | Observed direction/API |
| --- | --- | --- |
| +0x1398 | EC0493A4 | Synchronous indexed receive |
| +0x1514 | A5E108BB | Asynchronous indexed receive |
| +0x1640 | F8C6AFBD | Synchronous indexed send |
| +0x17B4 | 6BD82129 | Asynchronous indexed send |

BSMan +0xA128 (0x88243328) selects data channel 2 or 3 according to service flags, registers with sceHIDSvc, and receives 64-byte fragments through A5E108BB. BSMan +0x9EE0 (0x882430E0) groups records using HID transaction framing: it explicitly tests for high nibble 0xA0, corresponding to HID DATA transactions. This is positive evidence that at least these pipes carry service/HID traffic rather than raw HCI ACL packets.

The DS3 VID/PID check appears in this HID setup after service creation. It selects additional DS3-specific setup, while the receive registration has a generic path. Its existence neither proves DS4 compatibility nor explains an earlier link-establishment failure.

Other BSMan data wrappers at +0xB774, +0xB820, +0xB944 and +0xB9F0 expose indexed send/receive operations. Their channel selection must be traced through callers before assigning a Bluetooth protocol. A raw USB data API is not automatically a raw HCI API.

## HCI conclusion and remaining work

No standard HCI command/ACL passthrough route was identified in the examined BSMan initialization, native message transaction path, event dispatcher, or HID pipe handlers. This is a scoped negative result, not proof that the radio has no HCI support.

The corrected SET response interpretation means request 0x70 must remain a candidate BCCMD writer. The unresolved issue is why acknowledged same-value SETs were followed by unsuccessful RAM-only reads, and whether activation needs a separately documented mechanism. Mapping this storage/activation behavior is more justified than inventing a request 0x71 route.

Potential follow-up offline targets are callers of the native send-only export, remaining data channel ownership, Sony/CSR message definitions in public material, and radio boot-mode semantics from the CSR documentation. No command in this map is proposed as a hardware probe.
