#!/usr/bin/env python3
"""Diagnostic-path stack and raw marker regression checks; not a hardware test."""
import json,sys
from check_hid_stack import functions
f=functions(sys.argv[1]);a,w,frame=f['boot_marker_tick']
allowed={f[n][0] for n in ['pspSdkSetK1','sceKernelCpuSuspendIntr','sceKernelCpuResumeIntr','sceIoOpen','sceIoWrite','sceIoClose']}
assert frame<=256
assert all((((a+i*4+4)&0xf0000000)|((v&0x3ffffff)<<2)) in allowed for i,v in enumerate(w) if v>>26==3)
assert f['log_line'][2]<=512 and f['logger_thread'][2]<=2048
print(json.dumps(dict(raw_marker_frame=frame,raw_marker_no_formatter=True,log_line_frame=f['log_line'][2],logger_frame=f['logger_thread'][2],pass_check=True)))
