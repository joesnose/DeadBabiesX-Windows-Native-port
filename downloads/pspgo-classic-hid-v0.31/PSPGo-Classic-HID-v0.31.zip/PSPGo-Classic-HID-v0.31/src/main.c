/* Guarded PSP Go native HID profile selection; no firmware binaries included. */
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsysmem_kernel.h>
#include <pspsysclib.h>
#include <pspsdk.h>
#include <pspinit.h>
#include <systemctrl.h>
#include <stdarg.h>
#include <stdint.h>
#include <string.h>
#include "patch_plan.h"
#include "profile_policy.h"
#include "registration_policy.h"
#include "zeemote_hooks.h"
#include "zeemote_input.h"
#include "game_reconnect.h"
#include "pair_trace.h"
#include "lifecycle_trace.h"
#include "zeemote_input.h"
PSP_MODULE_INFO("PSPGoClassicHID",PSP_MODULE_KERNEL,0,31);
#define LOG_PATH "ef0:/seplugins/pspgo_hci_transport.log"
static STMOD_HANDLER previous_handler;
static uint32_t trampoline[4][4] __attribute__((aligned(16)));
static int (*original_register)(const void *,const void *);
static int (*original_no_pin)(const void *);
static int (*original_profile)(int,void *);
static int (*original_hid_connect)(int,int);
static int resident;
typedef struct {uint32_t base;SceUID block;uint32_t *code;} UiStub;
static UiStub ui_stubs[4];
static unsigned ui_stub_count;
static UiStub pin_stubs[4];
static unsigned pin_stub_count;
static unsigned profile_lines;
typedef struct {int seen,status,valid;unsigned flags,id;} ProfileState;
static ProfileState profile_states[8];
typedef struct {unsigned length;char data[256];} LogBuffer;
static void format_char(void *ctx,int ch){
 LogBuffer *b=ctx;if(ch==0x200)b->length=0;
 else if(ch>=0&&ch<256&&b->length<sizeof(b->data))b->data[b->length++]=(char)ch;
}
static void log_line(const char *fmt,...){
 int old=pspSdkSetK1(0);LogBuffer b={0,{0}};va_list args;
 va_start(args,fmt);prnt(format_char,&b,fmt,args);va_end(args);
 SceUID fd=sceIoOpen(LOG_PATH,PSP_O_CREAT|PSP_O_WRONLY|PSP_O_APPEND,0666);
 if(fd>=0){if(b.length)sceIoWrite(fd,b.data,b.length);sceIoClose(fd);}
 pspSdkSetK1(old);
}
static void reset_profile_cache(void){
 int irq=sceKernelCpuSuspendIntr();
 for(unsigned i=0;i<8;++i)profile_states[i].seen=0;
 sceKernelCpuResumeIntr(irq);
}
/* Arguments are forwarded unchanged. Never read/log PINs, link keys or device records. */
static int register_trace(const void *device,const void *pin){
 log_line("PIN_REGISTER begin\n");
 int result=original_register(device,pin);
 reset_profile_cache();
 log_line("PIN_REGISTER result=%08x\n",(unsigned)result);
 return result;
}
static void flush_code(void){sceKernelDcacheWritebackInvalidateAll();sceKernelIcacheInvalidateAll();}
static int no_pin_trace(const void *device_address){
 log_line("NO_PIN_REGISTER begin\n");
 int result=original_no_pin(device_address);
 reset_profile_cache();
 log_line("NO_PIN_REGISTER result=%08x\n",(unsigned)result);
 return result;
}
/* The native event worker only copies known numeric fields into bounded RAM.
 * UI profile queries/connection requests drain it; no event-thread file I/O. */
static int (*original_slc_event)(const uint16_t *);
typedef struct {unsigned slot,state,flags,length,outgoing,sequence;} SlcEvent;
typedef struct {unsigned slot,flags,allow,sequence,finished;int result;} IncomingEvent;
static SlcEvent slc_events[16];
static IncomingEvent incoming_events[16];
static unsigned slc_count,slc_dropped,incoming_count,incoming_dropped,event_sequence;
static int active_slot;
static int (*original_incoming)(unsigned,unsigned,int);
static void record_incoming(unsigned slot,unsigned flags,int allow,int finished,int result){
 if(slot<1 || slot>8 || !(flags&2))return;
 int irq=sceKernelCpuSuspendIntr();unsigned sequence=++event_sequence;
 if(incoming_count<16){IncomingEvent *e=&incoming_events[incoming_count++];
  e->slot=slot;e->flags=flags;e->allow=(unsigned)allow;e->finished=(unsigned)finished;
  e->result=result;e->sequence=sequence;
 }else ++incoming_dropped;
 sceKernelCpuResumeIntr(irq);
}
static int incoming_trace(unsigned slot,unsigned flags,int allow){
 record_incoming(slot,flags,allow,0,0);
 int result=original_incoming(slot,flags,allow);
 record_incoming(slot,flags,allow,1,result);
 return result;
}
static int slc_event_trace(const uint16_t *body){
 uintptr_t a=(uintptr_t)body,phys=a&0x1fffffffu;
 unsigned alias=a&0xe0000000u;
 int irq=sceKernelCpuSuspendIntr();
 if(!(a&1) && (alias==0||alias==0x80000000u||alias==0xa0000000u) &&
    phys>=0x08000004u && phys<=0x0c000000u-6 && body[-2]==0x263 &&
    slc_payload_length(body[-1])>=6 && body[0]>=1 && body[0]<=8 && (body[2]&2)){
  unsigned sequence=++event_sequence;
  if(slc_count<16){SlcEvent *e=&slc_events[slc_count++];
   e->slot=body[0];e->state=body[1];e->flags=body[2];e->length=body[-1];
   e->outgoing=active_slot==body[0];e->sequence=sequence;

  }else ++slc_dropped;
 }
 sceKernelCpuResumeIntr(irq);
 return original_slc_event(body);
}
/* UI threads and the dedicated logger drain RAM; no native event-thread I/O.
 * A drain lock preserves log sequence order when the UI and worker race. */
static int drain_busy;
static void drain_slc_events(void){
 SlcEvent events[16];IncomingEvent incoming[16];unsigned count,dropped,n,missed;
 int irq=sceKernelCpuSuspendIntr();
 if(drain_busy){sceKernelCpuResumeIntr(irq);return;}
 drain_busy=1;count=slc_count;dropped=slc_dropped;n=incoming_count;missed=incoming_dropped;
 memcpy(events,slc_events,count*sizeof(events[0]));slc_count=0;slc_dropped=0;
 memcpy(incoming,incoming_events,n*sizeof(incoming[0]));incoming_count=0;incoming_dropped=0;
 sceKernelCpuResumeIntr(irq);
 unsigned i=0,j=0;
 while(i<count || j<n){
  if(i<count && (j==n || (int)(events[i].sequence-incoming[j].sequence)<0)){
   SlcEvent *e=&events[i++];
   log_line("SLC_EVENT seq=%u slot=%u state=%u flags=%04x packet_length=%u payload_length=%u during_request=%u\n",
    e->sequence,e->slot,e->state,e->flags,e->length,e->length-4,e->outgoing);
  }else{
   IncomingEvent *e=&incoming[j++];
   if(e->finished)log_line("HID_INCOMING_END seq=%u slot=%u flags=%04x allow=%u result=%08x\n",
    e->sequence,e->slot,e->flags,e->allow,(unsigned)e->result);
   else log_line("HID_INCOMING_BEGIN seq=%u slot=%u flags=%04x allow=%u\n",e->sequence,e->slot,e->flags,e->allow);
  }
 }
 if(dropped||missed)log_line("TRACE_DROPPED slc=%u incoming=%u\n",dropped,missed);
 irq=sceKernelCpuSuspendIntr();drain_busy=0;sceKernelCpuResumeIntr(irq);
}
static PairReceive original_pair_receive;
static PairEvent pair_events[32];static unsigned pair_count,pair_dropped;
static void pair_record(const PairEvent *event){
 int irq=sceKernelCpuSuspendIntr();
 if(pair_count<32)pair_events[pair_count++]=*event;else ++pair_dropped;
 sceKernelCpuResumeIntr(irq);
}
static int pair_receive_trace(const void *sel,unsigned count,void *packet,unsigned cap,void *timeout,int callbacks){
 return pair_trace_forward(sel,count,packet,cap,timeout,callbacks,original_pair_receive,pair_record);
}
static void drain_pair_events(void){
 PairEvent e[32];unsigned count,dropped;int irq=sceKernelCpuSuspendIntr();
 count=pair_count;dropped=pair_dropped;memcpy(e,pair_events,count*sizeof(e[0]));pair_count=pair_dropped=0;
 sceKernelCpuResumeIntr(irq);
 for(unsigned i=0;i<count;i++)log_line("PAIR_EVENT id=%04x length=%u slot=%u word1=%04x\n",e[i].id,e[i].length,e[i].slot,e[i].word1);
 if(dropped)log_line("PAIR_EVENT dropped=%u\n",dropped);
}
static void install_pair_trace(void){
 SceModule *m=sceKernelFindModuleByName("sceBSMan");
 if(!m||m->text_size<0x7484){log_line("PAIR_TRACE skipped: module unavailable\n");return;}
 uint32_t b=m->text_addr,c[PAIR_TRACE_WORDS],patched;
 int irq=sceKernelCpuSuspendIntr();
 for(unsigned i=0;i<PAIR_TRACE_WORDS;i++)c[i]=_lw(b+0x9d0+i*4);
 int valid=pair_trace_plan(b,m->text_size,(uint32_t)(uintptr_t)pair_receive_trace,c,&patched)==0;
 if(valid){original_pair_receive=(PairReceive)(uintptr_t)(b+0x7480);_sw(patched,b+0x9e4);flush_code();resident=1;}
 sceKernelCpuResumeIntr(irq);
 log_line(valid?"PAIR_TRACE passive numeric event observer installed\n":"PAIR_TRACE skipped: receive context mismatch\n");
}
static void lifecycle_wait_snapshot(SceUID id){
 if(id<=0)return;
 SceKernelSemaInfo sem;memset(&sem,0,sizeof(sem));sem.size=sizeof(sem);
 if(sceKernelReferSemaStatus(id,&sem)>=0){
  sem.name[31]=0;log_line("LIFE_SEMA id=%08x name=%s count=%d waiters=%d\n",(unsigned)id,sem.name,sem.currentCount,sem.numWaitThreads);return;
 }
 SceKernelEventFlagInfo event;memset(&event,0,sizeof(event));event.size=sizeof(event);
 if(sceKernelReferEventFlagStatus(id,&event)>=0){
  event.name[31]=0;log_line("LIFE_FLAG id=%08x name=%s pattern=%08x waiters=%d\n",(unsigned)id,event.name,(unsigned)event.currentPattern,event.numWaitThreads);
 }
}
static void lifecycle_thread_snapshot(void){
 static unsigned ticks,samples,armed;static SceKernelThreadInfo last[16];static SceUID last_ids[16];static unsigned last_count;
 ZeeInputStats input;zee_input_stats(&input);if(input.active)armed=1;
 if(!armed||++ticks%4||samples>=180)return;
 ++samples;log_line("LIFE_HEARTBEAT sample=%u context=%08x\n",samples,(unsigned)sceKernelInitKeyConfig());
 SceUID ids[128];int count=0;
 if(sceKernelGetThreadmanIdList(SCE_KERNEL_TMID_Thread,ids,128,&count)<0)return;
 if(count>128)count=128;
 for(int i=0;i<count;i++){
  SceKernelThreadInfo info;memset(&info,0,sizeof(info));info.size=sizeof(info);
  if(sceKernelReferThreadStatus(ids[i],&info)<0)continue;
  info.name[31]=0;if(!life_watched(info.name))continue;
  unsigned at=0;while(at<last_count&&last_ids[at]!=ids[i])++at;
  int changed=at==last_count||last[at].status!=info.status||last[at].waitType!=info.waitType||last[at].waitId!=info.waitId;
  if(changed||samples%5==0){log_line("LIFE_THREAD id=%08x name=%s status=%08x wait_type=%d wait_id=%08x priority=%d stack_size=%d\n",(unsigned)ids[i],info.name,(unsigned)info.status,info.waitType,(unsigned)info.waitId,info.currentPriority,info.stackSize);lifecycle_wait_snapshot(info.waitId);}
  if(at<16){last[at]=info;last_ids[at]=ids[i];if(at==last_count)++last_count;}
 }
}
static void auto_reconnect_tick(void);
static int logger_thread(SceSize args,void *argp){
 (void)args;(void)argp;
 for(;;){sceKernelDelayThread(500000);drain_slc_events();drain_pair_events();zeemote_input_log_tick(log_line);auto_reconnect_tick();lifecycle_thread_snapshot();}
 return 0;
}
static int current_profile_query(int index,void *record){
 int old=pspSdkSetK1(0);
 int result=original_profile(index,record);
 pspSdkSetK1(old);return result;
}
static int selected_connect_forward(int index,int mode){
 log_line("HID_CONNECT native slot=%d selected_mode=%d flags=%04x\n",
          index,mode,mode?0x0402:0x0202);
 return original_hid_connect(index,mode);
}
static int hid_connect_trace(int index,int mode){
 drain_slc_events();
 log_line("HID_CONNECT begin slot=%d mode=%d\n",index,mode);
 int irq=sceKernelCpuSuspendIntr();
 int trace=index>=1 && index<=8 && !active_slot;
 if(trace)active_slot=index;
 sceKernelCpuResumeIntr(irq);
 NativeProfileDecision decision;
 int result=native_profile_connect(index,mode,original_profile?current_profile_query:NULL,
                                  selected_connect_forward,&decision);
 irq=sceKernelCpuSuspendIntr();if(trace)active_slot=0;sceKernelCpuResumeIntr(irq);
 drain_slc_events();reset_profile_cache();
 log_line("PROFILE_SELECT queried=%d result=%08x valid=%d id=%u flags=%04x requested=%d selected=%d\n",
          decision.queried,(unsigned)decision.query_result,decision.valid,decision.id,
          decision.flags,decision.requested_mode,decision.selected_mode);
 log_line("HID_CONNECT result=%08x\n",(unsigned)result);
 return result;
}
static int profile_trace(int index,void *record){
 drain_slc_events();
 int result=original_profile(index,record);
 if(index>=1 && index<=8){
  unsigned flags=0,id=0;int valid=0;
  uintptr_t address=(uintptr_t)record,physical=address&0x1fffffffu;
  unsigned alias=address&0xe0000000u;
  int irq=sceKernelCpuSuspendIntr();
  if(result>=0 && !(address&3) &&
     (alias==0 || alias==0x80000000u || alias==0xa0000000u) &&
     physical>=0x08000000u && physical<=0x0c000000u-80 && _lw(address)==0x50){
   const uint8_t *p=record;id=p[4]|((unsigned)p[5]<<8);
   flags=p[72]|((unsigned)p[73]<<8);valid=1;
  }
  ProfileState *old=&profile_states[index-1];
  int changed=!old->seen || old->status!=result || old->valid!=valid || old->flags!=flags || old->id!=id;
  old->seen=1;old->status=result;old->valid=valid;old->flags=flags;old->id=id;
  int emit=changed && profile_lines<64;if(emit)++profile_lines;
  sceKernelCpuResumeIntr(irq);
  if(emit)log_line("PROFILE slot=%d result=%08x metadata=%d id=%u flags=%04x\n",index,(unsigned)result,valid,id,flags);
 }
 return result;
}
/* Native Bluetooth startup precedes ordinary GAME plugins. Once our HID
 * hooks are ready in GAME or VSH, initiate the same saved-target connection as the menu.
 * One attempt per context only; no repeated connection storm on an asynchronous success. */
static void auto_reconnect_tick(void){
 static unsigned ticks,done;
 unsigned context=sceKernelInitKeyConfig();
 if(done||(context!=PSP_INIT_KEYCONFIG_GAME&&context!=PSP_INIT_KEYCONFIG_VSH))return;
 if(++ticks<4)return;
 done=1;ZeeInputStats stats;zee_input_stats(&stats);
 if(!zeemote_input_ready()||!sceKernelFindModuleByName("sceHIDSvc")){
  log_line("AUTO_RECONNECT skipped: HID module unavailable\n");return;
 }
 ZeeReconnect d=zee_game_reconnect(stats.active,original_profile?current_profile_query:NULL,
                                 original_hid_connect?hid_connect_trace:NULL);
 log_line("AUTO_RECONNECT context=%08x active=%u queries=%u matches=%u slot=%u flags=%04x attempted=%u result=%08x\n",
  context,stats.active,d.queries,d.matches,d.slot,d.flags,d.attempted,(unsigned)d.result);
}
static void install_trace(HookKind kind,uint32_t nid,uint32_t hook,const char *label){
 SceModule *mod=sceKernelFindModuleByName("sceBSMan");
 uint32_t entry=sctrlHENFindFunction("sceBSMan","sceBSMan",nid);
 if(!mod || !entry || mod->text_size<12 || entry<mod->text_addr ||
    entry-mod->text_addr>mod->text_size-12 || (entry&3)){
  log_line("%s hook skipped: export unavailable or outside module\n",label);return;
 }
 int irq=sceKernelCpuSuspendIntr();
 const uint32_t original[]={_lw(entry),_lw(entry+4)};HookPlan plan;
 int valid=native_hook_plan(entry,hook,(uint32_t)(uintptr_t)trampoline[kind],
                            original,kind,mod->text_addr,&plan)==0;
 if(valid){
  memcpy(trampoline[kind],plan.trampoline,sizeof(trampoline[kind]));
  if(kind==HOOK_PIN)original_register=(void *)trampoline[kind];
  else if(kind==HOOK_NO_PIN)original_no_pin=(void *)trampoline[kind];
  else if(kind==HOOK_PROFILE)original_profile=(void *)trampoline[kind];
  else original_hid_connect=(void *)trampoline[kind];
  _sw(plan.entry[0],entry);_sw(plan.entry[1],entry+4);flush_code();resident=1;
 }
 sceKernelCpuResumeIntr(irq);
 if(valid)log_line("%s hook installed at module+%08x\n",label,entry-mod->text_addr);
 else log_line("%s hook skipped: prologue mismatch %08x %08x\n",label,original[0],original[1]);
}
static void install_slc_trace(void){
 SceModule *mod=sceKernelFindModuleByName("sceBSMan");uint32_t word;
 if(!mod || mod->text_size<0x204c){log_line("SLC_TRACE skipped: module unavailable\n");return;}
 uint32_t base=mod->text_addr,site=base+0xa24;
 int irq=sceKernelCpuSuspendIntr();
 int valid=slc_call_plan(base,(uint32_t)(uintptr_t)slc_event_trace,
  _lw(site),_lw(site+4),_lw(site+8),_lw(base+0x2044),_lw(base+0x2048),&word)==0;
 if(valid){original_slc_event=(void *)(uintptr_t)(base+0x2044);
  _sw(word,site);flush_code();resident=1;}
 sceKernelCpuResumeIntr(irq);
 log_line(valid?"SLC_TRACE event call installed\n":"SLC_TRACE skipped: firmware context mismatch\n");
}
static void install_incoming_trace(void){
 SceModule *mod=sceKernelFindModuleByName("sceBSMan");uint32_t word;
 if(!mod || mod->text_size<0x2f80){log_line("HID_INCOMING skipped: module unavailable\n");return;}
 uint32_t base=mod->text_addr,site=base+0xc90;
 int irq=sceKernelCpuSuspendIntr();
 uint32_t context[]={_lw(site-8),_lw(site-4),_lw(site),_lw(site+4),_lw(site+8),_lw(site+12),_lw(base+0x2f78),_lw(base+0x2f7c)};
 int valid=incoming_call_plan(base,(uint32_t)(uintptr_t)incoming_trace,context,&word)==0;
 if(valid){original_incoming=(void *)(uintptr_t)(base+0x2f78);
  _sw(word,site);flush_code();resident=1;}
 sceKernelCpuResumeIntr(irq);
 log_line(valid?"HID_INCOMING decision call installed\n":"HID_INCOMING skipped: firmware context mismatch\n");
}
static void patch_discovery(SceModule *mod){
 const unsigned load_offset=0x13d40,compare_offset=0x13d6c;
 if(mod->text_size<compare_offset+4){log_line("DISCOVERY skipped: module too small\n");return;}
 int irq=sceKernelCpuSuspendIntr();
 uint32_t first=_lw(mod->text_addr+load_offset),second=_lw(mod->text_addr+compare_offset);
 int valid=discovery_patch_allowed(first,second);
 if(valid){
  _sw(0x240effffu,mod->text_addr+load_offset);
  _sw(0x144e0003u,mod->text_addr+compare_offset);flush_code();
 }
 sceKernelCpuResumeIntr(irq);
 if(valid)log_line("DISCOVERY filter lifted in RAM; select Zeemote: SteelSeries Free in Gamepad mode\n");
 else if(first==0x240effffu&&second==0x144e0003u)log_line("DISCOVERY filter already lifted\n");
 else log_line("DISCOVERY skipped: instruction mismatch %08x %08x\n",first,second);
}
static uint32_t jump_target(uint32_t pc,uint32_t word){
 return ((pc+4)&0xf0000000u)|((word&0x03ffffffu)<<2);
}
static int hid_context_matches(SceModule *mod){
 uint32_t base=mod->text_addr;
 if(mod->text_size<0x20c2c)return 0;
 uint32_t call=_lw(base+0x14ec0),hi=_lw(base+0x14ec8),lo=_lw(base+0x14ecc);
 uint32_t table=((hi&0xffffu)<<16)+(int16_t)lo;
 return _lw(base+0x14e18)==0x00a09021u && /* move s2,a1 */
        _lw(base+0x14e2c)==0x8e110004u && /* lw s1,4(s0) */
        _lw(base+0x14e38)==0x94a20048u && /* lhu v0,72(a1) */
        _lw(base+0x14e50)==0x24020001u &&
        call>>26==3 && jump_target(base+0x14ec0,call)==base+0x1abe0 &&
        _lw(base+0x14ec4)==0 && (hi&0xffff0000u)==0x3c030000u &&
        (lo&0xffff0000u)==0x24630000u && table==base+0x20c28;
}
static void patch_hid_menu(SceModule *mod){
 uint32_t base=mod->text_addr,site=base+0x14eb8;
 if(!hid_context_matches(mod)){log_line("HID_MENU skipped: firmware context mismatch\n");return;}
 UiStub *stub=NULL;
 for(unsigned i=0;i<ui_stub_count;++i)if(ui_stubs[i].base==base)stub=&ui_stubs[i];
 if(!stub){
  if(ui_stub_count>=4){log_line("HID_MENU skipped: user-stub limit reached\n");return;}
  int old_k1=pspSdkSetK1(0);
  SceUID block=sceKernelAllocPartitionMemory(2,"DS4HidMenu",PSP_SMEM_Low,56,NULL);
  uint32_t *code=block>=0?sceKernelGetBlockHeadAddr(block):NULL;
  uintptr_t address=(uintptr_t)code;
  int usable=code && !(address&3) && address>=0x08800000u && address<=0x0c000000u-56;
  if(block>=0 && !usable)sceKernelFreePartitionMemory(block);
  pspSdkSetK1(old_k1);
  if(block<0){log_line("HID_MENU skipped: user memory allocation %08x\n",block);return;}
  if(!usable){log_line("HID_MENU skipped: no valid user memory address\n");return;}
  stub=&ui_stubs[ui_stub_count++];stub->base=base;stub->block=block;stub->code=code;
 }
 int irq=sceKernelCpuSuspendIntr();
 uint32_t branch=_lw(site),delay=_lw(site+4);HidMenuPlan plan;
 int valid=hid_context_matches(mod)&&hid_menu_plan(site,(uint32_t)(uintptr_t)stub->code,branch,delay,&plan)==0;
 int already=branch>>26==2 && jump_target(site,branch)==(uint32_t)(uintptr_t)stub->code && delay==0x24040004u;
 if(valid){
  memcpy(stub->code,plan.code,sizeof(plan.code));_sw(plan.entry,site);flush_code();
 }
 sceKernelCpuResumeIntr(irq);
 if(valid)log_line("HID_MENU initial connection action enabled for type 2 with native HID flag\n");
 else if(already)log_line("HID_MENU already patched for this module\n");
 else log_line("HID_MENU skipped: branch/delay mismatch %08x %08x\n",branch,delay);
}
/* Only the default-PIN predicate at the real discovery-record call site is
 * extended. The stock allocator, object constructor and native registration
 * remain responsible for the selected record and PIN. No address-only hook
 * fabricates a discovery identifier. */
static void pin_context(SceModule *mod,uint32_t c[13]){
 uint32_t b=mod->text_addr;
 const uint32_t offsets[]={0x13f1c,0x13f20,0x13f24,0x13f28,0x13f2c,0x13f30,0x13f3c,0x13f40,0x13f44,0x13f48,0x13af8,0x13afc,0x20b70};
 for(unsigned i=0;i<13;i++)c[i]=_lw(b+offsets[i]);
}
static void patch_registration(SceModule *mod){
 if(mod->text_size<0x20ba0){log_line("PIN_ROUTE skipped: UI module too small\n");return;}
 uint32_t b=mod->text_addr,c[13],table[14],category[2];UiStub *stub=NULL;
 for(unsigned i=0;i<pin_stub_count;i++)if(pin_stubs[i].base==b)stub=&pin_stubs[i];
 if(stub){uint32_t predicate,constructor;
  if(!mips_jump(b+0x13f1c,(uint32_t)(uintptr_t)stub->code,&predicate)&&
     !mips_jump(b+0x13f3c,(uint32_t)(uintptr_t)stub->code+PIN_WRAPPER_OFFSET,&constructor)&&
     _lw(b+0x13f1c)==(predicate|0x04000000u)&&_lw(b+0x13f3c)==(constructor|0x04000000u)&&
     _lw(b+0x13f20)==0x02002821u&&_lw(b+0x13f40)==0x00408021u&&_lw(b+0x13afc)==0x24060020u){
   log_line("PIN_ROUTE hybrid already installed\n");return;
  }
 }
 pin_context(mod,c);for(unsigned i=0;i<14;i++)table[i]=_lw(b+0x20b68+i*4);
 category[0]=_lw(b+0x13950);category[1]=_lw(b+0x13954);NativePinPlan check;
 if(native_pin_hybrid_plan(b,0x08800000u,c,table,category,&check)){
  log_line("PIN_ROUTE skipped: constructor/category/vtable context mismatch\n");return;
 }
 if(!stub){
  if(pin_stub_count>=4){log_line("PIN_ROUTE skipped: resident stub limit\n");return;}
  int old=pspSdkSetK1(0);SceUID block=sceKernelAllocPartitionMemory(2,"DS4NativePin",PSP_SMEM_Low,PIN_STUB_BYTES,NULL);
  uint32_t *code=block>=0?sceKernelGetBlockHeadAddr(block):NULL;uintptr_t a=(uintptr_t)code;
  int usable=code&&!(a&3)&&a>=0x08800000u&&a<=0x0c000000u-PIN_STUB_BYTES;
  if(block>=0&&!usable){sceKernelFreePartitionMemory(block);}
  pspSdkSetK1(old);
  if(block<0||!usable){log_line("PIN_ROUTE skipped: no usable resident user memory\n");return;}
  stub=&pin_stubs[pin_stub_count++];stub->base=b;stub->block=block;stub->code=code;
 }
 int irq=sceKernelCpuSuspendIntr();pin_context(mod,c);for(unsigned i=0;i<14;i++)table[i]=_lw(b+0x20b68+i*4);
 category[0]=_lw(b+0x13950);category[1]=_lw(b+0x13954);NativePinPlan plan;
 int valid=native_pin_hybrid_plan(b,(uint32_t)(uintptr_t)stub->code,c,table,category,&plan)==0;
 if(valid){memcpy(stub->code,plan.code,sizeof(plan.code));_sw(plan.pin_zero_delay,b+0x13afc);_sw(plan.constructor_entry,b+0x13f3c);_sw(plan.entry,b+0x13f1c);flush_code();resident=1;}
 sceKernelCpuResumeIntr(irq);
 log_line(valid?"PIN_ROUTE installed: exact ASCII-case-insensitive Zeemote: SteelSeries Free name uses native PIN registration and private HID category; name does not prove identity or mode\n":"PIN_ROUTE skipped: context changed before installation\n");
}
static int module_started(SceModule *mod){
 if(mod&&!strcmp(mod->modname,"bluetooth_plugin_module")){patch_discovery(mod);patch_hid_menu(mod);patch_registration(mod);}
 zeemote_input_install_module(mod,log_line);
 return previous_handler?previous_handler(mod):0;
}
int module_start(SceSize args,void *argp){
 (void)args;(void)argp;
 unsigned fw=sceKernelDevkitVersion();int model=sceKernelGetModel();
 log_line("\nPSPGo Classic HID clean-baseline route 0.31 model=%d devkit=%08x\n",model,fw);
 if(model!=4||(fw!=0x06060010&&fw!=0x06060110)){
  log_line("UNSUPPORTED model/firmware; no patches installed\n");return -1;
 }
 log_line("BOOT context=%08x ctrl=%u bsman=%u hid=%u bridge=%u\n",
  (unsigned)sceKernelInitKeyConfig(),sceKernelFindModuleByName("sceController_Service")!=NULL,
  sceKernelFindModuleByName("sceBSMan")!=NULL,sceKernelFindModuleByName("sceHIDSvc")!=NULL,
  sceKernelFindModuleByName("sceVshBridge_Driver")!=NULL);
 install_trace(HOOK_PIN,0x8ac2f7b8u,(uint32_t)(uintptr_t)register_trace,"PIN_REGISTER");
 install_trace(HOOK_NO_PIN,0x2d649923u,(uint32_t)(uintptr_t)no_pin_trace,"NO_PIN_REGISTER");
 install_trace(HOOK_PROFILE,0xcbd232d1u,(uint32_t)(uintptr_t)profile_trace,"PROFILE");
 install_trace(HOOK_HID_CONNECT,0xf188a405u,(uint32_t)(uintptr_t)hid_connect_trace,"HID_CONNECT");
 install_slc_trace();
 install_incoming_trace();
 install_pair_trace();
 SceUID logger=sceKernelCreateThread("DS4TraceLogger",logger_thread,0x30,8192,0,NULL);
 int logger_result=logger>=0?sceKernelStartThread(logger,0,NULL):logger;
 if(logger_result<0){if(logger>=0)sceKernelDeleteThread(logger);log_line("LOGGER unavailable %08x; reopen device list to flush\n",(unsigned)logger_result);}
 else log_line("LOGGER automatic flush enabled\n");
 previous_handler=sctrlHENSetStartModuleHandler(module_started);resident=1;
 SceModule *mod=sceKernelFindModuleByName("bluetooth_plugin_module");
 if(mod){patch_discovery(mod);patch_hid_menu(mod);patch_registration(mod);}
 zeemote_input_install_module(sceKernelFindModuleByName("sceHIDSvc"),log_line);
 log_line("READY: generic descriptor input; native pairing selection; Zeemote-only auto reconnect; actual connection required\n");
 return 0;
}
int module_stop(SceSize args,void *argp){
 (void)args;(void)argp;
 /* Keep hook code resident. Disabling the entry and rebooting clears RAM patches. */
 if(resident)return -1;
 return 0;
}
