/* Bounded file-sink fallback policy; no PSP dependencies, original MIT. */
#ifndef DIAG_SINK_H
#define DIAG_SINK_H
#include <stddef.h>
#include <string.h>
#define DIAG_ROUTES 4
#define DIAG_NO_ROUTE 4u
#define DIAG_LINE_LIMIT 256u
typedef int (*DiagOpen)(const char *);
typedef int (*DiagWrite)(int,const void *,unsigned);
typedef int (*DiagClose)(int);
typedef struct {unsigned route,failures;int open_error[DIAG_ROUTES],write_error,close_error;} DiagSink;
static inline void diag_sink_init(DiagSink *s){
 *s=(DiagSink){.route=DIAG_NO_ROUTE};
}
/* One line, at most four opens. Preserve partial-write offsets per file;
 * an error may leave a partial line in a failed file, never false success.
 * Each descriptor is closed once. Caller owns synchronization and kernel K1. */
static inline int diag_sink_write(DiagSink *s,const char *const paths[DIAG_ROUTES],const void *data,unsigned size,DiagOpen open_file,DiagWrite write_file,DiagClose close_file){
 if(!s||!paths||!data||!size||size>DIAG_LINE_LIMIT||!open_file||!write_file||!close_file)return 0;
 unsigned preferred=s->route;
 for(unsigned round=0;round<DIAG_ROUTES;round++){
  unsigned route=preferred<DIAG_ROUTES?(round?round-1+(round-1>=preferred):preferred):round;
  if(!paths[route])continue;
  int fd=open_file(paths[route]);if(fd<0){s->open_error[route]=fd;s->failures++;continue;}
  unsigned done=0;int result=0;
  /* A line is <=256 bytes. Every successful write advances >=1 byte. */
  while(done<size){result=write_file(fd,(const unsigned char *)data+done,size-done);if(result<=0||(unsigned)result>size-done)break;done+=(unsigned)result;}
  int closed=close_file(fd);
  if(done==size&&closed>=0){s->route=route;return 1;}
  s->failures++;if(done!=size)s->write_error=result<0?result:-1;if(closed<0)s->close_error=closed;
 }
 s->route=DIAG_NO_ROUTE;return 0;
}
#define DIAG_MARKER_SIZE (sizeof("PSPGo HID v0.47 started stage=0 worker=0\n")-1u)
static inline unsigned diag_marker_line(char *out,unsigned capacity,unsigned stage,unsigned worker){
 if(!out||capacity<DIAG_MARKER_SIZE)return 0;
 static const char base[]="PSPGo HID v0.47 started stage=0 worker=0\n",hex[]="0123456789abcdef";
 memcpy(out,base,DIAG_MARKER_SIZE);
 out[sizeof("PSPGo HID v0.47 started stage=")-1]=hex[stage&15];
 out[sizeof("PSPGo HID v0.47 started stage=0 worker=")-1]=hex[worker>15?15:worker];
 return DIAG_MARKER_SIZE;
}
#endif
