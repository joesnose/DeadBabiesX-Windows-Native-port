#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p tests/build
flags='-std=gnu11 -Wall -Wextra -Werror -Wno-misleading-indentation -g -fsanitize=address,undefined -fno-omit-frame-pointer'
cc $flags tests/test_core.c src/hci_core.c -o tests/build/test_core
cc $flags -Itests tests/test_transport.c src/hci_core.c -o tests/build/test_transport
ASAN_OPTIONS=detect_leaks=0 tests/build/test_core
ASAN_OPTIONS=detect_leaks=0 tests/build/test_transport
cc $flags -Isrc tests/test_ds4.c src/ds4_report.c -o tests/build/test_ds4
cc $flags tests/test_store.c -o tests/build/test_store
ASAN_OPTIONS=detect_leaks=0 tests/build/test_ds4
ASAN_OPTIONS=detect_leaks=0 tests/build/test_store
bt=vendor/btstack
sources=''
for n in ad_parser btstack_memory btstack_memory_pool btstack_linked_list btstack_run_loop btstack_util btstack_tlv hci hci_cmd hci_dump hci_event hci_event_builder l2cap l2cap_signaling; do
 sources="$sources $bt/src/$n.c"
done
for n in hid_host sdp_client sdp_util; do sources="$sources $bt/src/classic/$n.c"; done
cc $flags -I. -Itests -Isrc -I$bt/src -I$bt/platform/embedded tests/test_host.c src/ds4_report.c $sources $bt/platform/embedded/btstack_run_loop_embedded.c -o tests/build/test_host
ASAN_OPTIONS=detect_leaks=0 tests/build/test_host
cc $flags -Itests tests/test_input.c -o tests/build/test_input
ASAN_OPTIONS=detect_leaks=0 tests/build/test_input
