# GameStick transition lifecycle isolation, 2026-11-10

User confirms report3 fix yields working VSH controls and game controls when
powered on after game boot. A live GameStick hangs entry/exit; Zeemote does not.
Latest log has no GAME startup banner after the failed launch. This points to
transition/early connection lifecycle but does not locate an instruction.

GameStick also registers native virtual keyboard/mouse interfaces. Those
initializers create SceInput devices whose term handlers unregister them;
the adapter only owned its gamepad previously. v0.29 tests omitting those
unneeded local registrations for the exact observed232-byte descriptor and
0f0d:1011 identity. It does not claim their teardown is proven responsible.

Guarded native tables add type1/2 init/report/term wrappers. The shared native
callback contract forwards four init/report args and two term args. Six
original table pointers and12 function-entry words/masks are checked before
any patch; existing type3/DS3/descriptor guards remain. Sony retains linked
node allocation and release. Report IDs on auxiliary nodes remain intact,
so numbered composite dispatch still reaches the owned report3 gamepad.

Reserve three bounded ownership entries first. Matching empty keyboard/mouse
nodes become owned without native input allocations; their reports are
ignored and only those owned nodes skip native resource cleanup. The gamepad
uses its reserved owner and existing decoder. Unexpected resources, capacity,
identity or descriptor uses native callbacks; no initialized device cleanup
is bypassed. Reserved unused entries clear on gamepad term even if metadata
was evicted; assigned auxiliary ownership survives reordered term until its
own callback releases it. Module-loss invalidation clears the registry.

Tests cover the full lifecycle and native passthrough, exact descriptor and
all new guard mutations. Fifteen sanitizer programs and PSP compiled checks
pass. The helper report frame24 is restored before native tail call; outer
report wrappers have no frames. No file I/O, export lookup or installer calls
run on the native report path. Main report stack budget remains separately
checked. Exact transition cause, hardware fix and USB behavior are unverified.

Own code/factual notes/static protocol metadata only; no native firmware,
disassembly, private logs, addresses, keys or raw auxiliary input data.
