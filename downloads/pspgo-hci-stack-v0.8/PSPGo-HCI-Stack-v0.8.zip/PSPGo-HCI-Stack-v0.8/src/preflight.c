/* Bounded RAM test matrix. Original implementation, MIT. */
#ifdef HCI_SUITE_HOST_TEST
#include "mock_platform.h"
#else
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsdk.h>
#include <systemctrl.h>
#endif
#include "host.h"
#include "store_query.h"
#include "ram_suite.h"
typedef struct {uint16_t id,length;const void *data;} Request;
typedef struct {uint16_t id,length,status,reserved;void *data;} Response;
#ifndef HCI_SUITE_HOST_TEST
_Static_assert(sizeof(Request)==8&&sizeof(Response)==12,"native transaction ABI");
#endif
#define SUITE_ONCE "ef0:/seplugins/pspgo_ramsuite_v08.once"
#define SUITE_STATE "ef0:/seplugins/pspgo_ramsuite_v08.state"
static int (*query)(const Request *,Response *);
static unsigned sequence=1;
/* File read: 1 exact record, 0 absent, -1 invalid/unreadable. */
static int read_file(const char *path,void *out,unsigned length){
 int k1=pspSdkSetK1(0);SceUID fd=sceIoOpen(path,PSP_O_RDONLY,0);
 if(fd<0){pspSdkSetK1(k1);if(fd!=(int)0x80010002)hci_log("SUITE file error %s=%08x\n",path,(unsigned)fd);return fd==(int)0x80010002?0:-1;}
 int n=sceIoRead(fd,out,length);uint8_t extra;int tail=sceIoRead(fd,&extra,1);int closed=sceIoClose(fd);pspSdkSetK1(k1);
 return n==(int)length&&tail==0&&closed>=0?1:-1;
}
static int create_file(const char *path,const void *data,unsigned length){
 int k1=pspSdkSetK1(0);SceUID fd=sceIoOpen(path,PSP_O_WRONLY|PSP_O_CREAT|PSP_O_EXCL,0600);
 if(fd<0){pspSdkSetK1(k1);return -1;}int ok=sceIoWrite(fd,data,length)==(int)length;
 if(sceIoClose(fd)<0)ok=0;if(sceIoSync("ef0:",0)<0)ok=0;pspSdkSetK1(k1);return ok?0:-1;
}
static int transact(const uint16_t tx[25],unsigned bytes,uint16_t rx[25]){
 Request request={0x70,(uint16_t)bytes,tx};Response response={0x170,50,0xffff,0,rx};memset(rx,0xa5,50);
 int k1=pspSdkSetK1(0);int result=query(&request,&response);pspSdkSetK1(k1);
 hci_log("SUITE native=%08x outer=%04x response_capacity=50 copied_extent_unknown\n",(unsigned)result,response.status);
 if(tx[0]==2){
  hci_log("SUITE ACK buffer[0..4]=%04x %04x %04x %04x %04x\n",rx[0],rx[1],rx[2],rx[3],rx[4]);
  hci_log("SUITE ACK buffer[5..8]=%04x %04x %04x %04x (a5a5=prefill)\n",rx[5],rx[6],rx[7],rx[8]);
 }
 if(result<0)return -2;if(response.status)return response.status==0x50?1:-2;return 0;
}
static int meta(RamOp op,unsigned *value){
 uint16_t tx[25] __attribute__((aligned(4))),rx[25] __attribute__((aligned(4)));unsigned seq=sequence++,status;
 ram_request(op,seq,tx);hci_log("SUITE metadata op=%u GET begin seq=%u\n",op,seq);
 int r=transact(tx,50,rx);if(r)return r;r=ram_response(op,seq,rx,50,value,&status);
 if(r==0)hci_log("SUITE metadata value=%04x\n",*value);return r==1?2:r;
}
static int key_op(unsigned key,SuiteOp op,unsigned *value){
 SuitePacket q;uint16_t tx[25] __attribute__((aligned(4))),rx[25] __attribute__((aligned(4)));unsigned status=0;
 if(suite_request(key,op,sequence++,&q)<0)return -1;memcpy(tx,q.words,50);
 hci_log("SUITE key=%04x op=%u %s store=%04x native_bytes=%u words=%u seq=%u begin\n",key,op,op>=SU_PADDED?"SET value1":"GET",tx[7],q.bytes,tx[1],tx[2]);
 int r=transact(tx,q.bytes,rx);if(r)return r;r=suite_response(&q,rx,50,value,&status);
 hci_log("SUITE parsed=%d status=%04x value=%04x (SET payload not used)\n",r,status,op>=SU_PADDED?0:*value);return r;
}
static int baseline(unsigned key){
 unsigned d=0,p=0,r=0;int a=key_op(key,SU_DEFAULT,&d),b=key_op(key,SU_PSI,&p),c=key_op(key,SU_ROM,&r);
 int ok=!a&&!b&&!c&&d==1&&p==1&&r==0;hci_log("SUITE baseline key=%04x ok=%d\n",key,ok);return ok;
}
static void suite_session(void){
 static const uint8_t token[8]={'R','A','M','8',0xc0,3,8,1};const unsigned keys[]={0x3c0,0x3cc};
 hci_log("RAM SUITE v0.8: 2 keys x 3 bounded BCCMD frame forms; same-value1/store8 only\n");
 unsigned build=0,type=0;if(meta(RAM_BUILD,&build)||meta(RAM_MEMORY_TYPE,&type)||build!=0x1918||type!=2){hci_log("SUITE STOP: build/transient RAM prerequisite failed; no SET\n");return;}
 uint8_t marker[8],state[12];int once=read_file(SUITE_ONCE,marker,8),saved=read_file(SUITE_STATE,state,12);
 if(once<0||saved<0||(once==1&&memcmp(marker,token,8))||(saved==1&&!suite_state_valid(state))){hci_log("SUITE STOP: invalid/unreadable state; no SET\n");return;}
 if(once==1){
  hci_log("SUITE FOLLOWUP: no writes repeated; saved_summary=%d\n",saved);
  for(unsigned k=0;k<2;k++){
   unsigned v=0;int b=baseline(keys[k]);int r=key_op(keys[k],SU_RAM,&v);
   hci_log("SUITE FOLLOWUP key=%04x previous_seen=%d current_result=%d current_value=%04x baseline_ok=%d\n",keys[k],saved==1?!!(state[5]&(1u<<k)):-1,r,v,b);
  }
  hci_log("SUITE DONE: compare first-run evidence with this observation; no HCI transition\n");return;
 }
 if(saved!=0){hci_log("SUITE STOP: orphan summary; no SET\n");return;}
 for(unsigned k=0;k<2;k++){unsigned v=0;if(!baseline(keys[k])||key_op(keys[k],SU_RAM,&v)!=1){hci_log("SUITE STOP: require known baseline and RAM GET0050 for both keys; no SET\n");return;}}
 if(create_file(SUITE_ONCE,token,8)<0||read_file(SUITE_ONCE,marker,8)!=1||memcmp(marker,token,8)){hci_log("SUITE STOP: durable one-shot marker unavailable; no SET\n");return;}
 unsigned count=0,seen=0,ackmask=0;int stop=0;
 for(unsigned k=0;k<2&&!stop;k++)for(unsigned form=0;form<3&&!stop;form++){
  unsigned before=0,after=0,unused=0;int pre=key_op(keys[k],SU_RAM,&before);
  if(pre!=1&&(pre!=0||before!=1)){hci_log("SUITE STOP: RAM pre-observation failed\n");stop=1;break;}
  int ack=key_op(keys[k],(SuiteOp)(SU_PADDED+form),&unused);count++;if(ack==0)ackmask|=1u<<(k*3+form);
  int readback=key_op(keys[k],SU_RAM,&after);if(readback==0&&after==1)seen|=1u<<k;
  /* Always attempt both key baselines, even after rejected ACK or GET. */
  int b0=baseline(keys[0]),b1=baseline(keys[1]);
  hci_log("SUITE CASE key=%04x form=%u ack=%d pre=%d/%04x readback=%d/%04x prior_value_already_present=%d baselines=%d,%d\n",keys[k],form,ack,pre,before,readback,after,pre==0&&before==1,b0,b1);
  if(!b0||!b1||ack==-2||(readback!=0&&readback!=1)||(readback==0&&after!=1))stop=1;
 }
 suite_state_make(state,count,seen,ackmask);uint8_t verify[12];
 int recorded=create_file(SUITE_STATE,state,12)==0&&read_file(SUITE_STATE,verify,12)==1&&!memcmp(state,verify,12);
 hci_log("SUITE SUMMARY cases=%u observed_RAM_mask=%u validated_ACK_mask=%02x stopped=%d summary_saved=%d\n",count,seen,ackmask,stop,recorded);
 hci_log("SUITE NEXT: one further full power-off/startup, enable Bluetooth, then send this single combined log; no SET repeats\n");
}
#ifndef HCI_SUITE_HOST_TEST
static void ram_preflight(void){
 SceModule *m=sceKernelFindModuleByName("sceBSMan");
 uint32_t r=sctrlHENFindFunction("sceBSMan","sceBSMan",0xed295515);
 uint32_t t=sctrlHENFindFunction("sceBSMan","sceBSMan",0xe1704dee);
 if(!m||!r||!t){hci_log("PREFLIGHT STOP: native management module unavailable\n");return;}
 uint32_t b=m->text_addr;if(m->text_size<0x5ebc||r!=b+0x5ea4||t!=b+0x385c){hci_log("PREFLIGHT STOP: management offsets differ\n");return;}
 uint32_t a[6],p[4];for(unsigned i=0;i<6;i++)a[i]=_lw(r+i*4);for(unsigned i=0;i<4;i++)p[i]=_lw(t+i*4);
 if(!radio_ready_guard(b,a)||!radio_transport_guard(b,p,_lw(b+0x3940),_lw(b+0x3944))){hci_log("PREFLIGHT STOP: management code guard mismatch\n");return;}
 int (*ready)(void)=(void *)(uintptr_t)r;query=(void *)(uintptr_t)t;
 for(unsigned i=0;i<30&&ready()!=1;i++)sceKernelDelayThread(1000000);
 if(ready()!=1){hci_log("PREFLIGHT STOP: management not ready\n");return;}
 suite_session();
}
void pspgo_radio_preflight(void){ram_preflight();}
#endif
