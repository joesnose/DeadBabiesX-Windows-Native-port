/* Original PSP controller merge adapter, MIT. Hooks remain resident until reboot. */
#ifdef ZEE_INPUT_HOST_TEST
#include "zeemote_input_mock.h"
typedef struct {unsigned TimeStamp,Buttons;unsigned char Lx,Ly,Rsrv[6];} SceCtrlData;
void sctrlHENPatchSyscall(void *,void *);
void sceKernelDcacheWritebackAll(void);
void sceKernelIcacheInvalidateAll(void);
#else
#include <pspkernel.h>
#include <pspctrl.h>
#include <systemctrl.h>
#endif
#include <string.h>
#include "zeemote_input.h"
static ZeeState remote;
static unsigned last_ms;
static int active,installed;
static unsigned read_counts[4],merged_samples;
void zee_input_stats(ZeeInputStats *out){if(!out)return;int irq=sceKernelCpuSuspendIntr();out->installed=installed;out->active=active;memcpy(out->reads,read_counts,sizeof(read_counts));out->merged_samples=merged_samples;sceKernelCpuResumeIntr(irq);}
typedef int (*Read)(SceCtrlData *,int);
static Read originals[4];
static unsigned now_ms(void){return (unsigned)(sceKernelGetSystemTimeWide()/1000);}
void zee_input_update(const ZeeState *s){int irq=sceKernelCpuSuspendIntr();remote=*s;last_ms=now_ms();active=1;sceKernelCpuResumeIntr(irq);}
void zee_input_keepalive(void){int irq=sceKernelCpuSuspendIntr();if(active)last_ms=now_ms();sceKernelCpuResumeIntr(irq);}
void zee_input_clear(void){int irq=sceKernelCpuSuspendIntr();active=0;memset(&remote,0,sizeof(remote));sceKernelCpuResumeIntr(irq);}
static int merge(unsigned index,SceCtrlData *p,int count){
 int irq_count=sceKernelCpuSuspendIntr();read_counts[index]++;sceKernelCpuResumeIntr(irq_count);
 int result=originals[index](p,count);if(result<=0||result>count||result>64)return result;
 ZeeState s;int irq=sceKernelCpuSuspendIntr();int valid=active&&(unsigned)(now_ms()-last_ms)<1500;s=remote;sceKernelCpuResumeIntr(irq);
 if(!valid)return result;
 irq=sceKernelCpuSuspendIntr();merged_samples+=(unsigned)result;sceKernelCpuResumeIntr(irq);
 for(int i=0;i<result;i++){
  if(index&1)p[i].Buttons&=~s.buttons;else p[i].Buttons|=s.buttons;
  if(s.lx<112||s.lx>144)p[i].Lx=s.lx;
  if(s.ly<112||s.ly>144)p[i].Ly=s.ly;
 }
 return result;
}
static int peek_pos(SceCtrlData *p,int n){return merge(0,p,n);}
static int peek_neg(SceCtrlData *p,int n){return merge(1,p,n);}
static int read_pos(SceCtrlData *p,int n){return merge(2,p,n);}
static int read_neg(SceCtrlData *p,int n){return merge(3,p,n);}
int zee_input_install(void){
 if(installed)return 0;
 static const unsigned nids[]={0x3a622550,0xc152080a,0x1f803938,0x60b81f86};
 Read hooks[]={peek_pos,peek_neg,read_pos,read_neg};
 for(unsigned i=0;i<4;i++){originals[i]=(Read)sctrlHENFindFunction("sceController_Service","sceCtrl",nids[i]);if(!originals[i])return -1;}
 for(unsigned i=0;i<4;i++)sctrlHENPatchSyscall((void *)originals[i],(void *)hooks[i]);
 sceKernelDcacheWritebackAll();sceKernelIcacheInvalidateAll();installed=1;return 0;
}
