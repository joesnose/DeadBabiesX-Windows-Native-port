/* Experimental PSP Go native registration trace; no firmware binaries included. */
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsysmem_kernel.h>
#include <pspsysclib.h>
#include <pspsdk.h>
#include <systemctrl.h>
#include <stdarg.h>
#include <stdint.h>
#include <string.h>
#include "patch_plan.h"
PSP_MODULE_INFO("PSPGoDS4PairTest",PSP_MODULE_KERNEL,0,7);
#define LOG_PATH "ef0:/seplugins/pspgo_ds4_pair.log"
static STMOD_HANDLER previous_handler;
static uint32_t trampoline[4][4] __attribute__((aligned(16)));
static int (*original_register)(const void *,const void *);
static int (*original_no_pin)(const void *);
static int (*original_profile)(int,void *);
static int (*original_hid_connect)(int,int);
static int resident;
typedef struct {uint32_t base;SceUID block;uint32_t *code;} UiStub;
static UiStub ui_stubs[4];
static unsigned ui_stub_count;
static unsigned profile_lines;
typedef struct {int seen,status,valid;unsigned flags,id;} ProfileState;
static ProfileState profile_states[8];
typedef struct {unsigned length;char data[256];} LogBuffer;
static void format_char(void *ctx,int ch){
 LogBuffer *b=ctx;if(ch==0x200)b->length=0;
 else if(ch>=0&&ch<256&&b->length<sizeof(b->data))b->data[b->length++]=(char)ch;
}
static void log_line(const char *fmt,...){
 int old=pspSdkSetK1(0);LogBuffer b={0,{0}};va_list args;
 va_start(args,fmt);prnt(format_char,&b,fmt,args);va_end(args);
 SceUID fd=sceIoOpen(LOG_PATH,PSP_O_CREAT|PSP_O_WRONLY|PSP_O_APPEND,0666);
 if(fd>=0){if(b.length)sceIoWrite(fd,b.data,b.length);sceIoClose(fd);}
 pspSdkSetK1(old);
}
static void reset_profile_cache(void){
 int irq=sceKernelCpuSuspendIntr();
 for(unsigned i=0;i<8;++i)profile_states[i].seen=0;
 sceKernelCpuResumeIntr(irq);
}
/* Arguments are forwarded unchanged. Never read/log PINs, link keys or device records. */
static int register_trace(const void *device,const void *pin){
 log_line("PIN_REGISTER begin\n");
 int result=original_register(device,pin);
 reset_profile_cache();
 log_line("PIN_REGISTER result=%08x\n",(unsigned)result);
 return result;
}
static void flush_code(void){sceKernelDcacheWritebackInvalidateAll();sceKernelIcacheInvalidateAll();}
static int no_pin_trace(const void *device_address){
 log_line("NO_PIN_REGISTER begin\n");
 int result=original_no_pin(device_address);
 reset_profile_cache();
 log_line("NO_PIN_REGISTER result=%08x\n",(unsigned)result);
 return result;
}
/* The native event worker only copies six bytes into bounded RAM. File I/O
 * runs on the requesting thread after the original synchronous call returns. */
static int (*original_slc_event)(const uint16_t *);
typedef struct {unsigned slot,state,flags,length;} SlcEvent;
static SlcEvent slc_events[16];
static unsigned slc_count,slc_dropped;
static int active_slot;
static int slc_event_trace(const uint16_t *body){
 uintptr_t a=(uintptr_t)body,phys=a&0x1fffffffu;
 unsigned alias=a&0xe0000000u;
 int irq=sceKernelCpuSuspendIntr();
 if(active_slot && !(a&1) && (alias==0||alias==0x80000000u||alias==0xa0000000u) &&
    phys>=0x08000004u && phys<=0x0c000000u-6 && body[-2]==0x263 &&
    body[-1]>=6 && body[-1]<=80 && body[0]==active_slot && (body[2]&2)){
  if(slc_count<16){SlcEvent *e=&slc_events[slc_count++];
   e->slot=body[0];e->state=body[1];e->flags=body[2];e->length=body[-1];
  }else ++slc_dropped;
 }
 sceKernelCpuResumeIntr(irq);
 return original_slc_event(body);
}
static int hid_connect_trace(int index,int mode){
 log_line("HID_CONNECT begin slot=%d mode=%d\n",index,mode);
 int irq=sceKernelCpuSuspendIntr();
 /* One XMB request is expected. A concurrent request is forwarded untraced. */
 int trace=index>=1 && index<=8 && !active_slot;
 if(trace){active_slot=index;slc_count=0;slc_dropped=0;}
 sceKernelCpuResumeIntr(irq);
 int result=original_hid_connect(index,mode);
 SlcEvent events[16];unsigned count=0,dropped=0;
 irq=sceKernelCpuSuspendIntr();
 if(trace){active_slot=0;count=slc_count;dropped=slc_dropped;
  memcpy(events,slc_events,count*sizeof(events[0]));}
 sceKernelCpuResumeIntr(irq);
 for(unsigned i=0;i<count;++i)log_line("SLC_EVENT slot=%u state=%u flags=%04x length=%u\n",
   events[i].slot,events[i].state,events[i].flags,events[i].length);
 if(trace)log_line("SLC_TRACE events=%u dropped=%u\n",count,dropped);
 reset_profile_cache();
 log_line("HID_CONNECT result=%08x\n",(unsigned)result);
 return result;
}
static int profile_trace(int index,void *record){
 int result=original_profile(index,record);
 if(index>=1 && index<=8){
  unsigned flags=0,id=0;int valid=0;
  uintptr_t address=(uintptr_t)record,physical=address&0x1fffffffu;
  unsigned alias=address&0xe0000000u;
  int irq=sceKernelCpuSuspendIntr();
  if(result>=0 && !(address&3) &&
     (alias==0 || alias==0x80000000u || alias==0xa0000000u) &&
     physical>=0x08000000u && physical<=0x0c000000u-80 && _lw(address)==0x50){
   const uint8_t *p=record;id=p[4]|((unsigned)p[5]<<8);
   flags=p[72]|((unsigned)p[73]<<8);valid=1;
  }
  ProfileState *old=&profile_states[index-1];
  int changed=!old->seen || old->status!=result || old->valid!=valid || old->flags!=flags || old->id!=id;
  old->seen=1;old->status=result;old->valid=valid;old->flags=flags;old->id=id;
  int emit=changed && profile_lines<64;if(emit)++profile_lines;
  sceKernelCpuResumeIntr(irq);
  if(emit)log_line("PROFILE slot=%d result=%08x metadata=%d id=%u flags=%04x\n",index,(unsigned)result,valid,id,flags);
 }
 return result;
}
static void install_trace(HookKind kind,uint32_t nid,uint32_t hook,const char *label){
 SceModule *mod=sceKernelFindModuleByName("sceBSMan");
 uint32_t entry=sctrlHENFindFunction("sceBSMan","sceBSMan",nid);
 if(!mod || !entry || mod->text_size<12 || entry<mod->text_addr ||
    entry-mod->text_addr>mod->text_size-12 || (entry&3)){
  log_line("%s hook skipped: export unavailable or outside module\n",label);return;
 }
 int irq=sceKernelCpuSuspendIntr();
 const uint32_t original[]={_lw(entry),_lw(entry+4)};HookPlan plan;
 int valid=native_hook_plan(entry,hook,(uint32_t)(uintptr_t)trampoline[kind],
                            original,kind,mod->text_addr,&plan)==0;
 if(valid){
  memcpy(trampoline[kind],plan.trampoline,sizeof(trampoline[kind]));
  if(kind==HOOK_PIN)original_register=(void *)trampoline[kind];
  else if(kind==HOOK_NO_PIN)original_no_pin=(void *)trampoline[kind];
  else if(kind==HOOK_PROFILE)original_profile=(void *)trampoline[kind];
  else original_hid_connect=(void *)trampoline[kind];
  _sw(plan.entry[0],entry);_sw(plan.entry[1],entry+4);flush_code();resident=1;
 }
 sceKernelCpuResumeIntr(irq);
 if(valid)log_line("%s hook installed at module+%08x\n",label,entry-mod->text_addr);
 else log_line("%s hook skipped: prologue mismatch %08x %08x\n",label,original[0],original[1]);
}
static void install_slc_trace(void){
 SceModule *mod=sceKernelFindModuleByName("sceBSMan");uint32_t word;
 if(!mod || mod->text_size<0x204c){log_line("SLC_TRACE skipped: module unavailable\n");return;}
 uint32_t base=mod->text_addr,site=base+0xa24;
 int irq=sceKernelCpuSuspendIntr();
 int valid=slc_call_plan(base,(uint32_t)(uintptr_t)slc_event_trace,
  _lw(site),_lw(site+4),_lw(site+8),_lw(base+0x2044),_lw(base+0x2048),&word)==0;
 if(valid){original_slc_event=(void *)(uintptr_t)(base+0x2044);
  _sw(word,site);flush_code();resident=1;}
 sceKernelCpuResumeIntr(irq);
 log_line(valid?"SLC_TRACE event call installed\n":"SLC_TRACE skipped: firmware context mismatch\n");
}
static void patch_discovery(SceModule *mod){
 const unsigned load_offset=0x13d40,compare_offset=0x13d6c;
 if(mod->text_size<compare_offset+4){log_line("DISCOVERY skipped: module too small\n");return;}
 int irq=sceKernelCpuSuspendIntr();
 uint32_t first=_lw(mod->text_addr+load_offset),second=_lw(mod->text_addr+compare_offset);
 int valid=discovery_patch_allowed(first,second);
 if(valid){
  _sw(0x240effffu,mod->text_addr+load_offset);
  _sw(0x144e0003u,mod->text_addr+compare_offset);flush_code();
 }
 sceKernelCpuResumeIntr(irq);
 if(valid)log_line("DISCOVERY filter lifted in RAM; select only your DS4 for this test\n");
 else if(first==0x240effffu&&second==0x144e0003u)log_line("DISCOVERY filter already lifted\n");
 else log_line("DISCOVERY skipped: instruction mismatch %08x %08x\n",first,second);
}
static uint32_t jump_target(uint32_t pc,uint32_t word){
 return ((pc+4)&0xf0000000u)|((word&0x03ffffffu)<<2);
}
static int hid_context_matches(SceModule *mod){
 uint32_t base=mod->text_addr;
 if(mod->text_size<0x20c2c)return 0;
 uint32_t call=_lw(base+0x14ec0),hi=_lw(base+0x14ec8),lo=_lw(base+0x14ecc);
 uint32_t table=((hi&0xffffu)<<16)+(int16_t)lo;
 return _lw(base+0x14e18)==0x00a09021u && /* move s2,a1 */
        _lw(base+0x14e2c)==0x8e110004u && /* lw s1,4(s0) */
        _lw(base+0x14e38)==0x94a20048u && /* lhu v0,72(a1) */
        _lw(base+0x14e50)==0x24020001u &&
        call>>26==3 && jump_target(base+0x14ec0,call)==base+0x1abe0 &&
        _lw(base+0x14ec4)==0 && (hi&0xffff0000u)==0x3c030000u &&
        (lo&0xffff0000u)==0x24630000u && table==base+0x20c28;
}
static void patch_hid_menu(SceModule *mod){
 uint32_t base=mod->text_addr,site=base+0x14eb8;
 if(!hid_context_matches(mod)){log_line("HID_MENU skipped: firmware context mismatch\n");return;}
 UiStub *stub=NULL;
 for(unsigned i=0;i<ui_stub_count;++i)if(ui_stubs[i].base==base)stub=&ui_stubs[i];
 if(!stub){
  if(ui_stub_count>=4){log_line("HID_MENU skipped: user-stub limit reached\n");return;}
  int old_k1=pspSdkSetK1(0);
  SceUID block=sceKernelAllocPartitionMemory(2,"DS4HidMenu",PSP_SMEM_Low,56,NULL);
  uint32_t *code=block>=0?sceKernelGetBlockHeadAddr(block):NULL;
  uintptr_t address=(uintptr_t)code;
  int usable=code && !(address&3) && address>=0x08800000u && address<=0x0c000000u-56;
  if(block>=0 && !usable)sceKernelFreePartitionMemory(block);
  pspSdkSetK1(old_k1);
  if(block<0){log_line("HID_MENU skipped: user memory allocation %08x\n",block);return;}
  if(!usable){log_line("HID_MENU skipped: no valid user memory address\n");return;}
  stub=&ui_stubs[ui_stub_count++];stub->base=base;stub->block=block;stub->code=code;
 }
 int irq=sceKernelCpuSuspendIntr();
 uint32_t branch=_lw(site),delay=_lw(site+4);HidMenuPlan plan;
 int valid=hid_context_matches(mod)&&hid_menu_plan(site,(uint32_t)(uintptr_t)stub->code,branch,delay,&plan)==0;
 int already=branch>>26==2 && jump_target(site,branch)==(uint32_t)(uintptr_t)stub->code && delay==0x24040004u;
 if(valid){
  memcpy(stub->code,plan.code,sizeof(plan.code));_sw(plan.entry,site);flush_code();
 }
 sceKernelCpuResumeIntr(irq);
 if(valid)log_line("HID_MENU initial connection action enabled for type 2 with native HID flag\n");
 else if(already)log_line("HID_MENU already patched for this module\n");
 else log_line("HID_MENU skipped: branch/delay mismatch %08x %08x\n",branch,delay);
}
static int module_started(SceModule *mod){
 if(mod&&!strcmp(mod->modname,"bluetooth_plugin_module")){patch_discovery(mod);patch_hid_menu(mod);}
 return previous_handler?previous_handler(mod):0;
}
int module_start(SceSize args,void *argp){
 (void)args;(void)argp;
 unsigned fw=sceKernelDevkitVersion();int model=sceKernelGetModel();
 log_line("\nPSPGo DS4 native pairing test 0.7 model=%d devkit=%08x\n",model,fw);
 if(model!=4||(fw!=0x06060010&&fw!=0x06060110)){
  log_line("UNSUPPORTED model/firmware; no patches installed\n");return -1;
 }
 install_trace(HOOK_PIN,0x8ac2f7b8u,(uint32_t)(uintptr_t)register_trace,"PIN_REGISTER");
 install_trace(HOOK_NO_PIN,0x2d649923u,(uint32_t)(uintptr_t)no_pin_trace,"NO_PIN_REGISTER");
 install_trace(HOOK_PROFILE,0xcbd232d1u,(uint32_t)(uintptr_t)profile_trace,"PROFILE");
 install_trace(HOOK_HID_CONNECT,0xf188a405u,(uint32_t)(uintptr_t)hid_connect_trace,"HID_CONNECT");
 install_slc_trace();
 previous_handler=sctrlHENSetStartModuleHandler(module_started);resident=1;
 SceModule *mod=sceKernelFindModuleByName("bluetooth_plugin_module");
 if(mod){patch_discovery(mod);patch_hid_menu(mod);}
 log_line("READY: pairing experiment only; native report decoding unchanged\n");
 return 0;
}
int module_stop(SceSize args,void *argp){
 (void)args;(void)argp;
 /* Keep hook code resident. Disabling the entry and rebooting clears RAM patches. */
 if(resident)return -1;
 return 0;
}
