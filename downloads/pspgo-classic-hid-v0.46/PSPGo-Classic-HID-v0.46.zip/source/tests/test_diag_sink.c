#include <assert.h>
#include <stdio.h>
#include "diag_sink.h"
static const char *const paths[4]={"ef0_dir","ef0_root","ms0_dir","ms0_root"};
static int available[4],open_calls[4],close_calls[4],write_calls[4],fail_write[4],fail_close[4],chunk[4],fd0;
static unsigned bytes[4];static unsigned char file[4][512];
static int open_mock(const char *path){
 for(int i=0;i<4;i++)if(path==paths[i]){open_calls[i]++;return available[i]?i+fd0:-100-i;}
 assert(!"unknown path");return -1;
}
static int write_mock(int fd,const void *data,unsigned size){
 int at=fd-fd0;assert(at>=0&&at<4);write_calls[at]++;
 if(fail_write[at])return fail_write[at]==1?0:fail_write[at]==2?(int)size+1:-200-at;
 unsigned n=chunk[at]&&(unsigned)chunk[at]<size?(unsigned)chunk[at]:size;
 assert(bytes[at]+n<=sizeof(file[at]));memcpy(file[at]+bytes[at],data,n);bytes[at]+=n;return (int)n;
}
static int close_mock(int fd){int at=fd-fd0;assert(at>=0&&at<4);close_calls[at]++;return fail_close[at]?-300-at:0;}
static void reset(void){memset(available,0,sizeof(available));memset(open_calls,0,sizeof(open_calls));memset(close_calls,0,sizeof(close_calls));memset(write_calls,0,sizeof(write_calls));memset(fail_write,0,sizeof(fail_write));memset(fail_close,0,sizeof(fail_close));memset(chunk,0,sizeof(chunk));memset(bytes,0,sizeof(bytes));memset(file,0,sizeof(file));fd0=0;}
static int line(DiagSink *s){return diag_sink_write(s,paths,"test\n",5,open_mock,write_mock,close_mock);}
int main(void){
 DiagSink s;reset();diag_sink_init(&s);available[0]=1;assert(line(&s)&&s.route==0&&!s.failures&&bytes[0]==5&&close_calls[0]==1);assert(!memcmp(file[0],"test\n",5));
 reset();diag_sink_init(&s);available[2]=1;assert(line(&s)&&s.route==2&&s.failures==2&&s.open_error[0]==-100&&s.open_error[1]==-101&&close_calls[2]==1);
 memset(open_calls,0,sizeof(open_calls));assert(line(&s)&&open_calls[2]==1&&!open_calls[0]&&!open_calls[1]&&!open_calls[3]); /* keep successful route */
 reset();diag_sink_init(&s);assert(!line(&s)&&s.route==DIAG_NO_ROUTE&&s.failures==4);for(unsigned i=0;i<4;i++)assert(open_calls[i]==1&&!close_calls[i]);
 available[3]=1;assert(line(&s)&&s.route==3); /* filesystem becomes ready later */
 for(unsigned route=0;route<4;route++){
  reset();diag_sink_init(&s);s.route=route;available[(route+1)%4]=1;
  assert(line(&s)&&s.route==(route+1)%4);for(unsigned i=0;i<4;i++)assert(open_calls[i]<=1);
 }
 for(unsigned failure=1;failure<4;failure++){
  reset();diag_sink_init(&s);available[0]=available[1]=1;fail_write[0]=failure;
  assert(line(&s)&&s.route==1&&close_calls[0]==1&&close_calls[1]==1&&s.failures==1&&s.write_error<0&&bytes[1]==5);
 }
 reset();diag_sink_init(&s);available[0]=available[1]=1;fail_close[0]=1;
 assert(line(&s)&&s.route==1&&s.close_error==-300&&close_calls[0]==1&&close_calls[1]==1);
 reset();diag_sink_init(&s);available[0]=1;chunk[0]=1;assert(line(&s)&&write_calls[0]==5&&close_calls[0]==1&&bytes[0]==5&&!memcmp(file[0],"test\n",5));
 reset();diag_sink_init(&s);available[0]=1;fd0=11;assert(line(&s)&&s.route==0); /* nonzero descriptors */
 const char *empty[4]={0};assert(!diag_sink_write(&s,empty,"a",1,open_mock,write_mock,close_mock));
 assert(!diag_sink_write(NULL,paths,"a",1,open_mock,write_mock,close_mock));assert(!diag_sink_write(&s,paths,NULL,1,open_mock,write_mock,close_mock));
 assert(!diag_sink_write(&s,paths,"a",0,open_mock,write_mock,close_mock));assert(!diag_sink_write(&s,paths,"a",257,open_mock,write_mock,close_mock));
 char marker[DIAG_MARKER_SIZE+1];memset(marker,0xa5,sizeof(marker));
 assert(diag_marker_line(marker,DIAG_MARKER_SIZE,4,1)==DIAG_MARKER_SIZE);
 assert(!memcmp(marker,"PSPGo HID v0.46 started stage=4 worker=1\n",DIAG_MARKER_SIZE)&&(unsigned char)marker[DIAG_MARKER_SIZE]==0xa5);
 assert(!diag_marker_line(marker,DIAG_MARKER_SIZE-1,0,0)&&!diag_marker_line(NULL,DIAG_MARKER_SIZE,0,0));
 puts("PASS: ef0/ms0 directory/root fallback, descriptor0, bounded route probes, all-storage failure/recovery, short/zero/error/oversized writes, close errors, route preference and raw version/stage marker bounds");
}
