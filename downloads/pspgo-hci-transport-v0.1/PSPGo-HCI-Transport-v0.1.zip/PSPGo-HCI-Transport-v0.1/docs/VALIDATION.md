# Validation — 2026-11-08 UTC

PASS: PSP GCC 15.2 compile, link, import fixup and PRX generation with
`-Wall -Wextra -Werror` (dense-layout misleading-indentation warning disabled).
No unresolved link symbols. Native host calls are resolved at runtime.

PASS: host AddressSanitizer/UBSan tests, leak sanitizer disabled because the
execution sandbox does not support its process inspection. Tests cover:

- Standard primary HCI descriptor acceptance and CDC/secondary-interface rejection.
- Required endpoint routing, duplicate/invalid endpoint rejection.
- Every split boundary of a five-byte event and 1028-byte maximum ACL packet.
- Coalesced events, retained packets when caller capacity is too small, malformed
  lengths and input overflow rejection.
- Kernel API packet validation, control request fields, bulk/interrupt routing.
- Immediate completion, submission error, read timeout and synchronous cancel.
- Busy ownership, disconnect before submission, disconnect during a pending read,
  reconnect after ownership releases, failed-cancel buffer quarantine.

Not tested: PSP module loading/registration, native calling conventions, real
USB DMA/cache coherence, native interrupt/abort timing, suspend/resume, radio mode
transition/recovery, Bluetooth authentication, DS4 connection or controls.
The tests are synchronous deterministic mocks, not concurrency stress tests.
