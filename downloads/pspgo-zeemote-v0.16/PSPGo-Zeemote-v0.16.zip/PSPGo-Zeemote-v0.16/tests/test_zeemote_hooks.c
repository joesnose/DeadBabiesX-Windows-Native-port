#include "../src/zeemote_hid.c"
#define ZEE_HOOK_HOST_TEST
#include "../src/zeemote_hooks.c"
#define main descriptor_test_main
#include "zeemote_descriptor_fixture.h"
#undef main
#include <stdarg.h>
static unsigned updates,clears,parse_calls,init_calls,report_calls,term_calls,install_calls,logs;
static int parse_result,init_result,terminate_during_install,input_active;static unsigned keepalive_calls;static SceModule *live_module;static ZeeState injected;
static uint8_t node[0x160];static void *ctx=(void *)(uintptr_t)0x88001000;
int sceKernelCpuSuspendIntr(void){return 0;}void sceKernelCpuResumeIntr(int n){(void)n;}
static uint32_t memory[0x5000/4];static uint32_t base=0x8822f800;
uint32_t _lw(uint32_t address){assert(address>=base&&address<base+sizeof(memory));return memory[(address-base)/4];}
void _sw(uint32_t value,uint32_t address){assert(address>=base&&address<base+sizeof(memory));memory[(address-base)/4]=value;}
void sceKernelDcacheWritebackInvalidateAll(void){}void sceKernelIcacheInvalidateAll(void){}
int zee_input_install(void){install_calls++;if(terminate_during_install){terminate_during_install=0;terminate(ctx,node);}return 0;}
void zee_input_update(const ZeeState *s){updates++;injected=*s;input_active=1;}void zee_input_clear(void){clears++;input_active=0;}
void zee_input_keepalive(void){keepalive_calls++;}
SceModule *sceKernelFindModuleByName(const char *name){assert(!strcmp(name,"sceHIDSvc"));return live_module;}
static int parse(void *c,const uint8_t *d,unsigned n){assert(c==ctx&&d==descriptor&&n==sizeof(descriptor));parse_calls++;return parse_result;}
static int init(void *c,void *p,const uint16_t *id,unsigned flags){assert(c==ctx&&p==node&&flags==123);assert(id);init_calls++;return init_result;}
static int report(void *c,void *p,const uint8_t *d,unsigned n){assert(c==ctx&&p==node&&d&&n<=65);report_calls++;return 77;}
static int term(void *c,void *p){assert(c==ctx&&p==node);term_calls++;return 88;}
static void log_mock(const char *fmt,...){assert(fmt);logs++;}
static void reset(void){memset(entries,0,sizeof(entries));memset(&counters,0,sizeof(counters));memset(&printed,0,sizeof(printed));generation=init_serial=reported_serial=installed_base=0;parse_result=init_result=input_active=0;keepalive_calls=0;live_module=NULL;updates=clears=parse_calls=init_calls=report_calls=term_calls=install_calls=logs=0;memset(node,0,sizeof(node));node[0]=3;original_parse=parse;original_init=init;original_report=report;original_term=term;}
static void authorize(uint16_t vendor,uint16_t product){uint16_t id[]={product,vendor};assert(!descriptor_capture(ctx,descriptor,sizeof(descriptor)));assert(!initialize(ctx,node,id,123));}
int main(void){
 reset();uint8_t r[]={7,1,0,0,255,128,128,8};assert(receive_report(ctx,node,r,8)==77&&!updates);
 authorize(0x1038,0x1412);assert(parse_calls==1&&init_calls==1&&entries[0].authorized);assert(receive_report(ctx,node,r,8)==77&&updates==1&&injected.buttons==0x4000&&injected.lx==0&&injected.ly==255);assert(!logs);
 node[1]=7;assert(receive_report(ctx,node,r+1,7)==77&&updates==2);node[1]=0;assert(receive_report(ctx,node,r+1,7)==77&&updates==2&&clears==1);
 assert(terminate(ctx,node)==88&&term_calls==1&&!entries[0].present);assert(receive_report(ctx,node,r,8)==77&&updates==2);
 reset();authorize(0x054c,0x0268);receive_report(ctx,node,r,8);assert(!updates&&!install_calls);
 reset();authorize(0x1038,0x1413);receive_report(ctx,node,r,8);assert(!updates&&!install_calls);
 reset();parse_result=-9;uint16_t ids[]={0x1412,0x1038};descriptor_capture(ctx,descriptor,sizeof(descriptor));initialize(ctx,node,ids,123);receive_report(ctx,node,r,8);assert(!updates);
 reset();authorize(0x1038,0x1412);terminate_during_install=1;receive_report(ctx,node,r,8);assert(!updates&&!entries[0].authorized); /* generation recheck after syscall hook install */
 reset();authorize(0x1038,0x1412);node[0]=4;receive_report(ctx,node,r,8);assert(!updates); /* never steal DS3 reports */
 zeemote_input_log_tick(log_mock);assert(logs);unsigned prior=logs;zeemote_input_log_tick(log_mock);assert(logs==prior);
 reset();
 for(unsigned i=0;i<9;i++){ctx=(void *)(uintptr_t)(0x88001000+i*0x100);descriptor_capture(ctx,descriptor,sizeof(descriptor));assert(find(ctx));}
 assert(!counters.capacity);authorize(0x1038,0x1412);Entry *protected=find(ctx);unsigned protected_generation=protected->generation;
 for(unsigned i=0;i<9;i++){ctx=(void *)(uintptr_t)(0x88101000+i*0x100);descriptor_capture(ctx,descriptor,sizeof(descriptor));}
 assert(protected->authorized&&protected->generation==protected_generation&&!counters.capacity);
 reset();ctx=(void *)(uintptr_t)0x88001000;authorize(0x1038,0x1412);receive_report(ctx,node,r,8);
 SceModule lifecycle={"sceHIDSvc",base,0x4ec4};live_module=&lifecycle;installed_base=base;assert(input_active&&updates==1);
 zeemote_input_log_tick(log_mock);assert(keepalive_calls==1&&input_active&&updates==1); /* no synthetic input report */
 receive_report(ctx,node,r+1,7);assert(!input_active);zeemote_input_log_tick(log_mock);assert(!input_active&&updates==1);
 receive_report(ctx,node,r,8);assert(input_active&&updates==2);unsigned kept=keepalive_calls;live_module=NULL;zeemote_input_log_tick(log_mock);assert(!input_active&&!entries[0].authorized&&!entries[0].present&&keepalive_calls==kept);
 live_module=&lifecycle;zeemote_input_log_tick(log_mock);assert(!input_active&&updates==2&&keepalive_calls==kept); /* module reappearance does not recreate session */
 reset();authorize(0x1038,0x1412);receive_report(ctx,node,r,8);installed_base=base;live_module=&lifecycle;lifecycle.text_addr=base+4;zeemote_input_log_tick(log_mock);assert(!input_active&&!entries[0].authorized&&!keepalive_calls);
 /* Installer context guards are exercised against a mock module image.
  * Host function alignment flag makes its synthetic JAL target representable. */
 base=((uint32_t)(uintptr_t)descriptor_capture&0xf0000000u)|0x0222f800u;
 const uint32_t offs[]={0x908,0x90c,0x904,0x8f4,0x8f8,0x4e64,0x4e68,0x4e4c,0x4e50,0x4e78,0x4e7c,0x4054,0x4058,0x3cc0,0x3cc4};uint32_t j;assert(jump(base+0x908,base+0x1000,&j));
 uint32_t words[]={j,0x02402021,0x27a50018,0x8fa60014,0x2cc70201,base+0x3cc0,base+0x3cc0,base+0x4054,base+0x4054,base+0x3fd0,base+0x3fd0,0x90a30000,0x27bdfff0,0x27bdffb0,0xafb40040};
 SceModule module={"sceHIDSvc",base,0x4ec4};
 for(unsigned bad=0;bad<sizeof(offs)/sizeof(offs[0]);bad++){
  installed_base=0;memset(memory,0,sizeof(memory));for(unsigned i=0;i<sizeof(offs)/sizeof(offs[0]);i++)_sw(words[i],base+offs[i]);_sw(words[bad]^1,base+offs[bad]);
  uint32_t prior[sizeof(memory)/4];memcpy(prior,memory,sizeof(memory));assert(zeemote_input_install_module(&module,NULL)<0);assert(!memcmp(prior,memory,sizeof(memory)));
 }
 installed_base=0;memset(memory,0,sizeof(memory));for(unsigned i=0;i<sizeof(offs)/sizeof(offs[0]);i++)_sw(words[i],base+offs[i]);assert(zeemote_input_install_module(&module,NULL)==1);
 assert(_lw(base+0x4e68)==base+0x3cc0&&_lw(base+0x4e50)==base+0x4054&&_lw(base+0x4e7c)==base+0x3fd0);assert(zeemote_input_install_module(&module,NULL)==1);
 puts("PASS: real descriptor parser plus mocked native init/report/term callbacks, PID/VID gate, full/stripped IDs, malformed neutral, disconnect invalidation, generation race, untouched DS3 path and deferred logging");
}
