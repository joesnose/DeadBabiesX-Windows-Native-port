/* Read-only GAME-context plugin/version and log-file check. Original MIT. */
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspdebug.h>
#include <pspctrl.h>
#include <pspsdk.h>
#include <pspinit.h>
#include <string.h>
PSP_MODULE_INFO("PSPGoHIDLoadCheck",PSP_MODULE_KERNEL,0,48);
static int checker_thread(SceSize args,void *argp){
 (void)args;(void)argp;
 pspDebugScreenInit();
 int old=pspSdkSetK1(0);
 pspDebugScreenKprintf("PSP Go HID Load Check v0.48\n\n");
 pspDebugScreenKprintf("GAME context only: opening this app reloads plugins.\n");
 pspDebugScreenKprintf("This does not check the previous VSH session.\n\n");
 SceModule *m=sceKernelFindModuleByName("PSPGoClassicHID");
 if(!m)m=sceKernelFindModuleByName("PSPGoNativeDS4");
 if(m){
  char name[29];memcpy(name,m->modname,28);name[28]=0;
  pspDebugScreenKprintf("Loaded: %s\nVersion: %u.%02u\nText bytes: %u\n\n",name,m->version[1],m->version[0],(unsigned)m->text_size);
 }else pspDebugScreenKprintf("No HID plugin found in this GAME session.\nCheck the enabled GAME entry/path.\n\n");
 const char *paths[]={"ef0:/seplugins/pspgo_hid_v048.log","ef0:/pspgo_hid_v048.log","ms0:/seplugins/pspgo_hid_v048.log","ms0:/pspgo_hid_v048.log","ef0:/pspgo_hid_v048.boot","ms0:/pspgo_hid_v048.boot"};
 for(unsigned i=0;i<6;i++){
  SceIoStat st;memset(&st,0,sizeof(st));int result=sceIoGetstat(paths[i],&st);
  pspDebugScreenKprintf("%s\n",paths[i]);
  if(result>=0)pspDebugScreenKprintf("  Found: %u bytes\n",(unsigned)st.st_size);else pspDebugScreenKprintf("  Stat error: %08x\n",(unsigned)result);
 }
 pspSdkSetK1(old);
 pspDebugScreenKprintf("\nNo Bluetooth/registration changes made by this checker.\n");
 pspDebugScreenKprintf("Press START to exit.\n");
 for(;;){SceCtrlData buttons;sceCtrlPeekBufferPositive(&buttons,1);if(buttons.Buttons&PSP_CTRL_START)break;sceKernelDelayThread(50000);}
 sceKernelExitGame();return 0;
}

int module_start(SceSize args,void *argp){
 (void)args;(void)argp;
 SceUID thread=sceKernelCreateThread("HIDLoadCheck",checker_thread,0x20,16384,0,NULL);
 if(thread<0)return thread;
 int result=sceKernelStartThread(thread,0,NULL);
 if(result<0)sceKernelDeleteThread(thread);
 return result;
}
