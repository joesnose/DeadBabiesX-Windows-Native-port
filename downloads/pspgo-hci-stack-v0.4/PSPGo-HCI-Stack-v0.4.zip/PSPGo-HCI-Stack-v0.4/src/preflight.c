/* Guarded same-value transient-store test. Original code, MIT. */
#ifdef HCI_RAM_HOST_TEST
#include "mock_platform.h"
#else
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsdk.h>
#include <systemctrl.h>
#endif
#include "host.h"
#include "store_query.h"
#include "ram_test.h"
typedef struct {uint16_t id,length;const void *data;} Request;
typedef struct {uint16_t id,length,status,reserved;void *data;} Response;
#ifndef HCI_RAM_HOST_TEST
_Static_assert(sizeof(Request)==8&&sizeof(Response)==12,"native transaction ABI");
#endif

#define ONCE_PATH "ef0:/seplugins/pspgo_ramtest_v04.once"
#define VERIFIED_PATH "ef0:/seplugins/pspgo_ramtest_v04.verified"
static int (*query)(const Request *,Response *);
static unsigned sequence=1;
/* 0=validated reply, 1=outer 0050, 2=BCCMD rejection, -1=other error. */
static int exchange(RamOp op,unsigned *value){
 uint16_t tx[25] __attribute__((aligned(4))),rx[25] __attribute__((aligned(4)));
 if(ram_request(op,sequence,tx)<0)return -1;memset(rx,0xa5,50);
 Request request={0x70,50,tx};Response response={0x170,50,0xffff,0,rx};
 hci_log("RAMTEST op=%u %s begin seq=%u\n",op,op==RAM_SET_SAME?"SET same value key=03c0 store=0008 value=0001":"GET",sequence);
 int k1=pspSdkSetK1(0);int result=query(&request,&response);pspSdkSetK1(k1);
 if(result<0||response.status){hci_log("RAMTEST native=%08x outer=%04x\n",(unsigned)result,response.status);sequence++;return result>=0&&response.status==0x50?1:-1;}
 unsigned status=0;int parsed=ram_response(op,sequence++,rx,50,value,&status);
 if(parsed<0){hci_log("RAMTEST malformed response; stopping\n");return -1;}
 if(parsed){hci_log("RAMTEST BCCMD_status=%04x\n",status);return 2;}
 hci_log("RAMTEST op=%u value=%04x\n",op,*value);return 0;
}
/* State markers contain only a fixed public test identifier. Refuse malformed
 * or unreadable files. Exclusive creation and read-back precede any SET. */
static int marker(const char *path,int create){
 static const char token[8]={'R','A','M','4',0xc0,3,8,1};char data[9];int k1=pspSdkSetK1(0);
 SceUID fd=sceIoOpen(path,PSP_O_RDONLY,0);
 if(fd>=0){int n=sceIoRead(fd,data,sizeof(data));sceIoClose(fd);pspSdkSetK1(k1);return n==8&&!memcmp(data,token,8)?1:-1;}
 if(fd!=(int)0x80010002){pspSdkSetK1(k1);return -1;} /* ENOENT only */
 if(!create){pspSdkSetK1(k1);return 0;}
 fd=sceIoOpen(path,PSP_O_WRONLY|PSP_O_CREAT|PSP_O_EXCL,0600);
 if(fd<0){pspSdkSetK1(k1);return -1;}
 int ok=sceIoWrite(fd,token,sizeof(token))==8;if(sceIoClose(fd)<0)ok=0;
 if(sceIoSync("ef0:",0)<0)ok=0;
 pspSdkSetK1(k1);if(!ok)return -1;return marker(path,0)==1?1:-1;
}
static void ram_session(void){
 hci_log("RAMTEST v0.4: one same-value RAM override; no mode switch/reset/power command\n");
 unsigned build=0,mem=0,def=0,psi=0,rom=0,onchip=0,ram=0;
 if(exchange(RAM_BUILD,&build)||exchange(RAM_MEMORY_TYPE,&mem)||exchange(RAM_DEFAULT,&def)||exchange(RAM_PSI,&psi)||exchange(RAM_ROM,&rom)||exchange(RAM_ONCHIP,&onchip)){
  hci_log("RAMTEST STOP: prerequisite GET failed; no SET sent\n");return;
 }
 if(!ram_baseline_ok(build,mem,def,psi,rom,onchip)){
  hci_log("RAMTEST STOP: baseline/type mismatch; require build1918 RAMtype2 default1 PSI1 ROM0 onchip1; no SET\n");return;
 }
 int prior=marker(ONCE_PATH,0),verified=marker(VERIFIED_PATH,0);int state=exchange(RAM_ONLY,&ram);
 if(prior<0||verified<0){hci_log("RAMTEST STOP: unreadable/malformed marker; no SET\n");return;}
 if(prior==1){
  if(verified==1&&state==1)hci_log("RAMTEST FOLLOWUP: previously verified RAM override now unavailable (0050); no SET repeated\n");
  else if(verified==1&&state==0&&ram==1)hci_log("RAMTEST FOLLOWUP: RAM override still readable; volatility NOT established; no SET repeated\n");
  else hci_log("RAMTEST FOLLOWUP: previous attempt/result inconclusive; no SET repeated\n");
  hci_log("RAMTEST DONE: send combined log; no HCI transition attempted\n");return;
 }
 if(verified!=0||state!=1){hci_log("RAMTEST STOP: require absent prior marker and pre-test RAM GET=0050; no SET\n");return;}
 if(marker(ONCE_PATH,1)!=1){hci_log("RAMTEST STOP: could not persist one-shot marker; no SET\n");return;}
 if(exchange(RAM_SET_SAME,&ram)||exchange(RAM_ONLY,&ram)||ram!=1){hci_log("RAMTEST STOP: SET/readback not verified; no retry/reset\n");return;}
 if(exchange(RAM_DEFAULT,&def)||exchange(RAM_PSI,&psi)||exchange(RAM_ROM,&rom)||exchange(RAM_ONCHIP,&onchip)||!ram_baseline_ok(build,mem,def,psi,rom,onchip)){
  hci_log("RAMTEST STOP: post-check failed; no further writes or reset\n");return;
 }
 if(marker(VERIFIED_PATH,1)!=1){hci_log("RAMTEST STOP: write/readback passed but verification marker failed; no retry\n");return;}
 hci_log("RAMTEST VERIFIED: store8 reads1; default/PSI1 ROM0 onchip1 unchanged\n");
 hci_log("RAMTEST NEXT: fully power off/on once more, enable Bluetooth, wait, then send combined log\n");
}
#ifndef HCI_RAM_HOST_TEST
static void ram_preflight(void){
 SceModule *m=sceKernelFindModuleByName("sceBSMan");
 uint32_t r=sctrlHENFindFunction("sceBSMan","sceBSMan",0xed295515);
 uint32_t t=sctrlHENFindFunction("sceBSMan","sceBSMan",0xe1704dee);
 if(!m||!r||!t){hci_log("PREFLIGHT STOP: native management module unavailable\n");return;}
 uint32_t b=m->text_addr;if(m->text_size<0x5ebc||r!=b+0x5ea4||t!=b+0x385c){hci_log("PREFLIGHT STOP: management offsets differ\n");return;}
 uint32_t a[6],p[4];for(unsigned i=0;i<6;i++)a[i]=_lw(r+i*4);for(unsigned i=0;i<4;i++)p[i]=_lw(t+i*4);
 if(!radio_ready_guard(b,a)||!radio_transport_guard(b,p,_lw(b+0x3940),_lw(b+0x3944))){hci_log("PREFLIGHT STOP: management code guard mismatch\n");return;}
 int (*ready)(void)=(void *)(uintptr_t)r;query=(void *)(uintptr_t)t;
 for(unsigned i=0;i<30&&ready()!=1;i++)sceKernelDelayThread(1000000);
 if(ready()!=1){hci_log("PREFLIGHT STOP: management not ready\n");return;}
 ram_session();
}
void pspgo_radio_preflight(void){ram_preflight();}
#endif
