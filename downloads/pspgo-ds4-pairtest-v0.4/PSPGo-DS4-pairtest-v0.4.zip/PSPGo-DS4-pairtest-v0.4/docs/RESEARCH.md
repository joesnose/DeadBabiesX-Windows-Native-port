# Findings from the privately supplied v0.3 snapshots

All five requested driver snapshots matched their logged sizes and FNV-1a checksums. The updated module inventory completed without query errors. Loaded modules include sceBSMan, sceHIDSvc, scePadSvc, sceInput_Library and sceUsbBSMCDC_Driver.

The snapshots contain import/export tables and constants, allowing cross-module call resolution. sceHIDSvc has an explicit Sony VID 054C / PID 0268 special path and a generic HID-descriptor path. The input library maps both native device types 9 and 10 into gamepad category 2; scePadSvc subscribes to that category. Therefore a generic gamepad path exists in the software. This does not establish DS4 descriptor compatibility, authentication, channel negotiation or usable mappings.

The native registration export used by the existing btfree ARK logger was found and its entry inspected. The entry preserves K1 and forwards two caller arguments to an internal registration routine. The v0.4 trace forwards the same two opaque arguments, preserving the original validation. It records only call start and result. It does not copy or reinterpret their contents.

A guarded discovery-filter experiment plus registration-result trace is the next bounded hardware test. We need to establish whether discovery and native pairing succeed before choosing a transport or input adaptation. No DS3 parser is assumed to understand DS4 packets, and no PID-only substitution is made.

Ghidra 11.4.2 with MIPS little-endian EABI and the PSP objdump toolchain were used locally. Decompiled output has incomplete external-service context and Allegrex/ABI limitations; decisions above were checked against native instructions and actual tables. Native code, complete disassembly/decompilation and the user's log remain private and are not included in this source package.
