/* Original PSP Go native HID observation/translation adapter. MIT.
 * No radio commands, DS3 feature requests or synthetic connection status. */
#ifdef ZEE_HOOK_HOST_TEST
#include "../tests/zeemote_hooks_mock.h"
#else
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsdk.h>
#endif
#include <stdint.h>
#include <string.h>
#include "zeemote_hid.h"
#include "zeemote_input.h"
#include "zeemote_hooks.h"
typedef int (*Parse)(void *,const uint8_t *,unsigned);
typedef int (*Init)(void *,void *,const uint16_t *,unsigned);
typedef int (*Report)(void *,void *,const uint8_t *,unsigned);
typedef int (*Term)(void *,void *);
static Parse original_parse;static Init original_init;static Report original_report;static Term original_term;
typedef struct {void *context,*node;unsigned generation;int present,valid,authorized,parse_status,init_result,native_called;uint8_t node_type;uint16_t vendor,product;unsigned init_serial,descriptor_length,first_length,frame_logged;uint8_t first_node_id,first_report_id;uint8_t descriptor[512];ZeeLayout layout;} Entry;
typedef struct {void *context,*node;} OwnedNode;
static OwnedNode owned_nodes[6];
static int owned_index(void *context,void *node){if(!node)return -1;for(unsigned i=0;i<6;i++)if(owned_nodes[i].node==node&&owned_nodes[i].context==context)return (int)i;return -1;}
static Entry entries[4];static unsigned generation,init_serial,reported_serial;
static uint32_t installed_base;
typedef struct {unsigned descriptors,layouts,initialized,reports,invalid,unmatched,capacity,busy;} Counters;
static Counters counters,printed;
static Entry *find(void *context){for(unsigned i=0;i<4;i++)if(entries[i].present&&entries[i].context==context)return &entries[i];return NULL;}
static void forget(Entry *e){if(e){e->valid=e->authorized=0;e->node=NULL;e->generation=++generation;}}
#ifdef ZEE_HOOK_HOST_TEST
#define ZEE_CODE_ALIGN __attribute__((aligned(4)))
#else
#define ZEE_CODE_ALIGN
#endif
static int ZEE_CODE_ALIGN descriptor_capture(void *context,const uint8_t *descriptor,unsigned length){
 int irq=sceKernelCpuSuspendIntr();counters.descriptors++;Entry *e=find(context);
 if(!e)for(unsigned i=0;i<4;i++)if(!entries[i].present){e=&entries[i];break;}
 if(!e)for(unsigned i=0;i<4;i++)if(!entries[i].authorized&&(!e||entries[i].generation<e->generation))e=&entries[i];
 if(e){e->present=1;e->context=context;}
 int clear=e&&e->authorized;unsigned serial=++generation;if(e){e->generation=serial;e->node=NULL;e->valid=e->authorized=0;e->vendor=e->product=0;e->init_serial=0;e->first_length=e->frame_logged=0;e->descriptor_length=descriptor&&length<=512?length:0;if(e->descriptor_length)memcpy(e->descriptor,descriptor,length);}else counters.capacity++;
 sceKernelCpuResumeIntr(irq);if(clear)zee_input_clear();
 ZeeLayout layout;int status=zee_parse_descriptor(descriptor,length,&layout);
 irq=sceKernelCpuSuspendIntr();if(e&&e->generation==serial){e->parse_status=status;if(!status){e->layout=layout;e->valid=1;counters.layouts++;}}sceKernelCpuResumeIntr(irq);
 int result=original_parse(context,descriptor,length);
 if(result<0){irq=sceKernelCpuSuspendIntr();if(e&&e->generation==serial)forget(e);sceKernelCpuResumeIntr(irq);}
 return result;
}
static int initialize(void *context,void *node,const uint16_t *identity,unsigned flags){
 uint16_t product=identity?identity[0]:0,vendor=identity?identity[1]:0;
 int irq=sceKernelCpuSuspendIntr();Entry *before=find(context);unsigned serial=before?before->generation:0;
 int owned=owned_index(context,node),free_owner=-1;
 if(owned>=0)free_owner=owned;else for(unsigned i=0;i<6;i++)if(!owned_nodes[i].node){free_owner=(int)i;break;}
 int take=before&&before->valid&&node&&*(const uint8_t *)node==3&&vendor==0x1038&&product==0x1412&&free_owner>=0&&
  *(const uint32_t *)((const uint8_t *)node+0x128)==0&&
  *(const uint32_t *)((const uint8_t *)node+0x150)==0&&
  *(const uint32_t *)((const uint8_t *)node+0x154)==0;
 if(take){
  /* The native parser owns the zero-initialized node and linked-list lifetime.
   * Our backend owns only translation; no native aux/SceInput allocation exists. */
  owned_nodes[free_owner].context=context;owned_nodes[free_owner].node=node;
  before->vendor=vendor;before->product=product;before->node=node;before->node_type=3;before->init_result=0;before->native_called=0;before->init_serial=++init_serial;before->authorized=1;counters.initialized++;
  sceKernelCpuResumeIntr(irq);return 0;
 }
 sceKernelCpuResumeIntr(irq);
 /* Never mix native resource allocation into a node already owned by us. */
 int result=owned>=0?-1:original_init(context,node,identity,flags);
 irq=sceKernelCpuSuspendIntr();Entry *e=find(context);
 if(e&&e->generation==serial){e->vendor=vendor;e->product=product;e->init_serial=++init_serial;e->node=node;e->node_type=node?*(const uint8_t *)node:0;e->init_result=result;e->native_called=owned<0;e->authorized=0;}
 sceKernelCpuResumeIntr(irq);return result;
}
/* Report thread has only1024 bytes. Large buffers live in resident storage.
 * A contending/reentrant callback skips work instead of waiting or sharing a
 * mutable layout. Generation checks still guard publication after decoding. */
typedef struct {int busy;ZeeLayout layout;uint8_t report[64];ZeeState state;} ReportScratch;
static ReportScratch report_scratch;
static int receive_report(void *context,void *node,const uint8_t *data,unsigned length){
 unsigned serial=0;int authorized=0;uint8_t node_report_id=0;Entry *owner=NULL;
 int irq=sceKernelCpuSuspendIntr();int was_owned=owned_index(context,node)>=0;Entry *e=find(context);
 if(e&&e->authorized&&e->node==node&&node&&*(const uint8_t *)node==3){
  if(report_scratch.busy)counters.busy++;
  else {report_scratch.busy=1;report_scratch.layout=e->layout;serial=e->generation;owner=e;node_report_id=((const uint8_t *)node)[1];if(!e->first_length){e->first_length=length;e->first_node_id=node_report_id;e->first_report_id=data&&length?data[0]:0;}authorized=1;}
 }else counters.unmatched++;
 sceKernelCpuResumeIntr(irq);
 if(authorized){
  ZeeLayout *layout=&report_scratch.layout;const uint8_t *full=data;unsigned size=length;int framing=0;
  if(data&&length<=64){
   if(!layout->numbered)framing=length==layout->payload_bytes;
   else if(length==(unsigned)layout->payload_bytes+1&&data[0]==layout->report_id)framing=1;
   else if(length==layout->payload_bytes&&node_report_id==layout->report_id&&length<64){report_scratch.report[0]=layout->report_id;memcpy(report_scratch.report+1,data,length);full=report_scratch.report;size=length+1;framing=1;}
  }
  int decoded=framing?zee_decode_report(layout,full,size,&report_scratch.state):ZEE_INVALID;
  irq=sceKernelCpuSuspendIntr();
  if(owner->authorized&&owner->generation==serial&&owner->node==node){
   if(!decoded){zee_input_update(&report_scratch.state);counters.reports++;}
   else {counters.invalid++;zee_input_clear();}
  }
  report_scratch.busy=0;
  sceKernelCpuResumeIntr(irq);
 }
 return was_owned?0:original_report(context,node,data,length);
}
static int terminate(void *context,void *node){
 int clear=0,irq=sceKernelCpuSuspendIntr();Entry *e=find(context);int owned=owned_index(context,node);
 if(e&&e->node==node){clear=e->authorized;forget(e);e->present=0;}
 if(owned>=0){owned_nodes[owned].context=owned_nodes[owned].node=NULL;clear=1;}
 sceKernelCpuResumeIntr(irq);if(clear)zee_input_clear();
 /* Caller still releases its pool node after this callback. There are no
  * native aux/input resources to unregister for adapter-owned nodes. */
 return owned>=0?0:original_term(context,node);
}
static int jump(uint32_t pc,uint32_t target,uint32_t *out){if((pc|target)&3||((pc+4)&0xf0000000)!=(target&0xf0000000))return 0;*out=0x0c000000u|((target>>2)&0x3ffffff);return 1;}
int zeemote_input_install_module(SceModule *module,ZeeLogger log){
 if(!module||strcmp(module->modname,"sceHIDSvc"))return 0;
 uint32_t b=module->text_addr;if(installed_base){if(installed_base==b)return 1;if(log)log("ZEE INPUT skipped: another HID module generation is resident\n");return -1;}
 if(module->text_size<0x4e80||b>0xffffffffu-module->text_size)return -1;
 uint32_t expected,patched;if(!jump(b+0x908,b+0x1000,&expected)||!jump(b+0x908,(uint32_t)(uintptr_t)descriptor_capture,&patched))return -1;
 int irq=sceKernelCpuSuspendIntr();
 int valid=_lw(b+0x908)==expected&&_lw(b+0x90c)==0x02402021u&&_lw(b+0x904)==0x27a50018u&&
  _lw(b+0x8f4)==0x8fa60014u&&_lw(b+0x8f8)==0x2cc70201u&&
  _lw(b+0x4e64)==b+0x3cc0&&_lw(b+0x4e68)==b+0x3cc0&&
  _lw(b+0x4e4c)==b+0x4054&&_lw(b+0x4e50)==b+0x4054&&
  _lw(b+0x4e78)==b+0x3fd0&&_lw(b+0x4e7c)==b+0x3fd0&&
  _lw(b+0x4054)==0x90a30000u&&_lw(b+0x4058)==0x27bdfff0u&&
  _lw(b+0x3cc0)==0x27bdffb0u&&_lw(b+0x3cc4)==0xafb40040u;
 if(valid){
  original_parse=(Parse)(uintptr_t)(b+0x1000);original_init=(Init)(uintptr_t)(b+0x3cc0);original_report=(Report)(uintptr_t)(b+0x4054);original_term=(Term)(uintptr_t)(b+0x3fd0);
  _sw((uint32_t)(uintptr_t)initialize,b+0x4e64);_sw((uint32_t)(uintptr_t)receive_report,b+0x4e4c);_sw((uint32_t)(uintptr_t)terminate,b+0x4e78);_sw(patched,b+0x908);
  sceKernelDcacheWritebackInvalidateAll();sceKernelIcacheInvalidateAll();installed_base=b;
 }
 sceKernelCpuResumeIntr(irq);
 if(log)log(valid?"ZEE INPUT installed: descriptor-derived type3 reports; identity1038:1412; DS3 callbacks unchanged\n":"ZEE INPUT skipped: HID callback/descriptor ABI context mismatch\n");
 return valid?1:-1;
}
int zeemote_input_ready(void){return installed_base!=0;}
void zeemote_input_log_tick(ZeeLogger log){
 /* Native lifecycle monitoring, not an RF heartbeat: unchanged HID reports
  * may legitimately stop while a button remains held. Keepalive never creates
  * or reactivates input state; only a valid report can do that. */
 if(installed_base){
  SceModule *module=sceKernelFindModuleByName("sceHIDSvc");
  int alive=module&&module->text_addr==installed_base&&module->text_size>=0x4e80;
  int live_session=0,irq=sceKernelCpuSuspendIntr();
  for(unsigned i=0;i<4;i++){
   Entry *e=&entries[i];
   if(!alive){forget(e);e->present=0;}
   else if(e->present&&e->authorized&&e->node&&*(const uint8_t *)e->node==3)live_session=1;
  }
  if(!alive){memset(owned_nodes,0,sizeof(owned_nodes));zee_input_clear();}else if(live_session)zee_input_keepalive();
  sceKernelCpuResumeIntr(irq);
  if(alive&&live_session){ZeeInputStats input;zee_input_stats(&input);if(input.active&&!input.installed)zee_input_install();}
 }
 if(!log)return;
 static unsigned stats_lines,seen_logged,motion_logged,error_logged,guard_logged=~0u;ZeeInputStats stats;zee_input_stats(&stats);
 if((stats.installed&&stats_lines<4)||stats.seen_buttons!=seen_logged||stats.motion_seen!=motion_logged||stats.install_error!=error_logged||stats.guard_index!=guard_logged){
  log("ZEE CTRL installed=%u active=%u peek_pos=%u peek_neg=%u read_pos=%u read_neg=%u merged=%u error=%u guard=%u vsh=%u vsh_reads=%u\n",stats.installed,stats.active,stats.reads[0],stats.reads[1],stats.reads[2],stats.reads[3],stats.merged_samples,stats.install_error,stats.guard_index,stats.vsh_installed,stats.vsh_reads);
  log("ZEE STATE buttons=%08x seen=%08x motion=%x lx=%u range=%u..%u ly=%u range=%u..%u\n",stats.last_buttons,stats.seen_buttons,stats.motion_seen,stats.lx,stats.min_lx,stats.max_lx,stats.ly,stats.min_ly,stats.max_ly);
  stats_lines++;seen_logged=stats.seen_buttons;motion_logged=stats.motion_seen;error_logged=stats.install_error;guard_logged=stats.guard_index;
 }
 Counters now;int irq=sceKernelCpuSuspendIntr();now=counters;sceKernelCpuResumeIntr(irq);
 Counters changes=now,previous=printed;changes.reports=changes.unmatched=0;previous.reports=previous.unmatched=0;
 if(memcmp(&changes,&previous,sizeof(changes))||now.reports/512!=printed.reports/512||now.unmatched/512!=printed.unmatched/512||(now.reports<8&&now.reports!=printed.reports)||(now.unmatched<8&&now.unmatched!=printed.unmatched)){log("ZEE INPUT descriptors=%u layouts=%u initialized=%u reports=%u invalid=%u unmatched=%u capacity=%u busy=%u\n",now.descriptors,now.layouts,now.initialized,now.reports,now.invalid,now.unmatched,now.capacity,now.busy);printed=now;}
 unsigned highest=reported_serial;
 for(unsigned i=0;i<4;i++){
  Entry meta;irq=sceKernelCpuSuspendIntr();meta=entries[i];int snapshot_owned=owned_index(meta.context,meta.node)>=0;sceKernelCpuResumeIntr(irq);
  if(meta.authorized&&meta.first_length&&meta.frame_logged!=meta.generation){
   log("ZEE INPUT FIRST REPORT layout_id=%u numbered=%u payload=%u length=%u node_id=%u first_byte=%02x\n",meta.layout.report_id,meta.layout.numbered,meta.layout.payload_bytes,meta.first_length,meta.first_node_id,meta.first_report_id);
   irq=sceKernelCpuSuspendIntr();if(entries[i].generation==meta.generation)entries[i].frame_logged=meta.generation;sceKernelCpuResumeIntr(irq);
  }
  if(meta.init_serial<=reported_serial)continue;
  log("ZEE INPUT INIT vendor=%04x product=%04x descriptor_status=%d authorized=%d owned=%d native_called=%d %s_result=%08x node_type=%u descriptor_length=%u\n",meta.vendor,meta.product,meta.parse_status,meta.authorized,snapshot_owned,meta.native_called,meta.native_called?"native":"adapter",(unsigned)meta.init_result,meta.node_type,meta.descriptor_length);
  if(meta.vendor==0x1038&&meta.product==0x1412){
   log("ZEE INPUT FRAME layout_id=%u numbered=%u payload=%u first_length=%u node_id=%u first_byte=%02x\n",meta.layout.report_id,meta.layout.numbered,meta.layout.payload_bytes,meta.first_length,meta.first_node_id,meta.first_report_id);
   static const char hex[]="0123456789abcdef";
   for(unsigned at=0;at<meta.descriptor_length;at+=16){char line[33];unsigned count=meta.descriptor_length-at;if(count>16)count=16;
    for(unsigned j=0;j<count;j++){uint8_t value=meta.descriptor[at+j];line[j*2]=hex[value>>4];line[j*2+1]=hex[value&15];}line[count*2]=0;log("ZEE HID DESCRIPTOR offset=%u bytes=%s\n",at,line);
   }
  }
  if(meta.init_serial>highest)highest=meta.init_serial;
 }
 reported_serial=highest;
}
