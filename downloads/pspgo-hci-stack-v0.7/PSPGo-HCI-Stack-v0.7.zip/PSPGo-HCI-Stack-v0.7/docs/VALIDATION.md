# Validation — 2026-11-09 UTC

PSP GCC 15.2 compile/link/import fixup/PRX generation completed. Strict warnings
are enabled (dense-layout misleading-indentation warning disabled). Final checks
are recorded in build/test output. Native USB APIs are runtime resolved.

Host tests run under AddressSanitizer/UBSan (leak detection disabled because of
sandbox process-inspection restrictions):

- Existing transport descriptor/endpoint matching, all event/maximum ACL split
  boundaries, coalescing, capacity retention, malformed/overflow bounds.
- Routing, ownership, submission errors, local timeout/cancel, disconnect before
  and during submission, reconnect and failed-cancel quarantine; version gates.
- 105 DS4 protocol assertion groups, CRC fixture, mapping, malformed/truncated
  reports and neutral failure state.
- Read-only store request allowlist, exact GET framing, selectors, response bounds;
  BDADDR/other keys and mixed/unknown store selectors rejected.
- Bond save/reload, local/remote address binding and corruption rejection through
  mocked PSP filesystem calls backed by temporary Linux files.
- HIDP transaction/length validation and decoded DS4 report delivery via mocked
  PSP input calls.
- Actual compiled upstream BTstack emits HCI Reset and advances initialization
  after a simulated command-complete event. This is NOT full HCI initialization,
  radio operation or successful Bluetooth pairing.
- Four input syscall selections, positive/negative merges, analog dead zone,
  stale-report expiry, disconnect neutral and preservation of original errors
  through mock calls. No real syscall table was modified in these tests.

Not verified: new build loading or per-store GETs on PSP, native USB transport,
DMA/cache/cancel timing, HCI exposure/recovery, full HCI initialization, real SSP
pairing, persistent-bond behavior on PSP, SDP/HID/feature response, actual input
hooks, games, suspend/resume or end-to-end DS4 controls. Deterministic mocks do
not establish concurrency safety or replace hardware validation.

## v0.4 — same-value RAM capability test

PSP build plus previous sanitizer suites rerun. Added mock-radio/filesystem tests
cover the fixed SET encoding, memory-type/baseline gates, malformed replies,
refusal without a durable marker, SET failure, readback and post-checks, existing
RAM override refusal, and no repeated SET on subsequent starts. Memory-type
parsing uses selector 0008 and requires returned type 2.

Hardware remains untested: the new memory-type query, SET acceptance, RAM-only
readback, PSP filesystem sync/EXCL behavior, power-cycle retention and actual
radio recovery. Simulated second runs are state-machine tests, not power tests.

## v0.5 acknowledgment/readback regression

Added simulated malformed-ACK and outer-rejection cases that require RAM GET and
baseline observations to proceed independently, with no verified marker and no
repeated write on subsequent starts. Existing v0.4 marker paths/tokens retained.
All host sanitizer suites and PSP build rerun. ACK diagnostics have a fixed
nine-word initialized-buffer bound and do not infer actual copied extent.
The real Sony acknowledgment remains unidentified; no parser compatibility or
hardware connection success is claimed.

## v0.6 bounded new attempt and ACK validation

Header-only and non-echo payload SETRESP accepted only with valid type, sequence,
varid, length bounds and zero status. Wrong type/sequence/varid and error status
are rejected. Independent GET/post-checks still run after a returned SET. A
valid prior v0.4 attempt and absent legacy verification marker are required;
new v0.6 marker gates one new SET and blocks all further ones. Mock tests cover
missing/completed prior histories, malformed markers and failed operations.
No claim is made that the actual Sony reply has been observed or that the RAM
write/power-cycle test has succeeded on hardware.

## v0.7 obsolete-history gate

Old v0.4 files are informational; current radio/baseline and retained v0.6
markers govern safety/one-shot behavior. Tests now verify missing old markers
and old verified markers do not block the guarded test, while invalid current
markers and previous current attempts still prevent writing. Marker failure
diagnostics separate open errors from invalid contents/lengths. PSP build and
host sanitizer suites passed; new hardware behavior is not yet verified.
