#include "hid_setup_plan.h"
#include <assert.h>
#include <stdio.h>
static void execute(const HidSetupPlan *p,uint32_t destination){
 const uint32_t stub=0x88310000,helper=0x88320000,initial_sp=0x09001000,original_ra=0x8823020c;
 uint32_t r[32]={0},saved_ra=0; r[4]=20000;r[18]=0x88235000;r[27]=0xface0010;r[29]=initial_sp;r[31]=original_ra;
 uint32_t pc=stub;unsigned calls=0;
 for(unsigned step=0;step<16&&pc!=destination;step++){
  if(pc==helper){assert(r[4]==20000&&r[31]==stub+16);calls++;r[2]=destination;pc=r[31];continue;}
  assert(pc>=stub&&pc<stub+HID_SETUP_WORDS*4);uint32_t w=p->code[(pc-stub)/4];
  if(w==0x27bdffe0){r[29]-=32;pc+=4;}
  else if(w==0xafbf001c){assert(r[29]+28==initial_sp-4);saved_ra=r[31];pc+=4;}
  else if(w>>26==3){assert(p->code[(pc-stub)/4+1]==0);r[31]=pc+8;pc=((pc+4)&0xf0000000u)|((w&0x3ffffffu)<<2);}
  else if(w==0x0040c821){r[25]=r[2];pc+=4;}
  else if(w==0x8fbf001c){r[31]=saved_ra;pc+=4;}
  else if(w==0x27bd0020){r[29]+=32;pc+=4;}
  else if(w==0x03200008){assert(p->code[(pc-stub)/4+1]==0x8e440000);assert(r[18]==0x88235000);r[4]=2;pc=r[25];}
  else assert(!"unknown wait-thunk instruction");
 }
 assert(pc==destination&&calls==1&&r[29]==initial_sp&&r[31]==original_ra&&r[27]==0xface0010&&r[18]==0x88235000&&r[4]==2);
}
int main(void){
 uint32_t b=0x8822f800,g[HID_SETUP_GUARDS];hid_setup_expected(b,g);HidSetupPlan p;
 assert(!hid_setup_plan(b,0x4ec4,0x88310000,0x88320000,g,&p));
 execute(&p,b+0x858);execute(&p,b+0x894);
 for(unsigned i=0;i<HID_SETUP_GUARDS;i++){g[i]^=1;HidSetupPlan sentinel;memset(&sentinel,0xa5,sizeof(sentinel));HidSetupPlan before=sentinel;assert(hid_setup_plan(b,0x4ec4,0x88310000,0x88320000,g,&sentinel)<0&&!memcmp(&sentinel,&before,sizeof(before)));g[i]^=1;}
 assert(hid_setup_plan(b,0x4e38,0x88310000,0x88320000,g,&p)<0);
 assert(hid_setup_plan(b,0x4ec4,0x08310000,0x88320000,g,&p)<0);
 assert(hid_setup_plan(b,0x4ec4,0x88310000,0x88320002,g,&p)<0);
 puts("PASS: all32 native busy/GP/cleanup guards, unchanged failure output, emitted MIPS wait thunk to original loop/identity-unavailable fallback with once-only helper and SP/RA/GP/S2 preservation");
}
