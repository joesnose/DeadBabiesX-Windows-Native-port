#ifndef ZEE_GAME_RECONNECT_H
#define ZEE_GAME_RECONNECT_H
#include <stdint.h>
#include <string.h>
typedef struct {unsigned queries,matches,slot,flags,attempted;int result;} ZeeReconnect;
static inline int zee_saved_free(const uint8_t p[80],unsigned slot){
 static const char name[]="Zeemote: SteelSeries Free";
 if(!p||slot<1||slot>8||p[0]!=80||p[1]||p[2]||p[3]||
    ((unsigned)p[4]|((unsigned)p[5]<<8))!=slot)return 0;
 unsigned flags=(unsigned)p[72]|((unsigned)p[73]<<8);
 if(flags!=0x0202&&flags!=0x0402&&flags!=0x0602)return 0;
 for(unsigned i=0;i<sizeof(name);i++){
  unsigned c=(unsigned)p[6+2*i]|((unsigned)p[7+2*i]<<8),n=(unsigned char)name[i];
  if(c>='A'&&c<='Z')c+='a'-'A';
  if(n>='A'&&n<='Z')n+='a'-'A';
  if(c!=n)return 0;
 }
 return 1;
}
/* Called once on the owned GAME worker. Query fresh records, require exactly
 * one named saved target, preserve mode policy, do not retain names/addresses.
 * Name selects a registration only; report ownership still requires VID/PID
 * and descriptor validation. No pairing, PIN, radio power/reset or writes. */
static inline ZeeReconnect zee_game_reconnect(int active,int (*query)(int,void *),int (*connect)(int,int)){
 ZeeReconnect d={0,0,0,0,0,0};
 if(active||!query||!connect)return d;
 for(unsigned slot=1;slot<=8;slot++){
  uint8_t record[80] __attribute__((aligned(16)))={0};record[0]=80;
  ++d.queries;int status=query((int)slot,record);
  if(status>=0&&zee_saved_free(record,slot)){
   ++d.matches;d.slot=slot;d.flags=(unsigned)record[72]|((unsigned)record[73]<<8);
  }
  memset(record,0,sizeof(record));
 }
 if(d.matches==1){d.attempted=1;d.result=connect((int)d.slot,d.flags==0x0402?1:0);}
 return d;
}
#endif
