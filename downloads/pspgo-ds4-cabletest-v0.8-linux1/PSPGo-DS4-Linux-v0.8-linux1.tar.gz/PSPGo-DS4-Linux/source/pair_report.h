#ifndef PAIR_REPORT_H
#define PAIR_REPORT_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
static inline int nibble(char c){
 if(c>='0'&&c<='9')return c-'0';
 if(c>='a'&&c<='f')return c-'a'+10;
 if(c>='A'&&c<='F')return c-'A'+10;
 return -1;
}
static inline int parse_address(const char *text,uint8_t address[6]){
 if(!text||strlen(text)!=17)return -1;
 unsigned any=0,all=255;
 for(unsigned i=0;i<6;i++){
  int a=nibble(text[i*3]),b=nibble(text[i*3+1]);
  if(a<0||b<0||(i<5&&text[i*3+2]!=':'))return -1;
  address[i]=(uint8_t)((a<<4)|b);any|=address[i];all&=address[i];
 }
 return any&&all!=255?0:-1;
}
/* Linux hidraw includes the report ID. BlueZ uses 23 bytes for report 13. */
static inline void pairing_report(const uint8_t address[6],uint8_t report[23]){
 memset(report,0,23);report[0]=0x13;
 for(unsigned i=0;i<6;i++)report[i+1]=address[5-i];
}
static inline void decode_address(const uint8_t *little_endian,char text[18]){
 const char *hex="0123456789ABCDEF";
 for(unsigned i=0;i<6;i++){
  uint8_t b=little_endian[5-i];text[i*3]=hex[b>>4];text[i*3+1]=hex[b&15];text[i*3+2]=i==5?'\0':':';
 }
}
#endif
