/* Experimental PSP Go native registration trace; no firmware binaries included. */
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsysmem_kernel.h>
#include <pspsysclib.h>
#include <pspsdk.h>
#include <systemctrl.h>
#include <stdarg.h>
#include <stdint.h>
#include <string.h>
#include "patch_plan.h"
PSP_MODULE_INFO("PSPGoDS4PairTest",PSP_MODULE_KERNEL,0,4);
#define LOG_PATH "ef0:/seplugins/pspgo_ds4_pair.log"
static STMOD_HANDLER previous_handler;
static uint32_t trampoline[4] __attribute__((aligned(16)));
static int (*original_register)(const void *,const void *);
static int resident;
typedef struct {unsigned length;char data[256];} LogBuffer;
static void format_char(void *ctx,int ch){
 LogBuffer *b=ctx;if(ch==0x200)b->length=0;
 else if(ch>=0&&ch<256&&b->length<sizeof(b->data))b->data[b->length++]=(char)ch;
}
static void log_line(const char *fmt,...){
 int old=pspSdkSetK1(0);LogBuffer b={0,{0}};va_list args;
 va_start(args,fmt);prnt(format_char,&b,fmt,args);va_end(args);
 SceUID fd=sceIoOpen(LOG_PATH,PSP_O_CREAT|PSP_O_WRONLY|PSP_O_APPEND,0666);
 if(fd>=0){if(b.length)sceIoWrite(fd,b.data,b.length);sceIoClose(fd);}
 pspSdkSetK1(old);
}
/* Arguments are forwarded unchanged. Never read/log PINs, link keys or device records. */
static int register_trace(const void *device,const void *pin){
 log_line("REGISTER begin\n");
 int result=original_register(device,pin);
 log_line("REGISTER result=%08x\n",(unsigned)result);
 return result;
}
static void flush_code(void){sceKernelDcacheWritebackInvalidateAll();sceKernelIcacheInvalidateAll();}
static void hook_registration(void){
 SceModule *mod=sceKernelFindModuleByName("sceBSMan");
 uint32_t entry=sctrlHENFindFunction("sceBSMan","sceBSMan",0x8ac2f7b8u);
 if(!mod || !entry || mod->text_size<8 || entry<mod->text_addr ||
    entry-mod->text_addr>mod->text_size-8 || (entry&3)){
  log_line("REGISTER hook skipped: export unavailable or outside module\n");return;
 }
 int irq=sceKernelCpuSuspendIntr();
 const uint32_t original[]={_lw(entry),_lw(entry+4)};HookPlan plan;
 int valid=registration_hook_plan(entry,(uint32_t)(uintptr_t)register_trace,
                                (uint32_t)(uintptr_t)trampoline,original,&plan)==0;
 if(valid){
  memcpy(trampoline,plan.trampoline,sizeof(trampoline));
  original_register=(void *)trampoline;
  _sw(plan.entry[0],entry);_sw(plan.entry[1],entry+4);flush_code();resident=1;
 }
 sceKernelCpuResumeIntr(irq);
 if(valid)log_line("REGISTER hook installed at module+%08x\n",entry-mod->text_addr);
 else log_line("REGISTER hook skipped: prologue mismatch %08x %08x\n",original[0],original[1]);
}
static void patch_discovery(SceModule *mod){
 const unsigned load_offset=0x13d40,compare_offset=0x13d6c;
 if(mod->text_size<compare_offset+4){log_line("DISCOVERY skipped: module too small\n");return;}
 int irq=sceKernelCpuSuspendIntr();
 uint32_t first=_lw(mod->text_addr+load_offset),second=_lw(mod->text_addr+compare_offset);
 int valid=discovery_patch_allowed(first,second);
 if(valid){
  _sw(0x240effffu,mod->text_addr+load_offset);
  _sw(0x144e0003u,mod->text_addr+compare_offset);flush_code();
 }
 sceKernelCpuResumeIntr(irq);
 if(valid)log_line("DISCOVERY filter lifted in RAM; select only your DS4 for this test\n");
 else if(first==0x240effffu&&second==0x144e0003u)log_line("DISCOVERY filter already lifted\n");
 else log_line("DISCOVERY skipped: instruction mismatch %08x %08x\n",first,second);
}
static int module_started(SceModule *mod){
 if(mod&&!strcmp(mod->modname,"bluetooth_plugin_module"))patch_discovery(mod);
 return previous_handler?previous_handler(mod):0;
}
int module_start(SceSize args,void *argp){
 (void)args;(void)argp;
 unsigned fw=sceKernelDevkitVersion();int model=sceKernelGetModel();
 log_line("\nPSPGo DS4 native pairing test 0.4 model=%d devkit=%08x\n",model,fw);
 if(model!=4||(fw!=0x06060010&&fw!=0x06060110)){
  log_line("UNSUPPORTED model/firmware; no patches installed\n");return -1;
 }
 hook_registration();
 previous_handler=sctrlHENSetStartModuleHandler(module_started);resident=1;
 SceModule *mod=sceKernelFindModuleByName("bluetooth_plugin_module");
 if(mod)patch_discovery((SceModule *)mod);
 log_line("READY: pairing experiment only; native report decoding unchanged\n");
 return 0;
}
int module_stop(SceSize args,void *argp){
 (void)args;(void)argp;
 /* Keep hook code resident. Disabling the entry and rebooting clears RAM patches. */
 if(resident)return -1;
 return 0;
}
