#ifndef ZEE_GAME_RECONNECT_H
#define ZEE_GAME_RECONNECT_H
#include <stdint.h>
#include <string.h>
#include "profile_policy.h"
typedef struct {unsigned queries,matches,slot,flags,attempted;int result;} ZeeReconnect;
typedef struct {unsigned slot;uint8_t address[6];int valid;} ZeeTarget;
static inline int zee_saved_free(const uint8_t p[80],unsigned slot){
 if(!p||slot<1||slot>8||p[0]!=80||p[1]||p[2]||p[3]||
    ((unsigned)p[4]|((unsigned)p[5]<<8))!=slot)return 0;
 unsigned flags=(unsigned)p[72]|((unsigned)p[73]<<8);
 if(!native_hid_saved(flags))return 0;
 /* A populated native saved HID record, not a claim of gamepad identity. */
 if(!p[6]&&!p[7])return 0;
 for(unsigned i=0;i<33;i++)if(!p[6+2*i]&&!p[7+2*i])return 1;
 return 0;
}
static inline int zee_target_encode(const uint8_t record[80],unsigned slot,uint8_t data[16]){
 if(!data||!zee_saved_free(record,slot))return -1;
 memset(data,0,16);memcpy(data,"CHID",4);data[4]=(uint8_t)slot;memcpy(data+8,record+74,6);return 0;
}
static inline ZeeTarget zee_target_decode(const uint8_t *data,int length){
 ZeeTarget t={0};
 if(data&&length==16&&!memcmp(data,"CHID",4)&&data[4]>=1&&data[4]<=8&&
    !data[5]&&!data[6]&&!data[7]&&!data[14]&&!data[15]){
  t.slot=data[4];memcpy(t.address,data+8,6);t.valid=1;
 }
 return t;
}
/* Called once on the owned GAME worker. Query fresh records, require exactly
 * one eligible saved HID target or the last user-selected slot/address, preserve mode policy, do not retain names/addresses.
 * Saved metadata selects a registration only; report ownership still requires
 * a supported gamepad descriptor. No pairing, PIN, radio power/reset or writes. */
static inline ZeeReconnect zee_game_reconnect_target(int active,int (*query)(int,void *),int (*connect)(int,int),const ZeeTarget *target){
 ZeeReconnect d={0,0,0,0,0,0};
 if(active||!query||!connect)return d;
 for(unsigned slot=1;slot<=8;slot++){
  uint8_t record[80] __attribute__((aligned(16)))={0};record[0]=80;
  ++d.queries;int status=query((int)slot,record);
  if(status>=0&&zee_saved_free(record,slot)&&(!target||!target->valid||
     (target->slot==slot&&!memcmp(target->address,record+74,6)))){
   ++d.matches;d.slot=slot;d.flags=(unsigned)record[72]|((unsigned)record[73]<<8);
  }
  memset(record,0,sizeof(record));
 }
 if(d.matches==1){d.attempted=1;d.result=connect((int)d.slot,native_hid_mode(d.flags,0));}
 return d;
}
static inline ZeeReconnect zee_game_reconnect(int active,int (*query)(int,void *),int (*connect)(int,int)){
 return zee_game_reconnect_target(active,query,connect,NULL);
}
#endif
