# Validation — 2026-11-09 UTC

PSP GCC 15.2 compile/link/import fixup/PRX generation completed. Strict warnings
are enabled (dense-layout misleading-indentation warning disabled). Final checks
are recorded in build/test output. Native USB APIs are runtime resolved.

Host tests run under AddressSanitizer/UBSan (leak detection disabled because of
sandbox process-inspection restrictions):

- Existing transport descriptor/endpoint matching, all event/maximum ACL split
  boundaries, coalescing, capacity retention, malformed/overflow bounds.
- Routing, ownership, submission errors, local timeout/cancel, disconnect before
  and during submission, reconnect and failed-cancel quarantine; version gates.
- 105 DS4 protocol assertion groups, CRC fixture, mapping, malformed/truncated
  reports and neutral failure state.
- Read-only store request allowlist, exact GET framing, selectors, response bounds;
  BDADDR/other keys and mixed/unknown store selectors rejected.
- Bond save/reload, local/remote address binding and corruption rejection through
  mocked PSP filesystem calls backed by temporary Linux files.
- HIDP transaction/length validation and decoded DS4 report delivery via mocked
  PSP input calls.
- Actual compiled upstream BTstack emits HCI Reset and advances initialization
  after a simulated command-complete event. This is NOT full HCI initialization,
  radio operation or successful Bluetooth pairing.
- Four input syscall selections, positive/negative merges, analog dead zone,
  stale-report expiry, disconnect neutral and preservation of original errors
  through mock calls. No real syscall table was modified in these tests.

Not verified: new build loading or per-store GETs on PSP, native USB transport,
DMA/cache/cancel timing, HCI exposure/recovery, full HCI initialization, real SSP
pairing, persistent-bond behavior on PSP, SDP/HID/feature response, actual input
hooks, games, suspend/resume or end-to-end DS4 controls. Deterministic mocks do
not establish concurrency safety or replace hardware validation.

## v0.4 — same-value RAM capability test

PSP build plus previous sanitizer suites rerun. Added mock-radio/filesystem tests
cover the fixed SET encoding, memory-type/baseline gates, malformed replies,
refusal without a durable marker, SET failure, readback and post-checks, existing
RAM override refusal, and no repeated SET on subsequent starts. Memory-type
parsing uses selector 0008 and requires returned type 2.

Hardware remains untested: the new memory-type query, SET acceptance, RAM-only
readback, PSP filesystem sync/EXCL behavior, power-cycle retention and actual
radio recovery. Simulated second runs are state-machine tests, not power tests.
