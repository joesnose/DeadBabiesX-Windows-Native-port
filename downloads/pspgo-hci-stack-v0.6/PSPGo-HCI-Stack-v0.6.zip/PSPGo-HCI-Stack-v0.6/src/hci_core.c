#include "hci_core.h"
#include <string.h>
static unsigned le16(const uint8_t *p){return p[0]|((unsigned)p[1]<<8);}
int hci_match_interface(const uint8_t *d,size_t n){
 return d&&n==9&&d[0]==9&&d[1]==4&&d[2]==0&&d[3]==0&&d[4]==3&&d[5]==0xe0&&d[6]==1&&d[7]==1;
}
int hci_add_endpoint(HciEndpoints *e,const uint8_t *d,size_t n){
 if(!e||!d||n!=7||d[0]!=7||d[1]!=5||(d[2]&0x70)||!(d[2]&15))return HCI_ERR_PROTOCOL;
 unsigned mps=le16(d+4);if(!mps||mps>64)return HCI_ERR_PROTOCOL;
 uint8_t *ep=0;uint16_t *size=0;
 if((d[3]&3)==3&&(d[2]&0x80)&&d[6]){ep=&e->event_in;size=&e->event_mps;}
 if((d[3]&3)==2){if(d[2]&0x80){ep=&e->acl_in;size=&e->acl_in_mps;}else{ep=&e->acl_out;size=&e->acl_out_mps;}}
 if(!ep||*ep)return HCI_ERR_PROTOCOL;
 *ep=d[2];*size=(uint16_t)mps;return 0;
}
int hci_endpoints_complete(const HciEndpoints *e){return e&&e->event_in&&e->acl_in&&e->acl_out;}
int hci_valid_command(const uint8_t *p,size_t n){return p&&n>=3&&n<=258&&n==3u+p[2];}
int hci_valid_acl(const uint8_t *p,size_t n){return p&&n>=4&&n<=HCI_MAX_ACL&&n==4u+le16(p+2);}
int hci_stream_feed(HciStream *s,const void *p,size_t n){
 if(!s||(!p&&n)||s->used>sizeof(s->data)||n>sizeof(s->data)-s->used)return HCI_ERR_PROTOCOL;
 if(n)memcpy(s->data+s->used,p,n);s->used+=n;return 0;
}
int hci_stream_take(HciStream *s,int acl,void *out,size_t cap){
 if(!s||!out||s->used>sizeof(s->data))return HCI_ERR_ARGUMENT;
 unsigned header=acl?4:2;if(s->used<header)return 0;
 size_t n=header+(acl?le16(s->data+2):s->data[1]);
 if(n>(acl?HCI_MAX_ACL:HCI_MAX_EVENT)){s->used=0;return HCI_ERR_PROTOCOL;}
 if(s->used<n)return 0;if(cap<n)return HCI_ERR_ARGUMENT;
 memcpy(out,s->data,n);s->used-=n;memmove(s->data,s->data+n,s->used);return (int)n;
}
