/* Read-only PSP Go module inventory. No Bluetooth calls, hooks or patches. */
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsysmem_kernel.h>
#include <pspmodulemgr.h>
#include <pspsysclib.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

PSP_MODULE_INFO("PSPGoDS4Diagnostic", PSP_MODULE_KERNEL, 0, 3);
#define LOG_PATH "ef0:/seplugins/pspgo_ds4_diag.log"
#define CAPTURE_FLAG "ef0:/seplugins/pspgo_ds4_capture.flag"
#define MAX_MODULES 256
#define MAX_EXPORTS 768
static volatile int running;
static SceUID worker = -1, logfile = -1;
static SceUID seen[MAX_MODULES];
static unsigned seen_count;
static int capture_enabled;
static unsigned char code_copy[65536];
typedef struct { char library[32]; uint32_t nid, address; } Export;
static Export exports[MAX_EXPORTS];

typedef struct { unsigned length; char data[256]; } LogBuffer;
static void format_char(void *context, int ch) {
    LogBuffer *b=context;
    if(ch==0x200) b->length=0;
    else if(ch>=0 && ch<256 && b->length<sizeof(b->data)) b->data[b->length++]=(char)ch;
}
static void log_line(const char *format, ...) {
    LogBuffer buffer={0,{0}};
    va_list args;
    va_start(args, format);
    prnt(format_char,&buffer,format,args);
    va_end(args);
    if (buffer.length && logfile>=0) sceIoWrite(logfile,buffer.data,buffer.length);
}
static int ram_range(const void *p, size_t size) {
    uintptr_t physical = (uintptr_t)p & 0x1fffffff;
    return physical >= 0x08000000 && physical < 0x0c000000 &&
           size <= 0x0c000000 - physical;
}
static int interesting(const char *name) {
    char lower[32]; unsigned i;
    for (i=0; i<sizeof(lower)-1 && name[i]; ++i)
        lower[i] = name[i]>='A' && name[i]<='Z' ? name[i]+('a'-'A') : name[i];
    lower[i]=0;
    return strstr(lower,"bsman") || strstr(lower,"bluetooth") ||
           strstr(lower,"hidsvc") || strstr(lower,"btdun") ||
           strstr(lower,"padsvc") || strstr(lower,"usbbsmcdc") ||
           !strcmp(lower,"sceinput_library") ||
           !strcmp(lower,"scecontroller_service");
}
/* Copy under the interrupt lock; perform all file I/O after restoring it.
 * Module unload cannot free these tables while the copy is in progress. */
static unsigned copy_exports(SceUID uid) {
    unsigned count=0;
    int irq=sceKernelCpuSuspendIntr();
    SceModule *mod=sceKernelFindModuleByUID(uid);
    if (mod && mod->ent_size <= 65536 && ram_range(mod->ent_top,mod->ent_size)) {
        unsigned offset=0;
        while (offset+sizeof(SceLibraryEntryTable)<=mod->ent_size) {
            SceLibraryEntryTable *e=(void *)((char *)mod->ent_top+offset);
            unsigned step=e->len*4, total=e->stubcount+e->vstubcount;
            if (step<sizeof(*e) || step>mod->ent_size-offset) break;
            if (total<=MAX_EXPORTS && e->libname && ram_range(e->libname,32) &&
                ram_range(e->entrytable,total*8) && !((uintptr_t)e->entrytable&3)) {
                const uint32_t *table=e->entrytable;
                for (unsigned i=0;i<e->stubcount && count<MAX_EXPORTS;++i) {
                    Export *out=&exports[count++];
                    memcpy(out->library,e->libname,31);out->library[31]=0;
                    out->nid=table[i];out->address=table[total+i];
                }
            }
            offset+=step;
        }
    }
    sceKernelCpuResumeIntr(irq);
    return count;
}
/* Opt-in native driver text snapshots. No data segments or pairing records. */
static void capture_code(SceUID uid,const SceKernelModuleInfo *info) {
    static const struct { const char *name,*path; } targets[]={
        {"sceBSMan","ef0:/seplugins/pspgo_ds4_code_sceBSMan.bin"},
        {"sceHIDSvc","ef0:/seplugins/pspgo_ds4_code_sceHIDSvc.bin"},
        {"scePadSvc","ef0:/seplugins/pspgo_ds4_code_scePadSvc.bin"},
        {"sceInput_Library","ef0:/seplugins/pspgo_ds4_code_sceInput_Library.bin"},
        {"sceUsbBSMCDC_Driver","ef0:/seplugins/pspgo_ds4_code_sceUsbBSMCDC_Driver.bin"}
    };
    if(!capture_enabled)return;
    unsigned target;
    for(target=0;target<sizeof(targets)/sizeof(targets[0]);++target)
        if(!strcmp(info->name,targets[target].name))break;
    if(target==sizeof(targets)/sizeof(targets[0]))return;
    unsigned size=0,base=0;
    int irq=sceKernelCpuSuspendIntr();
    SceModule *mod=sceKernelFindModuleByUID(uid);
    if(mod && !strcmp(mod->modname,targets[target].name) &&
       mod->text_addr==info->text_addr && mod->text_size>0 &&
       mod->text_size<=sizeof(code_copy) &&
       ram_range((void *)mod->text_addr,mod->text_size)) {
        size=mod->text_size;base=mod->text_addr;
        memcpy(code_copy,(void *)base,size);
    }
    sceKernelCpuResumeIntr(irq);
    if(!size){log_line("CAPTURE SKIP %s: code unavailable or over 64 KiB\n",info->name);return;}
    SceUID fd=sceIoOpen(targets[target].path,PSP_O_WRONLY|PSP_O_CREAT|PSP_O_TRUNC,0666);
    if(fd<0){log_line("CAPTURE OPEN ERROR %s %08x\n",info->name,fd);return;}
    unsigned written=0;int result=0;
    while(running && written<size){
        result=sceIoWrite(fd,code_copy+written,size-written);
        if(result<=0)break;
        written+=result;
    }
    int closed=sceIoClose(fd);
    if(written!=size || closed<0){
        sceIoRemove(targets[target].path);
        log_line("CAPTURE WRITE ERROR %s bytes=%u/%u result=%08x close=%08x\n",info->name,written,size,result,closed);
        return;
    }
    unsigned hash=2166136261u;
    for(unsigned i=0;i<size;++i)hash=(hash^code_copy[i])*16777619u;
    log_line("CAPTURE %s base=%08x bytes=%u fnv1a=%08x file=%s\n",info->name,base,size,hash,targets[target].path);
}
static int inventory(unsigned sample) {
    SceUID ids[MAX_MODULES]={0};
    u32 count=0;
    /* Firmware takes buffer bytes, despite the current SDK header saying entries.
     * Passing 256 bytes previously limited the populated list to 64 SceUIDs. */
    int rc=sceKernelGetModuleIdListForKernel(ids,sizeof(ids),&count,0);
    if (rc<0) {log_line("ERROR GetModuleIdListForKernel=%08x; stopping\n",rc);return rc;}
    if (count>MAX_MODULES) count=MAX_MODULES;
    log_line("SAMPLE %u modules=%u\n",sample,count);
    for (unsigned i=0;i<count;++i) {
        if (ids[i]<=0) continue;
        unsigned j;
        for (j=0;j<seen_count && seen[j]!=ids[i];++j) {}
        if (j<seen_count) continue;
        SceKernelModuleInfo info;memset(&info,0,sizeof(info));info.size=sizeof(info);
        rc=sceKernelQueryModuleInfo(ids[i],&info);
        if (rc<0) {log_line("QUERY uid=%08x error=%08x\n",ids[i],rc);continue;}
        info.name[sizeof(info.name)-1]=0;
        log_line("MODULE uid=%08x name=%s text=%08x bytes=%08x\n",
                 ids[i],info.name,info.text_addr,info.text_size);
        if (interesting(info.name)) {
            unsigned n=copy_exports(ids[i]);
            log_line("EXPORTS module=%s copied=%u limit=%u\n",info.name,n,MAX_EXPORTS);
            for (unsigned k=0;k<n;++k)
                log_line("EXPORT %s %08x %08x\n",exports[k].library,exports[k].nid,exports[k].address);
        }
        capture_code(ids[i],&info);
        if (seen_count<MAX_MODULES) seen[seen_count++]=ids[i];
    }
    return 0;
}
static int diagnostic_thread(SceSize args,void *argp) {
    (void)args;(void)argp;
    logfile=sceIoOpen(LOG_PATH,PSP_O_WRONLY|PSP_O_CREAT|PSP_O_APPEND,0666);
    log_line("\nPSPGo DS4 diagnostic 0.3 — no Bluetooth support or memory patches\n");
    SceUID flag=sceIoOpen(CAPTURE_FLAG,PSP_O_RDONLY,0);
    capture_enabled=flag>=0;if(flag>=0)sceIoClose(flag);
    log_line("CODE CAPTURE %s (flag-controlled; selected driver text only)\n",capture_enabled?"enabled":"disabled");
    int model=sceKernelGetModel();uint32_t fw=sceKernelDevkitVersion();
    log_line("MODEL %d (PSP Go expected: 4) DEVKIT %08x\n",model,fw);
    if (model!=4 || (fw!=0x06060010 && fw!=0x06060110))
        log_line("UNSUPPORTED model/firmware; diagnostic stopped\n");
    else {
        for (unsigned sample=0;running && sample<45;++sample) {
            if (inventory(sample)<0) {running=0;break;}
            for (unsigned wait=0;running && wait<20;++wait) sceKernelDelayThread(100000);
        }
        log_line("END: module inventory stopped; no controller transport implemented\n");
    }
    if (logfile>=0) sceIoClose(logfile);
    logfile=-1;
    return 0;
}
int module_start(SceSize args,void *argp) {
    (void)args;(void)argp;running=1;
    worker=sceKernelCreateThread("PSPGoDS4Diagnostic",diagnostic_thread,0x30,0x10000,0,NULL);
    if (worker<0) return worker;
    int rc=sceKernelStartThread(worker,0,NULL);
    if (rc<0) {sceKernelDeleteThread(worker);worker=-1;running=0;}
    return rc;
}
int module_stop(SceSize args,void *argp) {
    (void)args;(void)argp;running=0;
    if (worker>=0) {sceKernelWaitThreadEnd(worker,NULL);sceKernelDeleteThread(worker);worker=-1;}
    return 0;
}
