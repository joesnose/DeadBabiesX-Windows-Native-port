#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p tests/build
flags='-std=gnu11 -Wall -Wextra -Werror -Wno-misleading-indentation -g -fsanitize=address,undefined -fno-omit-frame-pointer'
cc $flags tests/test_core.c src/hci_core.c -o tests/build/test_core
cc $flags -Itests tests/test_transport.c src/hci_core.c -o tests/build/test_transport
ASAN_OPTIONS=detect_leaks=0 tests/build/test_core
ASAN_OPTIONS=detect_leaks=0 tests/build/test_transport
