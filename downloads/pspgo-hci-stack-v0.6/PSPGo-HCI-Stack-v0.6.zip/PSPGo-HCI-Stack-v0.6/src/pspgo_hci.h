#ifndef PSPGO_HCI_H
#define PSPGO_HCI_H
#include "hci_core.h"
/* Kernel-thread-only API. No H4 packet-type prefix. Positive return = byte count.
 * timeout_ms must be 1..1000. One simultaneous call per channel; busy is immediate.
 * Only trusted resident kernel callers may pass pointers. Calls can sleep.
 * No automatic HCI Reset, pairing, radio-mode writes, or HID input injection. */
int pspgoHciGetState(void); /* 0: no HCI interface; 1: attached; negative: not registered */
int pspgoHciSendCommand(const void *packet,unsigned length,unsigned timeout_ms);
int pspgoHciSendAcl(const void *packet,unsigned length,unsigned timeout_ms);
int pspgoHciReadEvent(void *packet,unsigned capacity,unsigned timeout_ms);
int pspgoHciReadAcl(void *packet,unsigned capacity,unsigned timeout_ms);
#endif
