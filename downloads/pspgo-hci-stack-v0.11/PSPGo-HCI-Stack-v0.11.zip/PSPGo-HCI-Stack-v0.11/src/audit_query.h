/* Original read-only query core. No transport or hardware access.
 * Layout references: BlueZ 5.50 tools/bccmd.c cmd_psget/cmd_pslist/
 * cmd_memtypes; tools/parser/csr.c type2str.
 * https://github.com/bluez/bluez/blob/5.50/tools/bccmd.c
 * CSR bcore-sp-005Pe sections 10.3, 10.6, 10.15 and 14.4.
 */
#ifndef PSPGO_AUDIT_QUERY_H
#define PSPGO_AUDIT_QUERY_H
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#define AQ_NATIVE_BYTES 50u
#define AQ_PDU_WORDS 9u
#define AQ_QUERY_COUNT 16u
enum aq_kind { AQ_BUILD, AQ_MEMORY, AQ_SIZE, AQ_SCALAR, AQ_NEXT };
enum aq_result { AQ_OK, AQ_INVALID, AQ_OUTER_ERROR, AQ_BCCMD_ERROR };
struct aq_query { uint16_t varid, key, store; enum aq_kind kind; };
struct aq_value { uint16_t value, status; int valid; };

static inline uint16_t aq_u16(const uint8_t *p) {
    return (uint16_t)((uint16_t)p[0] | (uint16_t)((uint16_t)p[1] << 8));
}
static inline void aq_put(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8);
}

/* Indexing is the entire allowlist: no caller-selected varid/key/store. */
static inline int aq_get_query(size_t index, struct aq_query *out) {
    static const struct aq_query queries[AQ_QUERY_COUNT] = {
        {0x2819,0,0,AQ_BUILD}, {0x3012,0,8,AQ_MEMORY},
        {0x3006,0x03c0,0,AQ_SIZE}, {0x3006,0x03c0,1,AQ_SIZE},
        {0x3006,0x03c0,4,AQ_SIZE}, {0x3006,0x03c0,8,AQ_SIZE},
        {0x3006,0x03cc,0,AQ_SIZE}, {0x3006,0x03cc,1,AQ_SIZE},
        {0x3006,0x03cc,4,AQ_SIZE}, {0x3006,0x03cc,8,AQ_SIZE},
        {0x7003,0x01fd,0,AQ_SCALAR}, {0x7003,0x03cd,0,AQ_SCALAR},
        {0x3005,0x03bf,8,AQ_NEXT}, {0x3005,0x03cb,8,AQ_NEXT},
        {0x7003,0x03c0,8,AQ_SCALAR}, {0x7003,0x03cc,8,AQ_SCALAR}
    };
    if (!out || index >= AQ_QUERY_COUNT) return 0;
    *out = queries[index]; return 1;
}

static inline int aq_build_request(size_t index, uint16_t seq,
                            uint8_t *buf, size_t capacity) {
    struct aq_query q;
    if (!buf || capacity < AQ_NATIVE_BYTES || !aq_get_query(index,&q)) return 0;
    memset(buf,0,AQ_NATIVE_BYTES);
    aq_put(buf,0); aq_put(buf+2,AQ_PDU_WORDS);
    aq_put(buf+4,seq); aq_put(buf+6,q.varid);
    switch (q.kind) {
    case AQ_BUILD: break;
    case AQ_MEMORY: aq_put(buf+10,q.store); break;
    case AQ_SIZE: case AQ_NEXT:
        aq_put(buf+10,q.key); aq_put(buf+12,q.store); break;
    case AQ_SCALAR:
        aq_put(buf+10,q.key); aq_put(buf+12,1); aq_put(buf+14,q.store); break;
    }
    return 1;
}

/* extent bounds readable buffer memory, not necessarily bytes copied on wire.
 * When the native API does not report copied length, AQ_OK establishes only
 * consistency of header/fields in that bounded buffer, not true wire extent.
 * AQ_OK validates only this bounded response, never effective write behavior.
 * Outer errors take precedence: the response buffer is not examined then.
 */
static inline enum aq_result aq_parse_response(size_t index, uint16_t seq,
        uint16_t outer, const uint8_t *buf, size_t extent, struct aq_value *out) {
    struct aq_query q;
    uint16_t declared, minimum;
    if (!out) return AQ_INVALID;
    memset(out,0,sizeof(*out));
    if (!aq_get_query(index,&q)) return AQ_INVALID;
    if (outer) return AQ_OUTER_ERROR;
    if (!buf || extent < 10 || aq_u16(buf) != 1 ||
        aq_u16(buf+4) != seq ||
        aq_u16(buf+6) != q.varid) return AQ_INVALID;
    declared=aq_u16(buf+2);
    if(declared<5 || declared>AQ_NATIVE_BYTES/2) return AQ_INVALID;
    if((size_t)declared*2>extent) return AQ_INVALID;
    out->status = aq_u16(buf+8);
    if (out->status) return AQ_BCCMD_ERROR;
    minimum=q.kind==AQ_BUILD?6:q.kind==AQ_MEMORY || q.kind==AQ_SIZE?7:
            q.kind==AQ_NEXT?8:9;
    if(declared<minimum) return AQ_INVALID;
    switch(q.kind) {
    case AQ_BUILD: out->value=aq_u16(buf+10); break;
    case AQ_MEMORY:
        if(aq_u16(buf+10)!=q.store) return AQ_INVALID;
        out->value=aq_u16(buf+12); break;
    case AQ_SIZE:
        if(aq_u16(buf+10)!=q.key) return AQ_INVALID;
        /* Word 6 is returned SIZE, not an echo of requested stores. */
        out->value=aq_u16(buf+12); break;
    case AQ_NEXT:
        if(aq_u16(buf+10)!=q.key || aq_u16(buf+12)!=q.store) return AQ_INVALID;
        out->value=aq_u16(buf+14); break;
    case AQ_SCALAR:
        if(aq_u16(buf+10)!=q.key || aq_u16(buf+12)!=1 ||
            aq_u16(buf+14)!=q.store) return AQ_INVALID;
        out->value=aq_u16(buf+16); break;
    }
    out->valid=1; return AQ_OK;
}

/* Integration adapters. Caller must reject native transport/outer errors
 * before audit_parse; its signature does not carry those statuses. */
#define AUDIT_QUERY_COUNT AQ_QUERY_COUNT
static inline int audit_make(size_t index, uint16_t seq, uint16_t words[25]) {
    return aq_build_request(index,seq,(uint8_t *)words,AQ_NATIVE_BYTES);
}
static inline int audit_parse(size_t index, uint16_t seq, const uint16_t *words,
        size_t bytes, uint16_t *status, uint16_t *value) {
    struct aq_value out;
    enum aq_result result;
    if (!status || !value) return -1;
    *status=0; *value=0;
    result=aq_parse_response(index,seq,0,(const uint8_t *)words,bytes,&out);
    *status=out.status;
    if(result==AQ_BCCMD_ERROR) return 1;
    if(result!=AQ_OK) return -1;
    *value=out.value; return 0;
}
#endif
