# MIT licensed. Windows PowerShell 5.1, built-in HID driver. No administrator rights needed.
$ErrorActionPreference = 'Stop'
try {
 Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.Drawing
 Add-Type -Path (Join-Path $PSScriptRoot 'Ds4Usb.cs')
 [System.Windows.Forms.Application]::EnableVisualStyles()
 $form = New-Object System.Windows.Forms.Form
 $form.Text = 'PSP Go / DS4 USB pairing test'
 $form.ClientSize = New-Object System.Drawing.Size(660,410)
 $form.StartPosition = 'CenterScreen'
 $form.FormBorderStyle = 'FixedDialog'
 $form.MaximizeBox = $false
 $label = New-Object System.Windows.Forms.Label
 $label.SetBounds(16,12,625,50)
 $label.Text = "Experimental cable-pairing test. Connect one DS4 by USB to this PC.`r`nWriting changes the DS4's saved Bluetooth pairing target."
 $form.Controls.Add($label)
 $fileButton = New-Object System.Windows.Forms.Button
 $fileButton.Text = 'Open PSP host file...'
 $fileButton.SetBounds(16,65,180,30)
 $form.Controls.Add($fileButton)
 $hostBox = New-Object System.Windows.Forms.TextBox
 $hostBox.SetBounds(210,68,210,25)
 $hostBox.ReadOnly = $true
 $form.Controls.Add($hostBox)
 $scan = New-Object System.Windows.Forms.Button
 $scan.Text = 'Read USB controller'
 $scan.SetBounds(16,110,180,30)
 $form.Controls.Add($scan)
 $write = New-Object System.Windows.Forms.Button
 $write.Text = 'Write PSP pairing target'
 $write.SetBounds(210,110,210,30)
 $write.Enabled = $false
 $form.Controls.Add($write)
 $output = New-Object System.Windows.Forms.TextBox
 $output.SetBounds(16,155,625,235)
 $output.Multiline = $true
 $output.ReadOnly = $true
 $output.ScrollBars = 'Vertical'
 $form.Controls.Add($output)
 $script:controller = $null
 $script:hostAddress = $null
 function Note([string]$message) {
  $output.AppendText($message + "`r`n")
  try { Add-Content -LiteralPath (Join-Path $PSScriptRoot 'pairing-helper.log') -Value $message } catch { }
 }
 function LoadHost([string]$path) {
  $value = [System.IO.File]::ReadAllText($path).Trim()
  $null = [Ds4Usb]::ParseAddress($value)
  $script:hostAddress = $value.ToUpperInvariant()
  $hostBox.Text = $script:hostAddress
  Note 'Loaded PSP Bluetooth address from host file.'
  $write.Enabled = ($null -ne $script:controller)
 }
 $fileButton.Add_Click({
  $dialog = New-Object System.Windows.Forms.OpenFileDialog
  $dialog.Filter = 'PSP Bluetooth host file (pspgo_ds4_host.txt)|pspgo_ds4_host.txt'
  try {
   if($dialog.ShowDialog() -eq 'OK'){ LoadHost $dialog.FileName }
  } catch { Note ('Host file error: ' + $_.Exception.Message) } finally { $dialog.Dispose() }
 })
 $scan.Add_Click({
  $script:controller = $null
  $write.Enabled = $false
  try {
   $devices = @([Ds4Usb]::Find())
   if($devices.Count -eq 0){ Note 'No supported USB DS4 found. Check the cable and close other controller apps.'; return }
   if($devices.Count -ne 1){ Note 'More than one DS4 interface found. Leave only one controller attached and read again.'; return }
   $script:controller = $devices[0]
   Note ('DS4 Bluetooth address: ' + $script:controller.Controller)
   Note ('Current paired host: ' + $script:controller.Host)
   $write.Enabled = ($null -ne $script:hostAddress)
  } catch { Note ('Read error: ' + $_.Exception.Message) }
 })
 $write.Add_Click({
  $write.Enabled = $false
  try {
   $after = [Ds4Usb]::SetHost($script:controller,$script:hostAddress)
   Note ('USB read-back confirmed PSP target: ' + $after.Host)
   Note 'This confirms the saved address only, not a Bluetooth connection.'
   Note 'Disconnect DS4 USB. Exit PSP USB mode, enable Bluetooth, then press PS alone.'
   Note 'Try the D-pad in XMB before trying Connect in the menu. See README for the complete test.'
   $script:controller = $after
  } catch { Note ('Write/read-back error: ' + $_.Exception.Message); Note 'The pairing state may have changed; read the controller again.' }
 })
 $default = Join-Path $PSScriptRoot 'pspgo_ds4_host.txt'
 if(Test-Path -LiteralPath $default){try { LoadHost $default } catch { Note ('Host file error: ' + $_.Exception.Message) }}
 Note 'Click Read USB controller first. No write occurs until you click Write PSP pairing target.'
 $null = $form.ShowDialog()
 $form.Dispose()
} catch {
 Write-Host ('Could not start helper: ' + $_.Exception.Message)
 Read-Host 'Press Enter to close'
}
