#ifndef RAM_TEST_H
#define RAM_TEST_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
typedef enum {RAM_BUILD,RAM_MEMORY_TYPE,RAM_DEFAULT,RAM_PSI,RAM_ROM,RAM_ONLY,RAM_ONCHIP,RAM_SET_SAME} RamOp;
/* The only SET representable is USB_VM_CONTROL=1, store=8. No caller-supplied
 * key, store, value, reset or power command exists. */
static inline int ram_request(RamOp op,unsigned seq,uint16_t p[25]){
 if(!p||seq>65535||op<RAM_BUILD||op>RAM_SET_SAME)return -1;
 memset(p,0,50);p[1]=9;p[2]=(uint16_t)seq;
 if(op==RAM_BUILD){p[3]=0x2819;return 0;}
 if(op==RAM_MEMORY_TYPE){p[3]=0x3012;p[5]=8;return 0;}
 p[3]=0x7003;p[5]=op==RAM_ONCHIP?0x03cc:0x03c0;p[6]=1;
 if(op==RAM_PSI)p[7]=1;if(op==RAM_ROM)p[7]=4;
 if(op==RAM_ONLY||op==RAM_SET_SAME)p[7]=8;
 if(op==RAM_SET_SAME){p[0]=2;p[8]=1;}return 0;
}
/* 0 scalar/success, 1 BCCMD error, -1 malformed. Outer errors handled first. */
static inline int ram_response(RamOp op,unsigned seq,const uint16_t p[25],size_t n,unsigned *value,unsigned *status){
 uint16_t expected[25];if(!p||!value||!status||ram_request(op,seq,expected)<0||n<10)return -1;
 if(p[0]!=1||p[1]<5||p[1]>25||p[1]*2u>n||p[2]!=seq||p[3]!=expected[3])return -1;
 *status=p[4];if(*status)return 1;
 if(op==RAM_BUILD){if(p[1]<6)return -1;*value=p[5];return 0;}
 if(op==RAM_MEMORY_TYPE){if(p[1]<7||p[5]!=8)return -1;*value=p[6];return 0;}
 /* SET success is a validated response header/status. Its payload is not
  * used as evidence of storage: the independent GET must establish that. */
 if(op==RAM_SET_SAME){*value=0;return 0;}
 if(p[1]<9||p[5]!=expected[5]||p[6]!=1||p[7]!=expected[7])return -1;
 *value=p[8];return 0;
}
static inline int ram_baseline_ok(unsigned build,unsigned memory_type,unsigned def,unsigned psi,unsigned rom,unsigned onchip){
 return build==0x1918&&memory_type==2&&def==1&&psi==1&&rom==0&&onchip==1;
}
#endif
