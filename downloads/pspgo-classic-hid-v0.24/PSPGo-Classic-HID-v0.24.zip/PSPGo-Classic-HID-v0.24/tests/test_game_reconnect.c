#include "game_reconnect.h"
#include <assert.h>
#include <stdio.h>
static unsigned queries,calls,match_slot=1,extra_slot,flags=0x0602,mutation;
static int status,was_active,last_slot,last_mode;
static int query(int slot,void *out){
 uint8_t *p=out;assert(p[0]==80&&!((uintptr_t)p&15));queries++;
 if((unsigned)slot!=match_slot&&(unsigned)slot!=extra_slot)return -1;
 p[4]=(uint8_t)slot;
 const char *n="Zeemote: SteelSeries Free";for(unsigned i=0;i<=strlen(n);i++)p[6+i*2]=(uint8_t)n[i];
 p[72]=(uint8_t)flags;p[73]=(uint8_t)(flags>>8);
 if(mutation==1)p[6]='X';
 if(mutation==2)p[7]=1;
 if(mutation==3)p[4]=0;
 if(mutation==4)p[0]=84;
 if(mutation==5)p[5]=1;
 if(mutation==6)p[6]='z';
 if(mutation==7)p[6+2*strlen(n)]='!';
 return status;
}
static int connect(int slot,int mode){assert(!was_active);calls++;last_slot=slot;last_mode=mode;return -123;}
static void reset(void){queries=calls=extra_slot=mutation=was_active=0;match_slot=1;status=0;flags=0x0602;}
int main(void){
 reset();ZeeReconnect d=zee_game_reconnect(0,query,connect);
 assert(d.queries==8&&queries==8&&d.matches==1&&d.attempted&&calls==1&&last_slot==1&&last_mode==0&&d.result==-123);
 for(unsigned slot=1;slot<=8;slot++){reset();match_slot=slot;flags=0x0402;d=zee_game_reconnect(0,query,connect);assert(calls==1&&last_slot==(int)slot&&last_mode==1);}
 reset();flags=0x0202;d=zee_game_reconnect(0,query,connect);assert(calls==1&&last_mode==0);
 for(unsigned i=1;i<=7;i++){reset();mutation=i;d=zee_game_reconnect(0,query,connect);assert(calls==((i==1||i==2||i==6||i==7)?1u:0u));}
 reset();extra_slot=2;d=zee_game_reconnect(0,query,connect);assert(d.matches==2&&!calls&&!d.attempted);
 reset();status=-1;d=zee_game_reconnect(0,query,connect);assert(!calls&&!d.matches);
 reset();flags=2;d=zee_game_reconnect(0,query,connect);assert(!calls);
 reset();was_active=1;d=zee_game_reconnect(1,query,connect);assert(!queries&&!calls);
 reset();d=zee_game_reconnect(0,NULL,connect);assert(!queries&&!calls);
 reset();extra_slot=2;ZeeTarget target={.slot=2,.valid=1};
 d=zee_game_reconnect_target(0,query,connect,&target);assert(d.attempted&&calls==1&&last_slot==2);
 reset();target.address[0]=99;d=zee_game_reconnect_target(0,query,connect,&target);assert(!calls);
 reset();uint8_t record[80]={80},encoded[16];query(1,record);record[74]=0xab;
 assert(!zee_target_encode(record,1,encoded));target=zee_target_decode(encoded,16);
 assert(target.valid&&target.slot==1&&target.address[0]==0xab);
 assert(!zee_target_decode(encoded,15).valid);encoded[0]^=1;assert(!zee_target_decode(encoded,16).valid);encoded[0]^=1;
 encoded[4]=9;assert(!zee_target_decode(encoded,16).valid);encoded[4]=1;encoded[7]=1;assert(!zee_target_decode(encoded,16).valid);
 puts("PASS: fresh aligned eight-slot queries, populated saved HID name/ID/size/flags, unique target or preferred slot/address, native mode selection, active/ambiguous/error rejection and once-only original connection result");
}
