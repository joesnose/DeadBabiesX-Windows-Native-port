# HCI transition: established facts and remaining gates

Known radio: build 6424, loader 5925, chip-version code 5, revision 00E1.
Prior default reads: ONCHIP_HCI_CLIENT=1, USB_VM_CONTROL=1,
HOST_INTERFACE=2, INITIAL_BOOTMODE=1. No marketed chip identity inferred.

CSR's Bluetooth and USB Design Considerations, Issue 4, p35:
USB_VM_CONTROL=false configures HCI Bluetooth enumeration; true gives USB to VM.
https://hacker.instanet.net/Bluetooth/CS-101412-AN-4.pdf

CSR BlueSuite User Guide, Issue 3, section 5.3: unified builds can present HCI or
RFCOMM, selected by ONCHIP_HCI_CLIENT, with details delegated to build release
files. The exact Sony firmware release files/image have not been located.
https://fccid.io/PIWBSMAN/User-Manual/User-Guide-1135316.pdf

BlueZ 5.50 tools/bccmd.c identifies selectors 1/2/4/8 as PSI/PSF/PSROM/PSRAM.
Its psset defaults to PSRAM. BTstack's CSR adapter likewise uses store 0008 and
warm reset in its init script. That adapter is NOT linked here: it also changes
clock/UART/address settings that must not be applied to the Go.
https://github.com/bluez/bluez/blob/5.50/tools/bccmd.c
https://github.com/bluekitchen/btstack/blob/master/chipset/csr/btstack_chipset_csr.c

The PSP symbol catalogue names sceSysconCtrlBtPower (NID 9C4266FC). A symbol name
alone is not proof of its ABI, that it fully removes radio power, that it clears
PSRAM, or that a blocked USB host can recover through it. It is not called here.

Before a transition build:

- Establish where each current mode value is supplied (new per-store GETs).
- Establish whether mode changes activate immediately or only on reset, and
  whether the management channel survives long enough to complete both changes.
- Verify the Sony radio's PSRAM-only write semantics and reset/retention behavior.
- Establish an independent power/reset recovery route and ownership coordination
  with BSM/CDC during USB re-enumeration; avoid racing Sony's initialization.
- Validate resulting interface descriptors, endpoint binding and native transfers.
- Only then run the compiled host stack against the DS4 and validate SSP, bond
  reconnect, SDP/HID, input and failure recovery on hardware.

No successful exposure, recovery or DS4 connection is claimed. The additional
store reads do not prove reversibility. No SET/reset implementation is shipped.

## v0.4 next prerequisite

The two identical v0.3 hardware runs located each current 1 override in selector
0001 and returned 0 for selector 0004; selectors 0002 and 0008 returned outer0050.
No conclusion about RAM writability follows from that rejection alone.

BlueZ 5.50 bccmd memtypes uses GET varid3012 with the store selector as the first
payload word; returned type2 means transient RAM. The new test gates a single
same-value USB_VM_CONTROL=1/store8 SET on that response and exact known baseline,
then records readback and a later-start observation. No off value, reset, power
control or HCI transition is implemented. The previous "no SET implementation"
statement applies to v0.3; this narrowly fixed v0.4 SET is the sole exception.

References: https://github.com/bluez/bluez/blob/5.50/tools/bccmd.c (cmd_memtypes,
memorytostr, cmd_psset), https://github.com/bluez/bluez/blob/5.50/tools/csr.h .
Protocol constants were independently implemented; no GPL tool source copied.
