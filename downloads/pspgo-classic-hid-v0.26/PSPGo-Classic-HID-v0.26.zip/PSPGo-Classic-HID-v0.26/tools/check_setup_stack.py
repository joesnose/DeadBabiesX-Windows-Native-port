#!/usr/bin/env python3
"""Regression check for the new setup wrapper; not complete firmware proof."""
import json,sys
from check_hid_stack import functions

def writes_gp(w):
    op=w>>26;rt=(w>>16)&31;rd=(w>>11)&31;fn=w&63
    return ((op in list(range(8,16))+[32,33,35,36,37,39] and rt==28) or
            (op==0 and rd==28 and fn in [0,2,3,4,6,7,16,18,32,33,34,35,36,37,38,39,42,43]))
f=functions(sys.argv[1]);names=['setup_dispatch','setup_wait_pause']
frames={n:f[n][2] for n in names}
no_gp_writes=not any(writes_gp(w) for n in names for w in f[n][1])
dispatch_tailcall=0x03200008 in f['setup_dispatch'][1] and not any(w>>26==3 for w in f['setup_dispatch'][1])
# Known native management caller64 and setup592. Thunk32 only exists on pause,
# not during descriptor parsing. Native delay helpers require separate review.
budget=64+592+32+frames['setup_dispatch']+frames['setup_wait_pause']+128
ok=frames['setup_dispatch']==0 and frames['setup_wait_pause']<=64 and no_gp_writes and dispatch_tailcall and budget<1024
print(json.dumps(dict(frames=frames,dispatch_tailcall=dispatch_tailcall,no_gp_writes=no_gp_writes,
                     known_pause_budget_with_helper_allowance=budget,management_thread_bytes=3072,pass_check=ok),indent=2))
raise SystemExit(0 if ok else 1)
