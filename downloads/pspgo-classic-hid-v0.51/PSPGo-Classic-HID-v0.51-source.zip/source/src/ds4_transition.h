/* Selected DS4 transition policy; native authentication remains live. */
#ifndef DS4_TRANSITION_H
#define DS4_TRANSITION_H
static inline int ds4_transition_defer(unsigned context,int selected,int linked){return selected&&(context!=0x200u||linked);}
static inline int ds4_transition_mode(unsigned context,int selected,int mode){return context==0x200u&&selected?0:mode;}
#endif
