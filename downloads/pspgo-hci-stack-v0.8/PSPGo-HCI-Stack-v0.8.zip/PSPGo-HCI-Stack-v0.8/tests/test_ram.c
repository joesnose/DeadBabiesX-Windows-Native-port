#define HCI_RAM_HOST_TEST
#include "../src/preflight_v07.c"
#include <assert.h>
#include <stdio.h>
static int once,verified,present,ram_value,sets,mem_type,default_value,failmarker,failset,malformed,badack,ram_reads,post_reads,legacy,legacy_verified,noecho,shortack;
static char output[8];static int current_file,writing,read_done;
int pspSdkSetK1(int k){(void)k;return 0;}void hci_log(const char *f,...){(void)f;}
int sceIoOpen(const char *p,int flags,int mode){(void)mode;current_file=!strcmp(p,ONCE_PATH)?1:!strcmp(p,VERIFIED_PATH)?2:!strcmp(p,LEGACY_PATH)?3:4;writing=!!(flags&PSP_O_WRONLY);read_done=0;
 int exists=current_file==1?once:current_file==2?verified:current_file==3?legacy:legacy_verified;if(!writing)return exists?1:(int)0x80010002;
 if(exists||failmarker)return -1;if(current_file==1)once=1;else verified=1;return 1;
}
int sceIoRead(int f,void *p,unsigned n){(void)f;if(read_done)return 0;read_done=1;assert(n==9);if(current_file>=3){const char token[8]={'R','A','M','4',0xc0,3,8,1};memcpy(p,token,8);}else memcpy(p,output,8);return 8;}
int sceIoWrite(int f,const void *p,unsigned n){(void)f;assert(writing&&n==8);memcpy(output,p,8);return 8;}
int sceIoClose(int f){(void)f;return 0;}int sceIoSync(const char *p,int mode){(void)p;(void)mode;return 0;}
static int native_query(const Request *q,Response *r){
 const uint16_t *tx=q->data;uint16_t *rx=r->data;memcpy(rx,tx,50);rx[0]=tx[0]+1;r->status=0;
 assert(tx[3]==0x2819||tx[3]==0x3012||tx[3]==0x7003);assert(q->id==0x70&&q->length==50);
 if(tx[0]==2){assert(tx[3]==0x7003&&tx[5]==0x3c0&&tx[6]==1&&tx[7]==8&&tx[8]==1);sets++;if(failset){r->status=0x50;return 1;}present=1;ram_value=1;if(noecho)memset(rx+5,0,8);if(shortack)rx[1]=5;if(badack)rx[0]=2;}
 else if(tx[3]==0x2819)rx[5]=0x1918;
 else if(tx[3]==0x3012){assert(tx[5]==8);rx[6]=(uint16_t)mem_type;}
 else if(tx[5]==0x3cc)rx[8]=1;
 else {assert(tx[5]==0x3c0);if(sets)post_reads++;if(tx[7]==8){ram_reads++;if(!present){r->status=0x50;return 1;}rx[8]=(uint16_t)ram_value;}else rx[8]=tx[7]==4?0:tx[7]==1?1:(uint16_t)default_value;}
 if(malformed)rx[2]++;return 1;
}
static void reset(void){once=verified=present=ram_value=sets=failmarker=failset=malformed=badack=ram_reads=post_reads=legacy_verified=noecho=shortack=0;legacy=1;mem_type=2;default_value=1;sequence=1;query=native_query;memset(output,0,8);}
int main(void){
 uint16_t p[25];unsigned v,s;
 assert(ram_request(RAM_SET_SAME,1,p)==0&&p[0]==2&&p[5]==0x3c0&&p[7]==8&&p[8]==1);
 assert(ram_request((RamOp)99,1,p)<0);assert(ram_request(RAM_SET_SAME,65536,p)<0);
 assert(!ram_request(RAM_MEMORY_TYPE,1,p));p[0]=1;p[6]=2;assert(!ram_response(RAM_MEMORY_TYPE,1,p,50,&v,&s)&&v==2);assert(ram_response(RAM_MEMORY_TYPE,1,p,12,&v,&s)<0);
 assert(!ram_request(RAM_SET_SAME,7,p));p[0]=3;p[5]=p[6]=p[7]=p[8]=0;
 assert(!ram_response(RAM_SET_SAME,7,p,50,&v,&s));
 p[0]=1;assert(ram_response(RAM_SET_SAME,7,p,50,&v,&s)<0);p[0]=3;
 p[2]=8;assert(ram_response(RAM_SET_SAME,7,p,50,&v,&s)<0);p[2]=7;
 p[3]=0x7004;assert(ram_response(RAM_SET_SAME,7,p,50,&v,&s)<0);p[3]=0x7003;
 p[4]=5;assert(ram_response(RAM_SET_SAME,7,p,50,&v,&s)==1&&s==5);p[4]=0;
 assert(ram_response(RAM_SET_SAME,7,p,9,&v,&s)<0);
 reset();ram_session();assert(sets==1&&present&&once&&verified);ram_session();assert(sets==1);
 present=0;ram_session();assert(sets==1&&verified); /* next boot: no repeat SET */
 reset();noecho=1;ram_session();assert(sets==1&&verified); /* ACK payload need not echo */
 reset();shortack=1;ram_session();assert(sets==1&&verified); /* header-only success */
 reset();legacy=0;ram_session();assert(sets==1&&once&&verified);
 reset();legacy_verified=1;ram_session();assert(sets==1&&once&&verified);
 reset();badack=1;ram_session();assert(sets==1&&once&&!verified&&ram_reads==2&&post_reads>=4);
 ram_session();assert(sets==1&&!verified); /* old marker is authoritative even when RAM reads1 */
 reset();mem_type=0;ram_session();assert(!sets&&!once);reset();default_value=0;ram_session();assert(!sets);
 reset();failmarker=1;ram_session();assert(!sets&&!verified);
 reset();failset=1;ram_session();assert(sets==1&&once&&!verified&&ram_reads==2&&post_reads>=4);ram_session();assert(sets==1);
 reset();malformed=1;ram_session();assert(!sets&&!once);
 reset();present=1;ram_value=1;ram_session();assert(!sets&&!once);
 reset();once=1;ram_session();assert(!sets&&!verified); /* corrupt marker blocks */
 puts("RAM test: fixed same-value SET, transient-store/baseline gates, response bounds, durable marker prerequisite, readback, refusal paths and no repeated writes passed (mock radio/filesystem)");
}
