/* Mocked USB host exercises driver logic; does not emulate Sony USB hardware. */
#define HCI_HOST_TEST
#include "../src/main.c"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static int sems[32],nextsem,scenario,cancelled,closed,submitted,control_calls;
static int pending_pipe;static Completion pending_cb;static void *pending_arg;
static uint64_t clock_us;
static unsigned reported_fw=0x06060110;
static uint8_t iface[9]={9,4,0,0,3,0xe0,1,1,0};
static uint8_t eps[3][7]={{7,5,0x81,3,16,0,1},{7,5,0x82,2,64,0,0},{7,5,0x02,2,64,0,0}};
int pspSdkSetK1(int a){(void)a;return 0;}void prnt(void (*a)(void *,int),void *b,const char *c,va_list d){(void)a;(void)b;(void)c;(void)d;}
int sceIoOpen(const char *a,int b,int c){(void)a;(void)b;(void)c;return -1;}int sceIoWrite(int a,const void *b,unsigned c){(void)a;(void)b;return (int)c;}int sceIoClose(int a){(void)a;return 0;}
int sceKernelWaitSema(int id,int n,SceUInt *t){if(t&&scenario==5){scenario=0;assert(detach(7)==0);}if(sems[id]>=n){sems[id]-=n;return 0;}if(t){clock_us+=*t;return -1;}assert(!"unexpected blocking semaphore");return -1;}
int sceKernelSignalSema(int id,int n){sems[id]+=n;assert(sems[id]<=1);return 0;}
int sceKernelPollSema(int id,int n){if(sems[id]<n)return -1;sems[id]-=n;return 0;}
int sceKernelCpuSuspendIntr(void){return 0;}void sceKernelCpuResumeIntr(int x){(void)x;}
void sceKernelDcacheWritebackInvalidateRange(void *p,unsigned n){(void)p;(void)n;}void sceKernelDcacheInvalidateRange(void *p,unsigned n){(void)p;(void)n;}
SceModule *sceKernelFindModuleByName(const char *n){(void)n;return NULL;}uintptr_t sctrlHENFindFunction(const char *a,const char *b,uint32_t c){(void)a;(void)b;(void)c;return 0;}uint32_t _lw(uintptr_t x){(void)x;return 0;}
int sceKernelIsIntrContext(void){return 0;}uint64_t sceKernelGetSystemTimeWide(void){return clock_us;}int sceKernelDelayThread(unsigned x){clock_us+=x;return 0;}
int sceKernelGetModel(void){return 4;}unsigned sceKernelDevkitVersion(void){return reported_fw;}
int sceKernelCreateSema(const char *a,int b,int c,int d,void *e){(void)a;(void)b;(void)d;(void)e;int id=++nextsem;sems[id]=c;return id;}int sceKernelDeleteSema(int a){(void)a;return 0;}
int sceKernelCreateThread(const char *a,int (*b)(SceSize,void *),int c,int d,int e,void *f){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;return 1;}int sceKernelStartThread(int a,int b,void *c){(void)a;(void)b;(void)c;return 0;}int sceKernelDeleteThread(int a){(void)a;return 0;}
static int info(uint32_t id,uint8_t type,uint8_t ix,uint8_t extra,void *p,unsigned n){(void)id;(void)extra;if(type==0x14&&n==9){memcpy(p,iface,9);return 9;}if(type==5&&ix<3&&n==7){memcpy(p,eps[ix],7);return 7;}return -1;}
static int open_pipe(uint32_t id,uint8_t ep){(void)id;return 100+ep;}
static int close_pipe(int p){assert(p>0);closed++;return 0;}
static int cancel_pipe(int p){cancelled++;if(pending_cb&&pending_pipe==p&&scenario!=4){Completion cb=pending_cb;pending_cb=NULL;cb(p,-9,0,pending_arg);}return 0;}
static int bulk(int pipe,void *p,int n,Completion cb,void *arg,int timeout,uint16_t flags){
 (void)timeout;assert(flags==5||flags==13);submitted++;
 if(scenario==2)return -33;
 if(scenario==3||scenario==4||scenario==5){pending_pipe=pipe;pending_cb=cb;pending_arg=arg;return 0;}
 if(pipe==100+0x82){static const uint8_t acl[]={1,0,2,0,0xaa,0xbb};memcpy(p,acl,sizeof(acl));cb(pipe,0,sizeof(acl),arg);}else cb(pipe,0,n,arg);return 0;
}
static int intr(int pipe,void *p,int n,Completion cb,void *arg,uint16_t flags){
 assert(n>=(int)HCI_MAX_EVENT&&n<=320);if(scenario>=2)return bulk(pipe,p,n,cb,arg,0,flags);
 static const uint8_t events[]={0x0e,1,0xaa,0x0f,0};memcpy(p,events,sizeof(events));submitted++;cb(pipe,0,sizeof(events),arg);return 0;
}
static int control(uint32_t id,const Setup *s,void *p,int t,uint16_t f){(void)id;assert(s->type==0x20&&s->request==0&&s->value==0&&s->index==0&&t>0&&f==0);assert(hci_valid_command(p,s->length));control_calls++;return s->length;}
static void reset(void){
 memset(channel,0,sizeof(channel));memset(sems,0,sizeof(sems));nextsem=0;pending_cb=NULL;scenario=cancelled=closed=submitted=control_calls=0;clock_us=0;
 attached=0;generation=0;registered=1;life=sceKernelCreateSema("",0,1,1,NULL);
 for(unsigned i=0;i<3;i++)channel[i].done_sem=sceKernelCreateSema("",0,0,1,NULL);
 host_info=info;host_open=open_pipe;host_close=close_pipe;host_cancel=cancel_pipe;host_bulk=bulk;host_interrupt=intr;host_control=control;
 assert(attach(7)==0);assert(pspgoHciGetState()==1);
}
int main(void){
 reset();uint8_t out[HCI_MAX_ACL];const uint8_t cmd[]={3,12,0},acl[]={1,0,0,0};
 assert(pspgoHciSendCommand(cmd,sizeof(cmd),100)==3&&control_calls==1);
 assert(pspgoHciSendAcl(acl,sizeof(acl),100)==4);
 assert(pspgoHciReadEvent(out,sizeof(out),100)==3&&out[2]==0xaa);
 assert(pspgoHciReadEvent(out,sizeof(out),100)==2&&out[0]==0x0f);
 assert(submitted==2);assert(pspgoHciReadAcl(out,sizeof(out),100)==6&&out[5]==0xbb);
 assert(pspgoHciSendCommand(cmd,2,100)==HCI_ERR_ARGUMENT);assert(pspgoHciReadAcl(out,4,0)==HCI_ERR_ARGUMENT);
 assert(detach(7)==0&&closed==3&&pspgoHciGetState()==0);assert(pspgoHciSendAcl(acl,4,10)==HCI_ERR_DISCONNECTED);
 reset();Channel *c;assert(begin(0,&c)==0);assert(begin(0,&c)==HCI_ERR_BUSY);assert(detach(7)==0);assert(!channel[0].poison);assert(finish(&channel[0],0)==0);assert(attach(8)==0);
 reset();scenario=2;assert(pspgoHciReadEvent(out,sizeof(out),10)==-33);assert(!channel[0].pending&&!channel[0].busy);
 reset();scenario=3;assert(pspgoHciReadEvent(out,sizeof(out),10)==HCI_ERR_TIMEOUT);assert(cancelled==1&&!channel[0].poison&&!channel[0].busy);assert(detach(7)==0);
 reset();scenario=5;assert(pspgoHciReadEvent(out,sizeof(out),10)==HCI_ERR_DISCONNECTED);assert(closed==3&&!channel[0].busy);assert(attach(8)==0);
 reset();scenario=4;assert(pspgoHciReadEvent(out,sizeof(out),10)==HCI_ERR_PROTOCOL);assert(channel[0].poison&&channel[0].busy);assert(pspgoHciGetState()==0);assert(attach(8)==HCI_ERR_BUSY);
 reset();reported_fw=0x06060010;assert(module_start(0,NULL)==0);
 reported_fw=0x06060110;assert(module_start(0,NULL)==0);
 reported_fw=0x06050010;assert(module_start(0,NULL)==-1);
 puts("transport mock: version gates, routing, packet retention, validation, timeout cancellation, detach/reconnect, ownership and failed-cancel quarantine passed");return 0;
}
