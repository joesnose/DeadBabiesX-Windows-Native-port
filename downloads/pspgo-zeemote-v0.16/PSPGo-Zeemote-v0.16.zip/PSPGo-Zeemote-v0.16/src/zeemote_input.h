#ifndef ZEEMOTE_INPUT_H
#define ZEEMOTE_INPUT_H
#include "zeemote_hid.h"
int zee_input_install(void);
void zee_input_update(const ZeeState *state);
void zee_input_clear(void);
/* Refreshes an existing state only; called by the trusted live-session monitor. */
void zee_input_keepalive(void);
#endif
