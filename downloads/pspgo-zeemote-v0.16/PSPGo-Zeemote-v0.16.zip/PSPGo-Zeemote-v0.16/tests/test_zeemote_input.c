#define ZEE_INPUT_HOST_TEST
#include "../src/zeemote_input.c"
#include <assert.h>
#include <stdio.h>
static uint64_t time_us;static unsigned patches;static int original_result=1;static unsigned physical;
uint64_t sceKernelGetSystemTimeWide(void){return time_us;}
int sceKernelCpuSuspendIntr(void){return 0;}void sceKernelCpuResumeIntr(int x){(void)x;}
void sceKernelDcacheWritebackAll(void){}void sceKernelIcacheInvalidateAll(void){}
static int native_read(SceCtrlData *p,int n){if(original_result>0&&n>0){memset(p,0,sizeof(*p));p->Buttons=physical;p->Lx=128;p->Ly=128;}return original_result;}
uintptr_t sctrlHENFindFunction(const char *a,const char *b,uint32_t n){(void)a;(void)b;(void)n;return (uintptr_t)native_read;}
void sctrlHENPatchSyscall(void *a,void *b){assert(a&&(a!=b));patches++;}
int main(void){
 assert(zee_input_install()==0&&patches==4);assert(zee_input_install()==0&&patches==4);
 ZeeState s={.buttons=0x4000,.lx=0,.ly=255};zee_input_update(&s);SceCtrlData out;
 physical=8;assert(peek_pos(&out,1)==1&&out.Buttons==0x4008&&out.Lx==0&&out.Ly==255);
 physical=~8u;assert(read_neg(&out,1)==1&&out.Buttons==~0x4008u);
 s.lx=s.ly=128;zee_input_update(&s);physical=8;assert(read_pos(&out,1)==1&&out.Lx==128&&out.Ly==128);
 time_us=1000000;zee_input_keepalive();time_us=2000000;assert(read_pos(&out,1)==1&&out.Buttons==0x4008);
 time_us=2500000;assert(read_pos(&out,1)==1&&out.Buttons==8);time_us=0;zee_input_update(&s);zee_input_clear();assert(peek_pos(&out,1)==1&&out.Buttons==8);
 original_result=-7;assert(read_pos(&out,1)==-7);original_result=0;assert(read_pos(&out,1)==0);
 puts("input adapter: four syscall selections, positive/negative button merge, analog dead zone, live-session keepalive for unchanged reports, 1500ms monitor timeout, disconnect neutral and original-error preservation passed (mock calls)");return 0;
}
