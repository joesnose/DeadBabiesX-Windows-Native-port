#ifndef REGISTRATION_POLICY_H
#define REGISTRATION_POLICY_H
#include <stdint.h>
#include <string.h>
#define PIN_STUB_WORDS 128
#define PIN_WRAPPER_OFFSET 320
#define PIN_TABLE_OFFSET 448
#define PIN_STUB_BYTES (PIN_STUB_WORDS*4)
_Static_assert(sizeof("zeemote: steelseries free")*2<=PIN_WRAPPER_OFFSET-256,
               "UTF16 target name including NUL must fit before constructor wrapper");
typedef struct {uint32_t entry,constructor_entry,pin_zero_delay,code[PIN_STUB_WORDS];} NativePinPlan;
/* One verified UI call site only. All offsets are from the examined UI module.
 * ASCII-case-insensitive exact discovery name selects the user-requested Zeemote target; it is not
 * proof of hardware identity or Gamepad mode. No CoD minor value is assumed. */
static inline int native_pin_context(uint32_t base,const uint32_t c[13]){
 uint32_t call,ctor,alloc,memset_call,branch;
 if(!c||base>0xfffdf48fu||mips_jump(base+0x13f1c,base+0x1427c,&call)||
 mips_jump(base+0x13f3c,base+0x13a84,&ctor)||mips_jump(base+0x13f2c,base+0x1abe0,&alloc)||
 mips_jump(base+0x13af8,base+0x1a9b8,&memset_call)||mips_jump(base+0x13f44,base+0x13f00,&branch))return 0;
 return c[0]==(call|0x04000000u)&&c[1]==0x02002821u&&c[2]==0x10400009u&&c[3]==0x02202021u&&
 c[4]==(alloc|0x04000000u)&&c[5]==0x24040078u&&c[6]==(ctor|0x04000000u)&&c[7]==0x00408021u&&
 c[8]==branch&&c[9]==0x02001821u&&c[10]==(memset_call|0x04000000u)&&c[11]==0x24060010u&&c[12]==base+0x13b28;
}
static inline int native_pin_plan(uint32_t base,uint32_t stub,const uint32_t context[13],NativePinPlan *out){
 if(!out||!native_pin_context(base,context)||stub>0xffffffffu-PIN_STUB_BYTES||(stub&3))return -1;
 NativePinPlan p;memset(&p,0,sizeof(p));uint32_t j;
 if(mips_jump(base+0x13f1c,stub,&j))return -1;
 p.entry=j|0x04000000u;
 /* Sole examined constructor caller allocates120 bytes; PIN at+88 fits32. */
 p.pin_zero_delay=0x24060020u;
 /* v0 reproduces the original predicate. Other written registers are caller
  * temporaries. a0/a1, saved registers, sp and ra remain untouched. */
 uint32_t code[]={
  0x90a20000u,0x30420020u,0x1440001au,0, /* original predicate -> accept29 */
  0x8ca3ffb8u,0x24080054u,0x14680019u,0, /* real discovery record84 */
  0x94a3ffbcu,0x10600016u,0, /* nonzero discovery identifier */
  0x24a8ffbeu, /* t0 points at record+6 UTF16 name */
  0,0, /* t1 points at canonical lowercase inline name */
  0x950a0000u,0x952b0000u, /* input and expected UTF16 code units */
  0x2543ffbfu,0x2c63001au, /* unsigned(input-'A') < 26 */
  0x10600002u,0,0x354a0020u, /* fold only ASCII A-Z; preserve other Unicode */
  0x154b000au,0, /* mismatch -> reject32 */
  0x11400005u,0, /* matching NUL -> accept29 */
  0x25080002u,0x25290002u,0x1000fff2u,0, /* next code unit ->14 */
  0x24020001u,0x03e00008u,0, /* accept29 */
  0x00001021u,0x03e00008u,0 /* reject32 */
 };
 uint32_t name=stub+256;code[12]=0x3c090000u|(name>>16);code[13]=0x35290000u|(name&0xffff);
 memcpy(p.code,code,sizeof(code));
 const char *name_text="zeemote: steelseries free";
 for(unsigned i=0;name_text[i];i++){unsigned byte=256+i*2;p.code[byte/4]|=(uint32_t)(uint8_t)name_text[i]<<((byte%4)*8);}
 *out=p;return 0;
}
/* Clone the PIN object's methods; only its category callback changes. */
static inline int native_pin_hybrid_plan(uint32_t base,uint32_t stub,const uint32_t context[13],
 const uint32_t table[14],const uint32_t category[2],NativePinPlan *out){
 static const uint32_t offsets[14]={0x1a528,0x1a538,0x13b28,0x13b48,0x1a4d8,0x13b50,0x13958,0x1a508,0x13984,0x1a560,0x1a518,0x1a520,0,0};
 if(base>0xffffffffu-0x20ba0u||!table||!category||!out||category[0]!=0x03e00008u||category[1]!=0x24020002u)return -1;
 for(unsigned i=0;i<14;i++)if(table[i]!=(offsets[i]?base+offsets[i]:0))return -1;
 NativePinPlan p;if(native_pin_plan(base,stub,context,&p))return -1;
 uint32_t target;
 if(mips_jump(base+0x13f3c,stub+PIN_WRAPPER_OFFSET,&target))return -1;
 p.constructor_entry=target|0x04000000u;
 uint32_t ctor,strict;
 if(mips_jump(stub+PIN_WRAPPER_OFFSET+6*4,base+0x13a84,&ctor)||
    mips_jump(stub+PIN_WRAPPER_OFFSET+11*4,stub+16,&strict))return -1;
 uint32_t clone=stub+PIN_TABLE_OFFSET;
 uint32_t wrapper[]={
  0x27bdffe0u,0xafbf001cu,0xafa40018u,0xafa50014u,
  0x10800012u,0, /* null allocation -> guarded return without constructor */
  ctor|0x04000000u,0,0xafa20010u,0x8fa50014u,0x24a50048u,
  strict|0x04000000u,0,0x10400005u,0, /* strict match, not audio shortcut */
  0x8fa40018u,0x3c030000u|(clone>>16),0x34630000u|(clone&0xffff),0xac830000u,
  0x8fa20010u,0x8fbf001cu,0x03e00008u,0x27bd0020u,
  0x00001021u,0x8fbf001cu,0x03e00008u,0x27bd0020u
 };
 memcpy(&p.code[PIN_WRAPPER_OFFSET/4],wrapper,sizeof(wrapper));
 memcpy(&p.code[PIN_TABLE_OFFSET/4],table,14*4);
 p.code[PIN_TABLE_OFFSET/4+3]=base+0x13950;
 *out=p;return 0;
}
#endif
