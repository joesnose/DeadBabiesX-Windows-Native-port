$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'Ds4Usb.cs')
function Check($condition, $message) { if(-not $condition){ throw $message } }
foreach($length in @(23,64)) {
 $report = [Ds4Usb]::PairingReport('02:17:3B:80:A5:FE',$length)
 Check ($report.Length -eq $length) 'Wrong feature buffer length'
 Check (($report[0..6] -join ',') -eq '19,254,165,128,59,23,2') 'Report ID/host address byte order incorrect'
 Check (($report[7..($length-1)] | Where-Object {$_ -ne 0}).Count -eq 0) 'Key/padding must be zero'
}
foreach($bad in @('', '00:00:00:00:00:00','FF:FF:FF:FF:FF:FF','02-17-3B-80-A5-FE','02:17:3B:80:A5:FE extra','GG:17:3B:80:A5:FE')) {
 $caught = $false
 try { $null = [Ds4Usb]::PairingReport($bad,64) } catch { $caught = $true }
 Check $caught ('Invalid address accepted: ' + $bad)
}
foreach($length in @(0,22,4097)) {
 $caught = $false
 try { $null = [Ds4Usb]::PairingReport('02:17:3B:80:A5:FE',$length) } catch { $caught = $true }
 Check $caught 'Invalid feature length accepted'
}
$read = New-Object byte[] 64
$read[0] = 0x12
[byte[]]$own = @(6,5,4,3,2,1)
[byte[]]$hostMac = @(254,165,128,59,23,2)
[Array]::Copy($own,0,$read,1,6)
[Array]::Copy($hostMac,0,$read,10,6)
Check ([Ds4Usb]::AddressText($read,1) -eq '01:02:03:04:05:06') 'DS4 own address decode incorrect'
Check ([Ds4Usb]::AddressText($read,10) -eq '02:17:3B:80:A5:FE') 'DS4 host address decode incorrect'
$tokens = $null; $errors = $null
$null = [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'Pair-DS4.ps1'), [ref]$tokens,[ref]$errors)
Check ($errors.Count -eq 0) ('PowerShell parse error: ' + ($errors -join '; '))
Write-Output 'PASS: C# compilation; report 0x13, little-endian address, zero key/padding, input rejection, read-back decoding, PowerShell script syntax.'
Write-Output 'Windows HID enumeration, USB I/O and GUI require hardware testing.'
