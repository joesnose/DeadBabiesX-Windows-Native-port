#ifndef PSPGO_HOST_H
#define PSPGO_HOST_H
void pspgo_host_run(void);
void hci_log(const char *format,...);
#endif
