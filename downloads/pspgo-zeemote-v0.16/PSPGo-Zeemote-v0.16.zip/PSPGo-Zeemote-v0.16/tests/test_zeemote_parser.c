#include "../src/zeemote_hid.c"
#include "zeemote_descriptor_fixture.h"
