#!/usr/bin/env python3
"""Compiled guard for the new drain wrapper; not full native stack proof."""
import json,sys
from check_hid_stack import functions
f=functions(sys.argv[1]);address,words,frame=f['drain_read']
allowed={f[n][0] for n in ['sceKernelCpuSuspendIntr','sceKernelCpuResumeIntr','sceKernelPollEventFlag']}
poll=f['sceKernelPollEventFlag'][0];calls=[];poll_mode=False
for i,w in enumerate(words):
 if w>>26==3:
  target=((address+i*4+4)&0xf0000000)|((w&0x3ffffff)<<2);calls.append(target)
  if target==poll:poll_mode=i>=2 and words[i-2]==0x24060001 and words[i-1]==0x24050001
indirect=sum(w&0xfc1fffff==0x0000f809 for w in words)
# New read and decode paths are sequential; reserve native read+helper space.
read_budget=128+frame+256+128
ok=frame<=64 and indirect==1 and all(c in allowed for c in calls) and poll_mode and read_budget<=768
print(json.dumps(dict(frame=frame,original_read_calls=indirect,nonclearing_bit1_poll=poll_mode,
 direct_calls_only_poll_and_irq=all(c in allowed for c in calls),conservative_read_path_allowance=read_budget,
 report_thread_bytes=1024,pass_check=ok),indent=2))
raise SystemExit(0 if ok else 1)
