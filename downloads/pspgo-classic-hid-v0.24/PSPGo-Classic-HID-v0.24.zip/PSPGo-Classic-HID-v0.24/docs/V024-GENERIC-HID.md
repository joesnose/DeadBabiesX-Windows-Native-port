# Experimental Classic HID expansion, 2026-11-10

User explicitly requested a standard Bluetooth Classic HID test build. The
hardware-confirmed v0.23 remains separate. No physical generic pad success is
claimed here.

Registration predicate: preserve the original service predicate, real84-byte
record/nonzeroID checks and the Zeemote fallback. Add major Peripheral5 and
minor joystick4/gamepad8 admission, using the examined high/middle/low CoD
byte order. Emitted code remains below the inline name/wrapper boundaries.
The constructor keeps the existing native PIN allocation and private category2
vtable. Exhaustive executable MIPS tests cover all65536 major/minor combinations
for both named fallback and generic-name admission.

Input: own type3 nodes only after valid Gamepad/Joystick application parsing,
zero native resources and an ownership slot. Remove the fixed Free VID/PID
requirement while excluding known DS3 identity and keeping type4 unchanged.
1038:1412 keeps its established buttons; others use documented generic button
ordering. XY+buttons no longer requires a hat; hat+buttons or standard four
D-pad usages+buttons may omit axes. Other report/field/ownership limits remain.

Reconnection: native saved-record metadata is not device authentication.
Accepted menu requests save slot/address in a16-byte local preference. Fresh
queries match both before reconnect; no preference uses unique-HID fallback.
Corrupt/short preference format is rejected. Multiple saved registrations need
one explicit menu Connect to select the target. No keys are stored or logged.

No new HCI/L2CAP/SSP/BLE stack is implemented. Native pairing and service support
still decide which Classic devices can establish a session. Unsupported
keyboard/consumer/vendor layouts are outside this test. Existing VSH/GAME/HOME
routes and report-thread/worker separation remain. Fourteen sanitizer programs
pass; compiled stack evidence is in V024-STACK-CHECK.json. Hardware tests remain.
