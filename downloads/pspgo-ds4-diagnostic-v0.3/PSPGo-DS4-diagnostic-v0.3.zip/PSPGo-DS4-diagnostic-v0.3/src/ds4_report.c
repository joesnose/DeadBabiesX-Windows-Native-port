#include "ds4_report.h"
#include <string.h>
static uint32_t crc_byte(uint32_t crc,uint8_t byte) {
    crc^=byte;
    for (unsigned i=0;i<8;++i) crc=(crc>>1)^((0u-(crc&1u))&0xedb88320u);
    return crc;
}
uint32_t ds4_input_crc(const uint8_t *report,size_t n) {
    uint32_t crc=crc_byte(0xffffffffu,0xa1);
    for(size_t i=0;i<n;++i)crc=crc_byte(crc,report[i]);
    return crc^0xffffffffu;
}
int ds4_decode_bt(const uint8_t *r,size_t n,Ds4State *s) {
    static const uint32_t hats[]={0x10,0x30,0x20,0x60,0x40,0xc0,0x80,0x90,0};
    if(!s)return -1;
    memset(s,0,sizeof(*s));s->lx=s->ly=s->rx=s->ry=128;
    if(!r||n==0)return -1;
    unsigned offset;
    if(r[0]==1 && n==10)offset=1;
    else if(r[0]==0x11 && n==78) {
        uint32_t expected=(uint32_t)r[74]|((uint32_t)r[75]<<8)|((uint32_t)r[76]<<16)|((uint32_t)r[77]<<24);
        if(ds4_input_crc(r,74)!=expected)return -1;
        offset=3;
    } else return -1;
    const uint8_t *p=r+offset;
    unsigned hat=p[4]&15;if(hat>8)return -1;
    s->lx=p[0];s->ly=p[1];s->rx=p[2];s->ry=p[3];s->l2=p[7];s->r2=p[8];
    s->buttons=hats[hat];
    /* Square, Cross, Circle, Triangle. */
    const uint32_t face[]={0x8000,0x4000,0x2000,0x1000};
    for(unsigned i=0;i<4;++i)if(p[4]&(0x10u<<i))s->buttons|=face[i];
    if(p[5]&0x05)s->buttons|=0x100; /* L1 or digital L2 */
    if(p[5]&0x0a)s->buttons|=0x200; /* R1 or digital R2 */
    if(p[5]&0x10)s->buttons|=1; /* Share -> Select */
    if(p[5]&0x20)s->buttons|=8; /* Options -> Start */
    if(p[6]&1)s->buttons|=0x10000; /* PS -> Home */
    s->l3=(p[5]>>6)&1;s->r3=(p[5]>>7)&1;s->touch=(p[6]>>1)&1;
    return 0;
}
