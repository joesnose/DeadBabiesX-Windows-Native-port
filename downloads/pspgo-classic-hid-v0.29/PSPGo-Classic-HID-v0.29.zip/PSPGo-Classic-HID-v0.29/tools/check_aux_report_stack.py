#!/usr/bin/env python3
"""Check bounded auxiliary report wrappers and restored-frame passthrough."""
import json,sys
from check_hid_stack import functions
f=functions(sys.argv[1]);names=['keyboard_report','mouse_report','auxiliary_report']
frames={n:f[n][2] for n in names};w=f['auxiliary_report'][1]
# Native passthrough must be a tail call after restoring this frame in its
# jump delay slot. Thus no new wrapper frame stays under native key/mouse code.
tail=any(w[i]==0x03200008 and w[i+1]==0x27bd0000+frames['auxiliary_report'] for i in range(len(w)-1))
allowed={f[n][0] for n in ['sceKernelCpuSuspendIntr','sceKernelCpuResumeIntr']};a=f['auxiliary_report'][0]
calls=[(((a+i*4+4)&0xf0000000)|((v&0x3ffffff)<<2)) for i,v in enumerate(w) if v>>26==3]
irq_only=all(c in allowed for c in calls)
ok=frames['keyboard_report']==0 and frames['mouse_report']==0 and frames['auxiliary_report']<=64 and tail and irq_only
print(json.dumps(dict(frames=frames,restored_stack_native_tailcall=tail,report_direct_calls_only_irq_helpers=irq_only,pass_check=ok),indent=2))
raise SystemExit(0 if ok else 1)
