#ifndef RADIO_QUERY_H
#define RADIO_QUERY_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
/* Independently implemented from the public BCCMD wire format. No generic
 * read/write entry point is exposed: only the listed scalar metadata reads. */
typedef struct {const char *name;uint16_t varid,key;} RadioQuery;
static const RadioQuery radio_queries[]={
 {"BUILD_ID",0x2819,0},{"CHIP_VERSION",0x281a,0},{"CHIP_REVISION",0x281b,0},
 
 {"ONCHIP_HCI_CLIENT",0x7003,0x03cc},{"USB_VM_CONTROL",0x7003,0x03c0},
 {"HOST_INTERFACE",0x7003,0x01f9},{"INITIAL_BOOTMODE",0x7003,0x03cd},
 {"LOADER_BUILD_ID",0x2838,0},{"INTERFACE_VERSION",0x2825,0}
};
#define RADIO_QUERY_COUNT (sizeof(radio_queries)/sizeof(radio_queries[0]))
/* Observed completed BSM reply 0050 maps to native status 802F0125.
 * It is not a timeout, malformed message, or evidence that HCI is absent. */
static inline int radio_query_skippable(int result,unsigned outer_status){
 return result>=0 && outer_status==0x50;
}
static inline int radio_query_index(uint16_t varid,uint16_t key){
 for(unsigned i=0;i<RADIO_QUERY_COUNT;i++)if(radio_queries[i].varid==varid&&radio_queries[i].key==key)return (int)i;
 return -1;
}
/* Sony's native address reader pads the nested command to 50 bytes. */
static inline int radio_query_make(uint16_t varid,uint16_t key,uint16_t sequence,uint16_t packet[25]){
 if(!packet || radio_query_index(varid,key)<0)return -1;
 memset(packet,0,50);packet[0]=0;packet[1]=9;packet[2]=sequence;packet[3]=varid;
 if(varid==0x7003){packet[5]=key;packet[6]=1;packet[7]=0;}
 return 0;
}
/* Return 0 for a validated scalar, 1 for BCCMD error status, -1 malformed.
 * available is the maximum copied buffer extent, never an inferred payload. */
static inline int radio_query_parse(const uint16_t *packet,size_t available,
 uint16_t varid,uint16_t key,uint16_t sequence,unsigned *status,unsigned *value){
 if(!packet||!status||!value||available<10||radio_query_index(varid,key)<0)return -1;
 if(packet[0]!=1 || packet[1]<5 || packet[1]>25 || packet[1]*2u>available ||
    packet[2]!=sequence || packet[3]!=varid)return -1;
 *status=packet[4];if(*status)return 1;
 size_t offset=varid==0x7003?8:5;
 if(packet[1]<=offset || available<(offset+1)*2)return -1;
 if(varid==0x7003 && (packet[5]!=key || packet[6]!=1))return -1;
 *value=packet[offset];return 0;
}
static inline int radio_ready_guard(uint32_t base,const uint32_t code[6]){
 if(!code||base>0xffff21a4u)return 0;
 return (code[0]&0xffff0000u)==0x3c020000u && (code[1]&0xffff0000u)==0x90440000u &&
  ((code[0]&0xffffu)<<16)+(int16_t)code[1]==base+0xde5bu &&
  code[2]==0x24050002u&&code[3]==0x24020001u&&code[4]==0x03e00008u&&code[5]==0x00a4100au;
}
static inline int radio_transport_guard(uint32_t base,const uint32_t prologue[4],uint32_t call,uint32_t delay){
 if(!prologue||base>0xffffc6b7u)return 0;
 uint32_t site=base+0x3940,target=base+0x3720;
 uint32_t expected=0x0c000000u|((target>>2)&0x03ffffffu);
 return !(base&3)&&((site+4)&0xf0000000u)==(target&0xf0000000u)&&call==expected&&delay==0&&
  prologue[0]==0x27bdffd0u&&prologue[1]==0x24820008u&&prologue[2]==0x2ca90001u&&prologue[3]==0x2c830001u;
}
#endif
