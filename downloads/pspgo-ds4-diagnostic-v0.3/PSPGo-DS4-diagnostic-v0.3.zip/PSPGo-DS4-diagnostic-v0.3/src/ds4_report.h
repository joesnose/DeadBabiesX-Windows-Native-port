#ifndef DS4_REPORT_H
#define DS4_REPORT_H
#include <stddef.h>
#include <stdint.h>
typedef struct {
    uint32_t buttons; /* PSP_CTRL bit values; PS maps to HOME. */
    uint8_t lx,ly,rx,ry,l2,r2;
    uint8_t l3,r3,touch;
} Ds4State;
/* HID report only: strip the HIDP 0xa1 transaction header before calling.
 * Accepts DS4 BT report 0x01 (10 bytes) or 0x11 (78 bytes, CRC checked).
 * This decoder does not pair controllers or receive Bluetooth data.
 * Returns 0 on success; otherwise -1, with output reset to neutral. */
int ds4_decode_bt(const uint8_t *report,size_t length,Ds4State *state);
uint32_t ds4_input_crc(const uint8_t *report,size_t length_without_crc);
#endif
