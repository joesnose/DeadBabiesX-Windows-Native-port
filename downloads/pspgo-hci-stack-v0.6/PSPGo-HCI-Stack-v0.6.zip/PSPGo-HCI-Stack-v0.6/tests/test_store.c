#include "../src/store_query.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned keys[]={0x3cc,0x3c0},stores[]={0,1,2,4,8};uint16_t tx[25];
 for(unsigned i=0;i<2;i++)for(unsigned j=0;j<5;j++){
  assert(store_query_make(keys[i],stores[j],17,tx)==0);
  assert(tx[0]==0&&tx[1]==9&&tx[2]==17&&tx[3]==0x7003&&tx[4]==0&&tx[5]==keys[i]&&tx[6]==1&&tx[7]==stores[j]);
  for(unsigned k=8;k<25;k++)assert(tx[k]==0);
  tx[0]=1;tx[8]=1;unsigned status,value;
  assert(radio_query_parse(tx,50,0x7003,keys[i],17,&status,&value)==0&&value==1);
  assert(radio_query_parse(tx,16,0x7003,keys[i],17,&status,&value)<0);
 }
 assert(store_query_make(1,8,1,tx)<0); /* BDADDR forbidden */
 assert(store_query_make(0x3cc,3,1,tx)<0);assert(store_query_make(0x3cc,0xffff,1,tx)<0);
 assert(store_query_make(0x3cc,8,65536,tx)<0);assert(store_query_make(0x3cc,8,1,NULL)<0);
 puts("read-only store preflight: exact GET framing, allowlist, stores and response bounds passed");
}
