#include "drain_stop_plan.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 uint32_t base=0x8822f800,c[DRAIN_STOP_WORDS],out;drain_stop_expected(base,c);
 assert(!drain_stop_plan(base,0x4ec4,0x88310000,c,&out));
 assert((out&0x3ffffff)<<2==0x08310000);
 for(unsigned i=0;i<DRAIN_STOP_WORDS;i++){c[i]^=1;out=0xfeedface;assert(drain_stop_plan(base,0x4ec4,0x88310000,c,&out)<0&&out==0xfeedface);c[i]^=1;}
 assert(drain_stop_plan(base,0x4ec4,0x08310000,c,&out)<0);
 assert(drain_stop_plan(base,0x4ec4,0x88310002,c,&out)<0);
 assert(drain_stop_plan(base,0x4ec0,0x88310000,c,&out)<0);
 assert(drain_stop_plan(0xffffc000,0x4ec4,0x88310000,c,&out)<0);
 puts("PASS: fifteen native drain/loop/stop-mask/event-pointer context guards, jump/bounds/alignment and unchanged failure output");
}
