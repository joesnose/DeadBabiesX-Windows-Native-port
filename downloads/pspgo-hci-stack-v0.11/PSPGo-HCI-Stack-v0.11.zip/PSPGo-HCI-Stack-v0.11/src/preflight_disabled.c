/* v0.10 deliberately makes no native radio configuration calls. MIT. */
#include "host.h"
void pspgo_radio_preflight(void){
 hci_log("PREFLIGHT v0.10: RAM suite disabled; no native radio commands, writes, reset or power changes\n");
}
