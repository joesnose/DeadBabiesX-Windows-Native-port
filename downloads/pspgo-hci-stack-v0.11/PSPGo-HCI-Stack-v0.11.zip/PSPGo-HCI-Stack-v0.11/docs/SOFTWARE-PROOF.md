# v0.10 software proof and limits

1. A 17-byte legacy HCI inquiry packet was fed through the real vendored BTstack
   normalization path using the original v0.9 host. An assertion expecting a
   selected peer failed, reproducing the discovery bug.
2. The same inquiry path in corrected host tests initiates one SDP query. Streamed
   SDP attribute callbacks with a valid same-record DS4 identity select the peer
   and request HID. SDP network exchange and HID connection are mocked.
3. Foreign, malformed, mixed-record, failed and timed-out identity results are
   rejected. Controls and persisted bonds are blocked before verification;
   reports for the wrong HID connection are rejected.
4. Offline replay of the user-supplied log finds four matching successful SET
   response headers and matching printed key/store/value fields. Actual copied
   extent and effective write changes remain unproven. Logs are not distributed.
5. Full native ASan/UBSan test suite and PSP cross-build pass. The production
   build links disabled preflight, not the historical write suite.

No actual standard-HCI attachment, Bluetooth authentication or DS4 gameplay
input was demonstrated by these checks. No new hardware commands were run.
