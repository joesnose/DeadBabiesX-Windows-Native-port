# Observed0422 connection route correction, 2026-11-10

User reports a second test controller registered/connected, no buttons,
Information displays SPP, and USB-mode Bluetooth disable freezes only after
connecting. Model/mode clarification requested; no answer yet.

Observed latest attempts: slot2 saved flags0422; HID_CONNECT selected_mode0,
requested flags0202; SLC slot2 state0/flags0202; native result0. No new HID
capture, init or report follows. Earlier decoded reports belong to1038:1412.
This supports a concrete selector bug, not an SPP report decoder or proof of
a successful generic input session.

Native connect mode0 constructs0202, nonzero mode constructs0402. The current
profile metadata contains0400/0002 with an extra0020. v0.24 redirected only
exact0402 and its saved-target whitelist also excluded0422. v0.25 strips only
this observed extra0020 for eligibility/selection. It does not ignore arbitrary
unknown bits:0402/0422 selectmode1,0202/0222 and0602/0622 retainmode0. Fresh80-byte
record size/slot checks, caller mode preservation and original outcome remain.
Both manual connect and automatic reconnect call this shared policy.

All65536 selection inputs and explicit0422 reconnect cases are tested. Existing
14 sanitizer programs pass. Controller input and USB disable with the changed
route remain unverified on hardware. No speculative native shutdown patch,
forced thread termination, reset or new radio command is added. A route fix
must not be described as proof that the USB hang is resolved.

No private log, address, firmware or disassembly is distributed in these notes.
