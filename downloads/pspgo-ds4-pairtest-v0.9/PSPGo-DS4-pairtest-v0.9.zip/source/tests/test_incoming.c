#include <assert.h>
#include <stdio.h>
#include "patch_plan.h"
int main(void){
 uint32_t ctx[]={0x94e40000,0x30a5ffff,0x0e08f05e,0,0x0a08e70c,0x8fa400f0,0x27bdffa0,0x24030001},word;
 assert(!incoming_call_plan(0x88239200,0x88400000,ctx,&word));assert(word==0x0e100000);
 for(unsigned i=0;i<8;i++){ctx[i]^=1;assert(incoming_call_plan(0x88239200,0x88400000,ctx,&word));ctx[i]^=1;}
 assert(incoming_call_plan(0x88239200,0x08400000,ctx,&word));
 assert(incoming_call_plan(0x88239200,0x88400001,ctx,&word));
 uint16_t short_body[3]={2,2,0x202};unsigned a=0,b=0;
 assert(failure_words(short_body,6,&a,&b));
 uint16_t full_body[5]={2,2,0x202,0x1234,0xabcd};
 assert(!failure_words(full_body,10,&a,&b));assert(a==0x1234&&b==0xabcd);
 assert(failure_words(full_body,8,&a,&b));assert(failure_words(full_body,12,&a,&b));
 full_body[1]=0;assert(failure_words(full_body,10,&a,&b));
 full_body[1]=3;assert(failure_words(full_body,10,&a,&b));
 full_body[1]=2;full_body[2]=4;assert(failure_words(full_body,10,&a,&b));
 puts("PASS: incoming call argument/target/delay guards; exact-length HID failure details; short-buffer ASan check");
}
