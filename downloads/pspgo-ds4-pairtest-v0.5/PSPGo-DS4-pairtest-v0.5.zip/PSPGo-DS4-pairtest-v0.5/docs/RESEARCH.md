# v0.5 research findings

The private v0.4 hardware log confirmed installation of the PIN-style native registration hook and the guarded VSH discovery patch, with no call to the traced registration entry. That absence alone was insufficient to locate the rejection.

Sony's official PSP Go 6.61 updater was downloaded locally from its public update server. Its MD5 matched fd0f7d0798b4f6e6d32ef95836740527. It was unpacked for analysis only; no updater was installed on the console. The Bluetooth menu's two original discovery-filter instructions match those accepted by the v0.4 runtime guards.

The menu imports both sceBSMan_8AC2F7B8 and sceBSMan_2D649923 for different registration paths. Its record/profile handling also calls sceBSMan_CBD232D1 and can generate the unsupported-device UI condition after a query. There is therefore an unobserved native path in v0.4 and a distinction between registration failure and later profile rejection. We cannot choose between those explanations from the v0.4 log alone.

The corresponding entries in the user-provided native driver snapshot were inspected to establish two-argument, one-argument, and index/output-buffer calling conventions. The profile output is an 80-byte structure, with its profile bitfield at offset 72. The v0.5 logger reads only size/ID/flags after the original API returns successfully and checks the pointer's allowed RAM range/alignment. It logs no device name, address, PIN or key.

No UI class is spoofed, no native status code is overridden, and no profile is forced to become supported. The two original discovery-filter patches remain. Each additional entry hook uses a verified branch-free, PC-independent displaced instruction pair. The profile entry uses a relocated LUI/LBU pair whose effective address is checked against the verified module-relative flag address. Displaced instructions are replayed in a bounded trampoline before rejoining the original function.

Tools used locally: John-K/pspdecrypt, Ghidra 11.4.2 with kotcrab/ghidra-allegrex v21.2 (PSP-aware ELF relocation/loading), and PSP objdump. Decompiled results were cross-checked against instructions and import/export tables. Some inferred C signatures were incomplete, so the argument forwarding decisions use the native wrapper instructions. Neither official firmware nor private captures/decompiled code are redistributed.

Sources:
- https://du01.psp.update.playstation.org/update/psp/image2/us/2014_1212_fd0f7d0798b4f6e6d32ef95836740527/EBOOT.PBP (official updater, local analysis only)
- https://github.com/John-K/pspdecrypt
- https://github.com/kotcrab/ghidra-allegrex
- https://github.com/PSP-Arkfive/ARK-5
- https://github.com/PSP-Archive/btfree
- https://github.com/Hirador/btfree-ark
