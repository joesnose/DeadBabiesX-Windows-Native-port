#ifndef ZEE_GAME_RECONNECT_H
#define ZEE_GAME_RECONNECT_H
#include <stdint.h>
#include <string.h>
typedef struct {unsigned queries,matches,slot,flags,attempted;int result;} ZeeReconnect;
static inline int generic_saved_hid(const uint8_t p[80],unsigned slot){
 if(!p||slot<1||slot>8||p[0]!=80||p[1]||p[2]||p[3]||
    ((unsigned)p[4]|((unsigned)p[5]<<8))!=slot)return 0;
 unsigned flags=((unsigned)p[72]|((unsigned)p[73]<<8))&~0x0020u;
 if(flags!=0x0202&&flags!=0x0402&&flags!=0x0602)return 0;
 /* Accept any nonempty bounded UTF16 name, without a vendor/name whitelist. */
 if(!p[6]&&!p[7])return 0;
 for(unsigned i=1;i<33;i++)if(!p[6+2*i]&&!p[7+2*i])return 1;
 return 0;
}
/* Called once on the owned GAME worker. Query fresh records, require exactly
 * one saved HID target, preserve mode policy, do not retain names/addresses.
 * Native flags select a registration only; input ownership still requires
 * a validated descriptor and native resource checks. No pairing, PIN, radio power/reset or writes. */
static inline ZeeReconnect zee_game_reconnect(int active,int (*query)(int,void *),int (*connect)(int,int)){
 ZeeReconnect d={0,0,0,0,0,0};
 if(active||!query||!connect)return d;
 for(unsigned slot=1;slot<=8;slot++){
  uint8_t record[80] __attribute__((aligned(16)))={0};record[0]=80;
  ++d.queries;int status=query((int)slot,record);
  if(status>=0&&generic_saved_hid(record,slot)){
   ++d.matches;d.slot=slot;d.flags=(unsigned)record[72]|((unsigned)record[73]<<8);
  }
  memset(record,0,sizeof(record));
 }
 if(d.matches==1){d.attempted=1;d.result=connect((int)d.slot,(d.flags&~0x0020u)==0x0402?1:0);}
 return d;
}
#endif
