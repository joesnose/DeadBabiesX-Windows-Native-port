/* Bounded single-file writer; no PSP dependencies. Original MIT. */
#ifndef DIAG_SINK_H
#define DIAG_SINK_H
#include <stddef.h>
#define DIAG_LINE_LIMIT 256u
typedef int (*DiagOpen)(const char *);
typedef int (*DiagWrite)(int,const void *,unsigned);
typedef int (*DiagClose)(int);
/* One open, one close, at most 256 advancing writes. Retry on next line
 * if storage is not ready. No alternate files or persistent handles. */
static inline int diag_sink_write(const char *path,const void *data,unsigned size,DiagOpen open_file,DiagWrite write_file,DiagClose close_file){
 if(!path||!data||!size||size>DIAG_LINE_LIMIT||!open_file||!write_file||!close_file)return 0;
 int fd=open_file(path);if(fd<0)return 0;
 unsigned done=0;
 while(done<size){int n=write_file(fd,(const unsigned char *)data+done,size-done);if(n<=0||(unsigned)n>size-done)break;done+=(unsigned)n;}
 int closed=close_file(fd);return done==size&&closed>=0;
}
#endif
