#include <assert.h>
#include <stdio.h>
#include "radio_query.h"
int main(void){
 uint16_t packet[26];memset(packet,0x5a,sizeof(packet));
 assert(!radio_query_make(0x2819,0,7,packet));
 assert(packet[0]==0&&packet[1]==9&&packet[2]==7&&packet[3]==0x2819&&packet[4]==0);
 for(unsigned i=5;i<25;i++)assert(packet[i]==0);
 assert(packet[25]==0x5a5a);
 unsigned accepted=0;
 for(unsigned varid=0;varid<=65535;varid++)accepted+=radio_query_make((uint16_t)varid,0,1,packet)==0;
 assert(accepted==5);
 for(unsigned key=0xca;key<=0xd9;key++)assert(radio_query_make(0x7003,(uint16_t)key,1,packet));
 assert(radio_query_make(0x4001,0,1,packet));assert(radio_query_make(0x4002,0,1,packet));
 assert(radio_query_make(0x7003,0x0001,1,packet));
 assert(!radio_query_make(0x7003,0x03cc,9,packet));
 assert(packet[0]==0&&packet[1]==9&&packet[3]==0x7003&&packet[5]==0x03cc&&packet[6]==1&&packet[7]==0);
 packet[0]=1;packet[8]=1;unsigned status=99,value=99;
 assert(!radio_query_parse(packet,50,0x7003,0x03cc,9,&status,&value));assert(!status&&value==1);
 for(unsigned i=0;i<4;i++){packet[i]^=1;assert(radio_query_parse(packet,50,0x7003,0x03cc,9,&status,&value));packet[i]^=1;}
 packet[4]=1;assert(radio_query_parse(packet,50,0x7003,0x03cc,9,&status,&value)==1&&status==1);packet[4]=0;
 assert(radio_query_parse(packet,16,0x7003,0x03cc,9,&status,&value));
 packet[1]=4;assert(radio_query_parse(packet,50,0x7003,0x03cc,9,&status,&value));
 packet[1]=26;assert(radio_query_parse(packet,50,0x7003,0x03cc,9,&status,&value));
 assert(!radio_query_make(0x2819,0,3,packet));packet[0]=1;packet[1]=6;packet[5]=0x1234;
 assert(!radio_query_parse(packet,12,0x2819,0,3,&status,&value)&&value==0x1234);
 assert(radio_query_parse(packet,10,0x2819,0,3,&status,&value));
 unsigned allowed_keys=0;
 for(unsigned key=0;key<=65535;key++)allowed_keys+=radio_query_index(0x7003,(uint16_t)key)>=0;
 assert(allowed_keys==4);
 uint16_t short_reply[5]={1,5,1,0x2819,0};
 assert(radio_query_parse(short_reply,sizeof(short_reply),0x2819,0,1,&status,&value));
 uint32_t ready[]={0x3c028824,0x9044705b,0x24050002,0x24020001,0x03e00008,0x00a4100a};
 assert(radio_ready_guard(0x88239200,ready));
 for(unsigned i=0;i<6;i++){ready[i]^=1;assert(!radio_ready_guard(0x88239200,ready));ready[i]^=1;}
 uint32_t entry[]={0x27bdffd0,0x24820008,0x2ca90001,0x2c830001};
 assert(radio_transport_guard(0x88239200,entry,0x0e08f248,0));
 assert(!radio_transport_guard(0x88239200,entry,0x0e08f249,0));
 assert(!radio_transport_guard(0x88239200,entry,0x0e08f248,1));
 puts("PASS: allowlist, no SET/reset/link-key reads, GET framing, response bounds/echo/status, guarded native ABI context");
}
