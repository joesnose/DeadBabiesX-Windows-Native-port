#define HCI_STACK_HOST_TEST
#include "../src/host.c"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
static char tempdir[128];static unsigned ms,commands,updates,installs;static Ds4State injected;
static uint8_t last_command[258];static unsigned last_command_len;
int pspSdkSetK1(int k){(void)k;return 0;}
static const char *path(const char *p){static char out[512];const char *base=strrchr(p,'/');assert(base);snprintf(out,sizeof(out),"%s/%s",tempdir,base+1);return out;}
int sceIoOpen(const char *p,int flags,int mode){return open(path(p),(flags&PSP_O_RDONLY)?O_RDONLY:O_WRONLY|O_CREAT|((flags&PSP_O_TRUNC)?O_TRUNC:0),mode);}
int sceIoWrite(int fd,const void *p,unsigned n){return (int)write(fd,p,n);}int sceIoRead(int fd,void *p,unsigned n){return (int)read(fd,p,n);}int sceIoClose(int fd){return close(fd);}
int sceIoSync(const char *p,int n){(void)p;(void)n;return 0;}int sceIoRename(const char *a,const char *b){char from[512];strcpy(from,path(a));return rename(from,path(b));}int sceIoRemove(const char *p){return unlink(path(p));}
uint64_t sceKernelGetSystemTimeWide(void){return (uint64_t)ms*1000;}int sceKernelDelayThread(unsigned us){ms+=(us+999)/1000;return 0;}
void hci_log(const char *fmt,...){(void)fmt;}void pspgo_radio_preflight(void){}
int pspgoHciGetState(void){return 1;}int pspgoHciSendCommand(const void *p,unsigned n,unsigned t){(void)t;assert(n<=sizeof(last_command));memcpy(last_command,p,n);last_command_len=n;commands++;return (int)n;}
int pspgoHciSendAcl(const void *p,unsigned n,unsigned t){(void)p;(void)t;return (int)n;}
int pspgoHciReadEvent(void *p,unsigned n,unsigned t){(void)p;(void)n;(void)t;return HCI_ERR_TIMEOUT;}int pspgoHciReadAcl(void *p,unsigned n,unsigned t){(void)p;(void)n;(void)t;return HCI_ERR_TIMEOUT;}
int pspgo_input_install(void){installs++;return 0;}void pspgo_input_update(const Ds4State *s){updates++;injected=*s;}void pspgo_input_clear(void){}
static unsigned queries,hid_requests;
static btstack_packet_handler_t identity_callback;
static uint8_t mock_query(btstack_packet_handler_t cb,bd_addr_t addr,uint16_t uuid){(void)addr;assert(uuid==0x1200);queries++;identity_callback=cb;return 0;}
static uint8_t mock_hid(bd_addr_t addr,hid_protocol_mode_t mode,uint16_t *cid){(void)addr;assert(peer_valid&&mode==HID_PROTOCOL_MODE_REPORT);*cid=7;hid_requests++;return 0;}
static void inquiry(void){uint8_t e[17]={HCI_EVENT_INQUIRY_RESULT,15,1,6,5,4,3,2,1,0,0,0,0,5,0,0,0};receive_packet(HCI_EVENT_PACKET,e,sizeof(e));}
static void attribute(unsigned record,unsigned attr,unsigned value){
 for(unsigned i=0;i<3;i++){uint8_t e[11]={SDP_EVENT_QUERY_ATTRIBUTE_BYTE,9};little_endian_store_16(e,2,record);little_endian_store_16(e,4,attr);little_endian_store_16(e,6,3);little_endian_store_16(e,8,i);e[10]=i==0?0x09:i==1?(uint8_t)(value>>8):(uint8_t)value;identity_callback(HCI_EVENT_PACKET,0,e,sizeof(e));}
}
static void finish_identity(unsigned status){uint8_t e[3]={SDP_EVENT_QUERY_COMPLETE,1,(uint8_t)status};identity_callback(HCI_EVENT_PACKET,0,e,sizeof(e));}
static void reset_discovery(void){peer_valid=connected=bond_valid=stopped=candidate_active=0;pairing_open=1;pairing_deadline=ms+60000;queries=hid_requests=0;query_identity=mock_query;connect_hid=mock_hid;}
static void discovery_tests(void){
 reset_discovery();inquiry();assert(queries==1&&candidate_active&&!peer_valid&&!hid_requests);
 inquiry();assert(queries==1); /* no simultaneous candidates */
 unsigned before=installs,before_updates=updates;uint8_t untrusted[18]={HCI_EVENT_HID_META,16,HID_SUBEVENT_REPORT,1,0,11,0,0xa1,1,128,128,128,128,0x28,0,0,0,0};event_handler(HCI_EVENT_PACKET,0,untrusted,sizeof(untrusted));assert(installs==before&&updates==before_updates);bd_addr_t a={1,2,3,4,5,6};link_key_t k={0};db_put(a,k,COMBINATION_KEY);assert(!bond_valid&&installs==before);
 attribute(1,0x0201,0x054c);attribute(1,0x0202,0x05c4);assert(!peer_valid&&!hid_requests);attribute(1,0x0205,2);finish_identity(0);assert(peer_valid&&hid_requests==1&&!candidate_active);
 reset_discovery();inquiry();attribute(1,0x0201,0x054c);attribute(2,0x0202,0x05c4);attribute(2,0x0205,2);finish_identity(0);assert(!peer_valid&&!hid_requests);
 reset_discovery();inquiry();attribute(1,0x0201,0x1234);attribute(1,0x0202,0x05c4);attribute(1,0x0205,2);finish_identity(0);assert(!peer_valid&&!hid_requests);
 reset_discovery();inquiry();attribute(1,0x0201,0x054c);attribute(1,0x0202,0x09cc);attribute(1,0x0205,2);finish_identity(1);assert(!peer_valid&&!hid_requests);
 reset_discovery();inquiry();uint8_t bad[11]={SDP_EVENT_QUERY_ATTRIBUTE_BYTE,9,1,0,1,2,3,0,2,0,9};identity_callback(HCI_EVENT_PACKET,0,bad,sizeof(bad));finish_identity(0);assert(!peer_valid&&!hid_requests);
 reset_discovery();inquiry();ms+=15000;discovery_tick();assert(stopped&&!candidate_active&&!peer_valid&&!hid_requests);attribute(1,0x0201,0x054c);finish_identity(0);assert(!peer_valid&&!hid_requests);
 reset_discovery();inquiry();attribute(1,0x0201,0x054c);attribute(1,0x0202,0x09cc);attribute(1,0x0205,2);finish_identity(0);assert(peer_valid&&hid_requests==1);
 puts("discovery: legacy inquiry without EIR, sequential SDP bytes, same-record identity, foreign/malformed/error rejection, pre-verification bond gate and deadline/stale callbacks passed");
}
int main(void){
 strcpy(tempdir,"/tmp/pspgo-host-test-XXXXXX");assert(mkdtemp(tempdir));
 bd_addr_t addr={1,2,3,4,5,6},host={6,5,4,3,2,1};link_key_t key,got;memset(key,0x42,16);link_key_type_t type;
 memcpy(peer,addr,6);peer_valid=1;db_open();assert(!bond_valid);db_local(host);db_put(addr,key,COMBINATION_KEY);assert(bond_valid);assert(db_get(addr,got,&type)&&!memcmp(got,key,16));
 bond_valid=0;memset(bond,0,sizeof(bond));db_open();db_local(host);assert(bond_valid&&db_get(addr,got,&type));
 bd_addr_t wrong={9,9,9,9,9,9};assert(!db_get(wrong,got,&type));db_local(wrong);assert(!bond_valid);
 db_open();assert(bond_valid);int fd=open(path(KEY_PATH),O_WRONLY);assert(fd>=0);uint8_t bad=0xff;assert(write(fd,&bad,1)==1);close(fd);db_open();assert(!bond_valid);
 connected=1;hid_cid=1;uint8_t event[18]={HCI_EVENT_HID_META,16,HID_SUBEVENT_REPORT,1,0,11,0,0xa1,1,128,128,128,128,0x28,0,0,0,0};
 event_handler(HCI_EVENT_PACKET,0,event,sizeof(event));assert(updates==1&&installs==1&&injected.buttons==0x4000);
 event[3]=2;event_handler(HCI_EVENT_PACKET,0,event,sizeof(event));assert(updates==1);event[3]=1;
 event[7]=0xa2;event_handler(HCI_EVENT_PACKET,0,event,sizeof(event));assert(updates==1);event[7]=0xa1;event[5]=250;event_handler(HCI_EVENT_PACKET,0,event,sizeof(event));assert(updates==1);
 for(unsigned n=0;n<sizeof(event);n++)event_handler(HCI_EVENT_PACKET,0,event,(uint16_t)n);assert(updates==1);
 btstack_memory_init();btstack_run_loop_init(btstack_run_loop_embedded_get_instance());hci_init(&transport,NULL);hci_power_control(HCI_POWER_ON);
 assert(commands==1&&last_command_len==3&&last_command[0]==3&&last_command[1]==12&&last_command[2]==0);
 uint8_t complete[]={0x0e,4,1,3,12,0};receive_packet(HCI_EVENT_PACKET,complete,sizeof(complete));
 for(unsigned i=0;i<500&&commands<2;i++)btstack_run_loop_embedded_execute_once();
 assert(commands>=2);
 callback.callback=event_handler;hci_add_event_handler(&callback);discovery_tests();
 unlink(path(KEY_PATH));rmdir(tempdir);
 puts("host: bond save/reload/address binding/corruption rejection, HIDP validation/DS4 mapping, real BTstack reset and command-complete progression passed (mock transport)");return 0;
}
