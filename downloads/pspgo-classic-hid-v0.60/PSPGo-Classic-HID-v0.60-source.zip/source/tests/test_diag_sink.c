#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "diag_sink.h"
static int opens,closes,writes,fd_value,fail,close_fail,chunk;
static char output[256];static unsigned used;
static int open_mock(const char *path){assert(!strcmp(path,"fixed.log"));opens++;return fd_value;}
static int write_mock(int fd,const void *p,unsigned n){assert(fd==fd_value);writes++;if(fail)return fail==1?0:fail==2?-1:(int)n+1;unsigned take=chunk&&(unsigned)chunk<n?(unsigned)chunk:n;memcpy(output+used,p,take);used+=take;return (int)take;}
static int close_mock(int fd){assert(fd==fd_value);closes++;return close_fail?-1:0;}
static void reset(void){opens=closes=writes=fd_value=fail=close_fail=chunk=0;used=0;memset(output,0,sizeof(output));}
static int line(void){return diag_sink_write("fixed.log","test\n",5,open_mock,write_mock,close_mock);}
int main(void){
 reset();assert(line()&&opens==1&&closes==1&&used==5&&!memcmp(output,"test\n",5));
 reset();fd_value=-1;assert(!line()&&opens==1&&!closes&&!writes);fd_value=0;assert(line());
 reset();chunk=1;assert(line()&&writes==5&&closes==1&&!memcmp(output,"test\n",5));
 for(int f=1;f<=3;f++){reset();fail=f;assert(!line()&&opens==1&&closes==1&&writes==1);}
 reset();close_fail=1;assert(!line()&&closes==1);
 reset();fd_value=12;assert(line());
 assert(!diag_sink_write(NULL,"a",1,open_mock,write_mock,close_mock));
 assert(!diag_sink_write("fixed.log",NULL,1,open_mock,write_mock,close_mock));
 assert(!diag_sink_write("fixed.log","a",0,open_mock,write_mock,close_mock));
 assert(!diag_sink_write("fixed.log","a",257,open_mock,write_mock,close_mock));
 puts("PASS: one fixed log, descriptor zero, unavailable-storage recovery, bounded partial writes, write/close failures and input bounds");
}
