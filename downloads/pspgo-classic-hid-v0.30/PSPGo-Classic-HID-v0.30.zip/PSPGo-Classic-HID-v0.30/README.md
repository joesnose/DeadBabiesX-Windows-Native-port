# PSP Go Classic HID v0.30 — clean v0.23-based GameStick test

This restarts from the hardware-confirmed v0.23 Zeemote build. The next target
is the original white GameStick controller, or another Classic HID gamepad.
Keep the NES30 Pro off and out of this round. The user confirmed no-code GameStick registration and connection on v0.27.
Physical button response with this correction remains unverified.

## v0.30 cooperative native report shutdown

The user confirmed v0.29 still hung game transitions even with
`gamepad_only=1, aux_mask=3`; omitting keyboard/mouse registrations did not
resolve it. v0.30 returns to the working v0.28 input baseline, with original
native keyboard/mouse behavior restored. It adds one targeted read-loop hook.

Native composite report dispatch drains packets in a loop. The outer report
worker checks native event bit1 to stop, but the inner drain never checks it.
With a live producer it can keep processing input instead of returning to that
stop check. User logs show native input continuing after VSH controller reads
stop; that is consistent with the exposure, not runtime proof of the cause.

Before each native report read, v0.30 nonblockingly polls the same event/bit1
without clearing it. If native shutdown is requested, it returns end-of-drain0
without another packet read. The original outer worker then sees the still-set
flag and exits through its normal cleanup. Other flag bits, poll errors and
invalid event IDs preserve the original read and exact result. No fixed-time
wait, radio reset, forced thread kill or resource cleanup bypass is added.

Fifteen caller/loop/stop-mask/event-address guards must match before the single
read callsite is changed. Normal input parsing, report3 routing, pairing and
reconnect policy remain. Keyboard/mouse suppression from v0.29 is absent.
The startup line identifies native stop-aware report drain. Deferred `ZEE DRAIN`
stop_observed counters may log before reboot, but shutdown can outpace file
logging, so absence of a counter alone does not prove no stop was observed.

Install: replace the PRX, keep VSH/GAME enabled and the existing GameStick
registration, fully shut down/restart. Connect in VSH, then test entering and
exiting a PSP game with the GameStick left on. No re-pairing. If it still hangs,
the controller-off transition workaround remains the recovery path; retain the
log. Use full shutdown/restart with controllers off before USB until that
separate shutdown behavior is verified. Keep NES30 out of this test.

All16 sanitizer programs pass, including a continuously positive producer that
must stop when native bit1 appears, unchanged packet/flag contents, preserved
original results and poll-error fallback. Actual installer and pure-plan tests
reject each of15 changed native context words before any write. Pinned PSP
cross-build and compiled report/observer/drain checks passed. The new read
wrapper32-byte frame runs before decoding; conservative checked read-path
allowance544/1024, main decode path392/1024. Native indirect helpers still need
source review; these checks are not full firmware execution or hardware proof.
Game transition and USB success remain unverified for v0.30.

## Retained composite gamepad report routing

The v0.27 log now establishes successful no-code registration,0402 connection,
identity0f0d:1011 and a supported232-byte HID descriptor. It contains keyboard
report1, mouse report2 and gamepad report3. Our decoder accepts the gamepad's
9-byte payload, but reports=0 shows that no callback reached it.

Sony's native generic gamepad collection handler skips its contents without
assigning node[1] (Report ID). Its composite dispatcher compares the incoming
Report ID with each node[1] before invoking that node's handler. The keyboard
and mouse parsers assign their IDs; the generic gamepad node can remain0.

v0.30 assigns the descriptor-validated report ID only to the adapter-owned,
numbered generic type3 node after the existing ownership/resource checks.
No dispatcher or unrelated keyboard/mouse node is modified. The native
composite dispatcher can then select node3 and pass its ID-stripped payload;
the existing callback validates/restores that ID for decoding. The confirmed
Free1038:1412 route remains unchanged. The INIT log now records route_before
and route_after, so this hypothesis has a direct runtime check.

The actual static descriptor is included as non-secret protocol metadata in
a regression fixture. A synthetic report3 routes past keyboard1/mouse2 into
the owned gamepad and decodes Cross; term/lifetime cleanup remains tested.
This is not a hardware button success claim. No new registration/PIN or
native wait/shutdown behavior is introduced.

## Install and first test

1. Keep the working v0.23 PRX as rollback. After a full shutdown/restart with
   controllers off, replace `ef0:/seplugins/pspgo_hci_transport.prx` with v0.30.
2. Keep the same VSH/GAME entries enabled, then fully restart again:

```
vsh, ef0:/seplugins/pspgo_hci_transport.prx, on
game, ef0:/seplugins/pspgo_hci_transport.prx, on
```

3. Keep the successful GameStick registration and select Connect manually
   after restarting. Do not delete/re-pair it for this input-only change.
   Existing Zeemote registration can stay.
4. If registration succeeds, select Connect manually in XMB and test buttons,
   D-pad and left stick. Keep the first test in VSH; do not use the NES30 Pro.
5. Send `ef0:/seplugins/pspgo_hci_transport.log` even if registration fails.
   Newest banner should say `Classic HID clean-baseline route 0.27` and the
   startup log should include `PAIR_TRACE passive numeric event observer`.

Until this controller's shutdown behavior is known, fully shut down/restart
with controllers off before USB file transfer. Do not reproduce the known
NES30 USB freeze just to retrieve a log. A v0.23 success with the Zeemote did
not establish that v0.23 can safely shut down the NES30 connection; the user
later confirmed that controller freezes USB there too.

## Exactly what this build changes

The VSH, GAME and HOME/quit-menu input interception, pairing choice, reconnect
policy and native lifecycle paths come from v0.23. There are no v0.26 setup
wait hooks, no native timeout changes, no v0.24 target-preference file writes,
and no broadened automatic reconnection. Existing `pspgo_classic_target.dat`
from experiments is ignored. Automatic reconnect remains Zeemote-only. Generic
controller auto-reconnect across game launch will be added only after a manual
VSH connection/input session is established.

Generic descriptor input from v0.24 is retained: native type3 gamepad nodes
with a supported Generic Desktop Gamepad/Joystick descriptor can be decoded
without the Free VID/PID allowlist. Existing native resources, native DS3
identity/type4 and code/ownership guards are retained. Free1038:1412 keeps its
established mapping; other devices use default generic mapping:

| HID button | PSP |
| --- | --- |
| 1,2,3,4 | Cross,Circle,Square,Triangle |
| 5,6 | L,R |
| 7,8 | Select,Start |
| 11 | HOME |

X/Y maps to PSP left analog; a hat or standard D-pad usages90..93 maps to
PSP directions. Buttons plus XY axes, a hat, or all four D-pad usages are
supported. Bounds remain512-byte descriptor, one complete numbered/unnumbered
report up to64bytes and bounded absolute variable fields. Layouts outside
those bounds are refused. Keyboard/consumer remotes, BLE, vendor protocols and
split gamepad report IDs are outside this test. Physical button numbering may
need a device-specific profile later.

## Pairing choice and passive diagnostics

Unknown controllers retain Sony's stock pairing selection; this build does not
force every gamepad through the Zeemote's0000 PIN path. The exact Zeemote name
fallback from v0.23 remains. There is no replacement authentication/SSP stack,
so GameStick registration may still fail. That is a pairing result, not a
failed input-decoder test.

A guarded observer forwards the native management receive call's six EABI
arguments and original result unchanged. It copies only bounded numeric event
metadata into a32-entry RAM queue. The plugin worker logs PAIR_EVENT id/length,
slot for known slot-bearing events, and word1 only for262/264. For269 PIN-request
events, no PIN/text bytes are read or logged. No packets are rewritten, native
waits shortened or new radio commands introduced. Event labels/word meanings
are not guessed as an authentication error. Discovery/name/address/key/button
payloads are not logged. Static native type3 gamepad descriptors may be logged
for parser diagnostics; those are metadata, not input reports.

## Verification

All16 ASan/UBSan programs passed. Tests cover native receive forwarding/results,
metadata bounds/no packet mutation, nine call-context guards, existing Zeemote
registration, generic decoder/ownership, lifecycle and VSH/GAME/HOME routes.
The pinned PSP build and compiled stack checks are included in V030 evidence.
The prior log proves GameStick pairing/connection on v0.27, but software checks
do not prove v0.30 physical buttons or USB shutdown. v0.23 remains the Zeemote working fallback.

Build image:
`pspdev/pspdev@sha256:ee385df3aa783189d5a033af5eb1d4a9cdd93718fb8bf652ec7bb48e54038a8b`.
Run `sh tests/run.sh` and `python tools/check_hid_stack.py pspgo_hci_transport.elf`.
Original source MIT with SDK notice. No Sony firmware/disassembly, private
user logs, addresses or keys distributed. Historical notes are superseded by
this README for v0.30 behavior.
