/* Original PSP controller merge adapter, MIT. Hooks remain resident until reboot. */
#ifdef ZEE_INPUT_HOST_TEST
#include "zeemote_input_mock.h"
typedef struct {unsigned TimeStamp,Buttons;unsigned char Lx,Ly,Rsrv[6];} SceCtrlData;
void sctrlHENPatchSyscall(void *,void *);
void sceKernelDcacheWritebackAll(void);
void sceKernelIcacheInvalidateAll(void);
#else
#include <pspkernel.h>
#include <pspctrl.h>
#include <psploadcore.h>
#include <pspsdk.h>
#include <systemctrl.h>
#endif
#include <string.h>
#include "zeemote_input.h"
#include "vsh_input_plan.h"
static ZeeState remote;
static unsigned last_ms;
static int active,installed;
static unsigned read_counts[5],merged_samples,install_attempts,vsh_installed;
static unsigned install_error,guard_index=~0u;
static unsigned seen_buttons,motion_seen,min_lx=255,max_lx,min_ly=255,max_ly;
void zee_input_stats(ZeeInputStats *out){if(!out)return;int irq=sceKernelCpuSuspendIntr();out->installed=installed;out->vsh_installed=vsh_installed;out->vsh_reads=read_counts[4];out->active=active;memcpy(out->reads,read_counts,4*sizeof(read_counts[0]));out->merged_samples=merged_samples;out->install_error=install_error;out->guard_index=guard_index;out->seen_buttons=seen_buttons;out->motion_seen=motion_seen;out->last_buttons=remote.buttons;out->lx=remote.lx;out->ly=remote.ly;out->min_lx=min_lx;out->max_lx=max_lx;out->min_ly=min_ly;out->max_ly=max_ly;sceKernelCpuResumeIntr(irq);}
/* Installation errors:1 firmware,2 module,3 export bounds/alias,4 VSH ABI,
 * 5 module changed,6 context changed. Installation is worker-only, bounded. */
static int install_fail(unsigned error,unsigned index){install_error=error;guard_index=index;return -1;}
typedef int (*Read)(SceCtrlData *,int);
static Read originals[5];
static uint32_t code_address(const void *p){
#ifdef ZEE_INPUT_HOST_TEST
 return zee_test_code_address(p);
#else
 return (uint32_t)(uintptr_t)p;
#endif
}
static unsigned now_ms(void){return (unsigned)(sceKernelGetSystemTimeWide()/1000);}
void zee_input_update(const ZeeState *s){int irq=sceKernelCpuSuspendIntr();remote=*s;seen_buttons|=s->buttons;motion_seen|=(s->lx<112?1u:0u)|(s->lx>144?2u:0u)|(s->ly<112?4u:0u)|(s->ly>144?8u:0u);if(s->lx<min_lx)min_lx=s->lx;if(s->lx>max_lx)max_lx=s->lx;if(s->ly<min_ly)min_ly=s->ly;if(s->ly>max_ly)max_ly=s->ly;last_ms=now_ms();active=1;sceKernelCpuResumeIntr(irq);}
void zee_input_keepalive(void){int irq=sceKernelCpuSuspendIntr();if(active)last_ms=now_ms();sceKernelCpuResumeIntr(irq);}
void zee_input_clear(void){int irq=sceKernelCpuSuspendIntr();active=0;memset(&remote,0,sizeof(remote));sceKernelCpuResumeIntr(irq);}
static int merge(unsigned index,SceCtrlData *p,int count){
 int irq_count=sceKernelCpuSuspendIntr();read_counts[index]++;sceKernelCpuResumeIntr(irq_count);
 int result=originals[index](p,count);if(result<=0||result>count||result>64)return result;
 ZeeState s;int irq=sceKernelCpuSuspendIntr();int valid=active&&(unsigned)(now_ms()-last_ms)<1500;s=remote;sceKernelCpuResumeIntr(irq);
 if(!valid)return result;
 irq=sceKernelCpuSuspendIntr();merged_samples+=(unsigned)result;sceKernelCpuResumeIntr(irq);
 for(int i=0;i<result;i++){
  if(index&1)p[i].Buttons&=~s.buttons;else p[i].Buttons|=s.buttons;
  if(s.lx<112||s.lx>144)p[i].Lx=s.lx;
  if(s.ly<112||s.ly>144)p[i].Ly=s.ly;
 }
 return result;
}
static int peek_pos(SceCtrlData *p,int n){return merge(0,p,n);}
static int peek_neg(SceCtrlData *p,int n){return merge(1,p,n);}
static int read_pos(SceCtrlData *p,int n){return merge(2,p,n);}
static int read_neg(SceCtrlData *p,int n){return merge(3,p,n);}
static int vsh_read_pos(SceCtrlData *p,int n){return merge(4,p,n);}
int zee_input_install(void){
 if(installed)return 0;
 if(install_attempts>=4)return -1;
 ++install_attempts;
 unsigned fw=sceKernelDevkitVersion();if(fw!=0x06060010u&&fw!=0x06060110u){install_attempts=4;return install_fail(1,~0u);}
 static const unsigned nids[]={0x3a622550,0xc152080a,0x1f803938,0x60b81f86};
 Read hooks[]={peek_pos,peek_neg,read_pos,read_neg};
 SceModule *ctrl=sceKernelFindModuleByName("sceController_Service");
 SceModule *bridge=sceKernelFindModuleByName("sceVshBridge_Driver");
 if(!ctrl||!bridge)return install_fail(2,~0u);
 uint32_t cb=ctrl->text_addr,cs=ctrl->text_size,b=bridge->text_addr,size=bridge->text_size;
 if(cb>0xffffffffu-cs||b>0xffffffffu-size||size<0x5610u||cs<8)return install_fail(3,~0u);
 Read targets[5];
 for(unsigned i=0;i<4;i++){
  uint32_t entry=(uint32_t)sctrlHENFindFunction("sceController_Service","sceCtrl",nids[i]);
  if((entry&3)||entry<cb||entry-cb>cs-8)return install_fail(3,i);
  targets[i]=(Read)(uintptr_t)entry;
 }
 uint32_t alias=(uint32_t)sctrlHENFindFunction("sceController_Service","sceCtrl_driver",0xbe30ced0);
 if(alias!=(uint32_t)(uintptr_t)targets[2])return install_fail(3,2);
 uint32_t exported=(uint32_t)sctrlHENFindFunction("sceVshBridge_Driver","sceVshBridge",0xc6395c03);
 SceModule *ark=sceKernelFindModuleByName("VshCtrl");
 uint32_t ab=ark?ark->text_addr:0,as=ark?ark->text_size:0;
 uint32_t snapshot[VSH_INPUT_CONTEXT_WORDS],stub[2],patched,stub_target;
 for(unsigned i=0;i<VSH_INPUT_CONTEXT_WORDS;i++)snapshot[i]=_lw(b+0x200+i*4);
 stub[0]=_lw(b+0x5608);stub[1]=_lw(b+0x560c);
 if(vsh_input_stub_target(b,(uint32_t)(uintptr_t)targets[2],ab,as,stub,&stub_target)){
  install_attempts=4;return install_fail(4,5);
 }
 int plan=vsh_input_plan(b,size,exported,stub_target,code_address((void *)vsh_read_pos),snapshot,stub,&patched);
 if(plan){install_attempts=4;return install_fail(4,(unsigned)-plan);}
 targets[4]=(Read)(uintptr_t)(b+0x5608);
 int irq=sceKernelCpuSuspendIntr();
 if(installed){sceKernelCpuResumeIntr(irq);return 0;}
 if((ark&&(ark->text_addr!=ab||ark->text_size!=as))||ctrl->text_addr!=cb||ctrl->text_size!=cs||bridge->text_addr!=b||bridge->text_size!=size){sceKernelCpuResumeIntr(irq);return install_fail(5,~0u);}
 for(unsigned i=0;i<VSH_INPUT_CONTEXT_WORDS;i++)if(_lw(b+0x200+i*4)!=snapshot[i]){
  sceKernelCpuResumeIntr(irq);return install_fail(6,4);
 }
 if(_lw(b+0x5608)!=stub[0]||_lw(b+0x560c)!=stub[1]){sceKernelCpuResumeIntr(irq);return install_fail(6,4);}
 memcpy(originals,targets,sizeof(originals));
 /* These replace syscall-table references only. Current Ctrl entry detours
  * and the bridge's original direct import remain untouched. */
 for(unsigned i=0;i<4;i++)sctrlHENPatchSyscall((void *)targets[i],(void *)hooks[i]);
 _sw(patched,b+0x25c);
 sceKernelDcacheWritebackAll();sceKernelIcacheInvalidateAll();installed=vsh_installed=1;install_error=0;guard_index=~0u;
 sceKernelCpuResumeIntr(irq);return 0;
}
