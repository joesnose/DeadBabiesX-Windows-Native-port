@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Pair-DS4.ps1"
