#!/usr/bin/env python3
import sys,json
from check_hid_stack import functions
f=functions(sys.argv[1]);a,w,frame=f['event_wait_receive']
jalr=[i for i,v in enumerate(w) if v&0xfc1fffff==0xf809]
tail=[i for i,v in enumerate(w) if v==0x03200008]
assert len(jalr)==len(tail)==1 and frame<=64
capture=[0x00808025,0x00a08825,0x00c0b825,0x00e0f025,0x0100a825,0x0120b025]
restore=[0x02002025,0x02202825,0x02e03025,0x03c03825,0x02a04025,0x02c04825]
first_direct=next(i for i,v in enumerate(w) if v>>26==3)
assert all(v in w[:first_direct] for v in capture)
assert all(v in w[max(0,jalr[0]-10):jalr[0]+2] for v in restore)
assert all(v in w[max(0,tail[0]-24):tail[0]+2] for v in restore)
allowed={f[n][0] for n in ['sceKernelCpuSuspendIntr','sceKernelCpuResumeIntr','sceKernelGetThreadId']}
assert all((((a+i*4+4)&0xf0000000)|((v&0x3ffffff)<<2)) in allowed for i,v in enumerate(w) if v>>26==3)
# Collapse bounded metadata-loop SCCs, then count original calls on every return path.
graph={};weights={}
for i,v in enumerate(w):
 op=v>>26
 if v==0x03200008:graph[i]=[];weights[i]=1
 elif v==0x03e00008:graph[i]=[];weights[i]=0
 elif i==jalr[0] or op==3:graph[i]=[i+2];weights[i]=int(i==jalr[0])
 elif op in [1,4,5,6,7,20,21,22,23]:
  imm=v&65535;imm=imm-65536 if imm&32768 else imm;dest=i+1+imm
  graph[i]=[dest] if op in [4,20] and (v>>21)&31==(v>>16)&31 else [i+2,dest];weights[i]=0
 else:graph[i]=[i+1];weights[i]=0
visited=set();order=[]
def visit(i):
 assert 0<=i<len(w)
 if i in visited:return
 visited.add(i)
 for j in graph[i]:visit(j)
 order.append(i)
visit(0);rev={i:[] for i in visited}
for i in visited:
 for j in graph[i]:rev[j].append(i)
components={};groups=[]
def assign(i,n):
 if i in components:return
 components[i]=n;groups[n].append(i)
 for j in rev[i]:assign(j,n)
for i in reversed(order):
 if i not in components:groups.append([]);assign(i,len(groups)-1)
for group in groups:
 if len(group)>1:assert not any(weights[i] for i in group)
edges={n:{components[j] for i in group for j in graph[i] if components[j]!=n} for n,group in enumerate(groups)}
memo={}
def bounds(n):
 if n in memo:return memo[n]
 extra=sum(weights[i] for i in groups[n]);values=[bounds(j) for j in edges[n]]
 result=(extra+min([v[0] for v in values],default=0),extra+max([v[1] for v in values],default=0));memo[n]=result;return result
assert bounds(components[0])==(1,1)
assert 0x00408025 in w[jalr[0]+2:jalr[0]+5] and 0x02001025 in w[jalr[0]+2:]
print(json.dumps(dict(frame=frame,six_arguments_saved_and_restored=True,normal_call_and_overflow_tail_call=True,no_retry_of_original=True,no_native_callback_file_io=True,pass_check=True)))
