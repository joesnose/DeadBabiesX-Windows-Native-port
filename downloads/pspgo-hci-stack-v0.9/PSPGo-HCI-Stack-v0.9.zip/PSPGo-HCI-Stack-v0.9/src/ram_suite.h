#ifndef RAM_SUITE_H
#define RAM_SUITE_H
#include "ram_test.h"
typedef enum {SU_DEFAULT,SU_PSI,SU_ROM,SU_RAM,SU_PADDED,SU_FULL} SuiteOp;
typedef struct {uint16_t words[25];unsigned bytes;} SuitePacket;
static inline int suite_request(unsigned key,SuiteOp op,unsigned seq,SuitePacket *out){
 if(!out||(key!=0x3c0&&key!=0x3cc)||op<SU_DEFAULT||op>SU_FULL||seq>65535)return -1;
 memset(out,0,sizeof(*out));out->bytes=50;
 uint16_t *p=out->words;p[0]=op>=SU_PADDED?2:0;p[1]=op==SU_FULL?25:9;p[2]=(uint16_t)seq;p[3]=0x7003;p[5]=(uint16_t)key;p[6]=1;
 p[7]=op==SU_DEFAULT?0:op==SU_PSI?1:op==SU_ROM?4:8;p[8]=op>=SU_PADDED?1:0;return 0;
}
/* 0 success, 2 BCCMD rejection, 3 matching GET-style reply to SET,
 * -1 malformed. Never use SET payload as proof of storage. */
static inline int suite_response(const SuitePacket *q,const uint16_t *p,size_t bytes,unsigned *value,unsigned *status){
 if(!q||!p||!value||!status||bytes<10||p[1]<5||p[1]>25||p[1]*2u>bytes||p[2]!=q->words[2]||p[3]!=0x7003)return -1;
 int set=q->words[0]==2;
 if(p[0]!=(set?3:1)){if(set&&p[0]==1){*status=p[4];return 3;}return -1;}
 *status=p[4];if(*status)return 2;
 if(set){*value=0;return 0;}
 if(p[1]<9||p[5]!=q->words[5]||p[6]!=1||p[7]!=q->words[7])return -1;
 *value=p[8];return 0;
}
static inline uint32_t suite_crc(const uint8_t *p,unsigned n){uint32_t c=~0u;for(unsigned i=0;i<n;i++){c^=p[i];for(unsigned j=0;j<8;j++)c=(c>>1)^((0u-(c&1))&0xedb88320u);}return ~c;}
static inline void suite_state_make(uint8_t p[12],unsigned count,unsigned seen,unsigned ack){
 memset(p,0,12);memcpy(p,"R9S1",4);p[4]=(uint8_t)count;p[5]=(uint8_t)seen;p[6]=(uint8_t)ack;uint32_t c=suite_crc(p,8);for(unsigned i=0;i<4;i++)p[8+i]=(uint8_t)(c>>(8*i));
}
static inline int suite_state_valid(const uint8_t p[12]){
 if(!p||memcmp(p,"R9S1",4)||p[4]>4||p[5]>3||p[6]>15||p[7])return 0;
 uint32_t c=0;for(unsigned i=0;i<4;i++)c|=(uint32_t)p[8+i]<<(8*i);return c==suite_crc(p,8);
}
#endif
