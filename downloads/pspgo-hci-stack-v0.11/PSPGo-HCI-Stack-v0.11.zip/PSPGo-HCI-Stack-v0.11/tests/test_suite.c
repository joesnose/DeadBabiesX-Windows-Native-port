#define HCI_SUITE_HOST_TEST
#include "../src/preflight.c"
#include <assert.h>
#include <stdio.h>
static struct {int exists;unsigned length;uint8_t data[16];} files[2];
static int fileid,offset,sets,style,memtype,failmarker,changebaseline,interrupt_after,failed;
static unsigned ram_present,forms;
int pspSdkSetK1(int k){(void)k;return 0;}void hci_log(const char *f,...){(void)f;}
int sceIoOpen(const char *p,int flags,int mode){(void)mode;fileid=!strcmp(p,SUITE_ONCE)?0:1;offset=0;
 if(!(flags&PSP_O_WRONLY))return files[fileid].exists?1:(int)0x80010002;
 if(files[fileid].exists||failmarker)return -1;files[fileid].exists=1;files[fileid].length=0;return 1;
}
int sceIoRead(int fd,void *out,unsigned n){(void)fd;unsigned left=files[fileid].length-(unsigned)offset;if(n>left)n=left;memcpy(out,files[fileid].data+offset,n);offset+=(int)n;return (int)n;}
int sceIoWrite(int fd,const void *data,unsigned n){(void)fd;assert(n<=16);memcpy(files[fileid].data,data,n);files[fileid].length=n;return (int)n;}
int sceIoClose(int fd){(void)fd;return 0;}int sceIoSync(const char *p,int n){(void)p;(void)n;return 0;}
static int fake(const Request *q,Response *r){
 assert(!failed);const uint16_t *t=q->data;uint16_t *p=r->data;memcpy(p,t,50);p[0]=1;r->status=0;
 if(t[3]==0x2819){p[5]=0x1918;return 1;}if(t[3]==0x3012){p[6]=(uint16_t)memtype;return 1;}
 assert(t[3]==0x7003&&(t[5]==0x3c0||t[5]==0x3cc));unsigned key=t[5]==0x3c0?0:1;
 if(t[0]==2){
  assert(files[0].exists&&t[7]==8&&t[8]==1);sets++;
  unsigned form=t[1]==25?1:0;assert(q->length==50);forms|=1u<<(key*2+form);
  if(interrupt_after&&sets>=interrupt_after){failed=1;return -7;}
  if(style==1)p[0]=1;else if(style==2){r->status=0x50;return 1;}else ram_present|=1u<<key;
  return 1;
 }
 assert(t[0]==0&&q->length==50);
 if(t[7]==8){if(!(ram_present&(1u<<key))){r->status=0x50;return 1;}p[8]=1;}
 else p[8]=t[7]==4?0:(changebaseline&&sets?0:1);return 1;
}
static void reset(void){memset(files,0,sizeof(files));sets=style=failmarker=changebaseline=interrupt_after=failed=transport_fault=0;memtype=2;ram_present=forms=0;sequence=1;query=fake;}
int main(void){
 SuitePacket q;uint16_t reply[25];unsigned value,status;
 assert(suite_request(1,SU_PADDED,1,&q)<0);assert(suite_request(0x3c0,SU_PADDED,65536,&q)<0);
 for(unsigned k=0;k<2;k++)for(unsigned f=0;f<2;f++){
  assert(!suite_request(k?0x3cc:0x3c0,(SuiteOp)(SU_PADDED+f),7,&q));assert(q.words[0]==2&&q.words[7]==8&&q.words[8]==1);
  assert(q.bytes==50&&q.words[1]==(f==1?25:9));memcpy(reply,q.words,50);reply[0]=1;
  assert(!suite_response(&q,reply,50,&value,&status));reply[0]=3;assert(suite_response(&q,reply,50,&value,&status)<0);
  reply[0]=1;reply[4]=5;assert(suite_response(&q,reply,50,&value,&status)==2&&status==5);reply[4]=0;
  assert(suite_response(&q,reply,9,&value,&status)<0);
  reply[2]++;assert(suite_response(&q,reply,50,&value,&status)<0);
 }
 reset();style=1;suite_session();assert(sets==4&&forms==15&&files[0].exists&&files[1].exists);assert(suite_state_valid(files[1].data)&&files[1].data[4]==4&&!files[1].data[5]&&files[1].data[6]==15);suite_session();assert(sets==4);
 reset();suite_session();assert(sets==4&&ram_present==3&&files[1].data[5]==3&&files[1].data[6]==15);ram_present=0;suite_session();assert(sets==4);
 reset();style=2;suite_session();assert(sets==4&&!files[1].data[5]);
 reset();memtype=0;suite_session();assert(!sets&&!files[0].exists);
 reset();failmarker=1;suite_session();assert(!sets);
 reset();changebaseline=1;suite_session();assert(sets==1&&files[1].data[4]==1);suite_session();assert(sets==1);
 reset();interrupt_after=1;suite_session();assert(sets==1&&failed);transport_fault=failed=0;interrupt_after=0;suite_session();assert(sets==1);
 reset();files[0].exists=1;files[0].length=8;suite_session();assert(!sets); /* corrupt marker */
 uint8_t state[12];suite_state_make(state,4,3,15);assert(suite_state_valid(state));state[5]^=1;assert(!suite_state_valid(state));
 puts("RAM suite: four fixed-50-byte cases, request forms/keys, documented type-1 responses and rejected ACKs, readbacks, durable summary, retention observations, baseline/transport stops and no repeated writes passed (mocks)");
}
