#ifndef CONTROLLER_ENTRY_PLAN_H
#define CONTROLLER_ENTRY_PLAN_H
#include <stdint.h>
#include <string.h>
typedef struct {uint32_t entry[2],trampoline[4];} ControllerEntryPlan;
static inline int controller_jump(uint32_t from,uint32_t to,uint32_t *out){
 if((from&3)||(to&3)||((from+4)&0xf0000000u)!=(to&0xf0000000u))return -1;
 *out=0x08000000u|((to>>2)&0x03ffffffu);return 0;
}
static inline int controller_entry_plan(unsigned index,uint32_t base,uint32_t size,
 uint32_t entry,uint32_t alias,uint32_t hook,uint32_t trampoline,const uint32_t words[8],
 ControllerEntryPlan *out){
 static const uint32_t offsets[]={0x1ae0,0x1b00,0x1b20,0x1b40};
 static const uint32_t modes[]={0x00003821,0x24070001,0x24070002,0x24070003};
 if(index>=4||!words||!out||(base&3)||base>0xffffffffu-0x1e74u||size<0x1e74u||
    entry!=base+offsets[index]||alias!=entry||(trampoline&15))return -1;
 uint32_t core,detour,back;
 if(controller_jump(entry+12,base+0x1e70,&core)||
    controller_jump(entry,hook,&detour)||controller_jump(trampoline+8,entry+8,&back))return -1;
 uint32_t expected[]={0x27bdfff0,0x00003021,0xafbf0000,core|0x04000000u,
                      modes[index],0x8fbf0000,0x03e00008,0x27bd0010};
 if(memcmp(words,expected,sizeof(expected)))return -1;
 /* Retain the selector-zero delay instruction, including for an old caller
  * already suspended at entry+4 when this resident patch is installed. */
 ControllerEntryPlan p={{detour,words[1]},{words[0],words[1],back,0}};*out=p;return 0;
}
#endif
