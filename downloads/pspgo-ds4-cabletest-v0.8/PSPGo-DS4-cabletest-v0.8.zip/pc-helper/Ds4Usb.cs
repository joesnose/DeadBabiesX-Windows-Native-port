// Copyright 2026. MIT licensed. Uses Windows' built-in HID driver.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32.SafeHandles;

public sealed class Ds4PairingInfo {
 public string Path;
 public string Controller;
 public string Host;
 public int FeatureLength;
}
public static class Ds4Usb {
 [StructLayout(LayoutKind.Sequential)] struct InterfaceData { public int Size; public Guid ClassGuid; public int Flags; public UIntPtr Reserved; }
 [StructLayout(LayoutKind.Sequential)] struct DeviceInfo { public int Size; public Guid ClassGuid; public uint DevInst; public UIntPtr Reserved; }
 [StructLayout(LayoutKind.Sequential)] struct Attributes { public int Size; public ushort Vendor, Product, Version; }
 [StructLayout(LayoutKind.Sequential)] struct Caps {
  public ushort Usage, UsagePage, InputLength, OutputLength, FeatureLength;
  [MarshalAs(UnmanagedType.ByValArray, SizeConst=17)] public ushort[] Reserved;
  public ushort Links, InputButtons, InputValues, InputIndices, OutputButtons, OutputValues, OutputIndices, FeatureButtons, FeatureValues, FeatureIndices;
 }
 [DllImport("hid.dll")] static extern void HidD_GetHidGuid(out Guid guid);
 [DllImport("hid.dll", SetLastError=true)] [return: MarshalAs(UnmanagedType.U1)] static extern bool HidD_GetAttributes(SafeFileHandle device, ref Attributes attributes);
 [DllImport("hid.dll", SetLastError=true)] [return: MarshalAs(UnmanagedType.U1)] static extern bool HidD_GetPreparsedData(SafeFileHandle device, out IntPtr data);
 [DllImport("hid.dll")] [return: MarshalAs(UnmanagedType.U1)] static extern bool HidD_FreePreparsedData(IntPtr data);
 [DllImport("hid.dll")] static extern int HidP_GetCaps(IntPtr data, out Caps caps);
 [DllImport("hid.dll", SetLastError=true)] [return: MarshalAs(UnmanagedType.U1)] static extern bool HidD_GetFeature(SafeFileHandle device, [In,Out] byte[] buffer, int length);
 [DllImport("hid.dll", SetLastError=true)] [return: MarshalAs(UnmanagedType.U1)] static extern bool HidD_SetFeature(SafeFileHandle device, byte[] buffer, int length);
 [DllImport("setupapi.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern IntPtr SetupDiGetClassDevs(ref Guid guid, string enumerator, IntPtr parent, uint flags);
 [DllImport("setupapi.dll", SetLastError=true)] [return: MarshalAs(UnmanagedType.Bool)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr list, IntPtr info, ref Guid guid, uint index, ref InterfaceData data);
 [DllImport("setupapi.dll", CharSet=CharSet.Unicode, SetLastError=true)] [return: MarshalAs(UnmanagedType.Bool)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr list, ref InterfaceData data, IntPtr detail, uint size, out uint required, ref DeviceInfo info);
 [DllImport("setupapi.dll")] [return: MarshalAs(UnmanagedType.Bool)] static extern bool SetupDiDestroyDeviceInfoList(IntPtr list);
 [DllImport("cfgmgr32.dll", CharSet=CharSet.Unicode)] static extern uint CM_Get_Device_ID(uint instance, StringBuilder buffer, uint length, uint flags);
 [DllImport("cfgmgr32.dll")] static extern uint CM_Get_Parent(out uint parent, uint instance, uint flags);
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern SafeFileHandle CreateFile(string name, uint access, uint share, IntPtr security, uint creation, uint flags, IntPtr template);
 static Exception Error(string action) { return new Win32Exception(Marshal.GetLastWin32Error(), action); }
 static SafeFileHandle Open(string path) {
  SafeFileHandle h=CreateFile(path,0xc0000000,3,IntPtr.Zero,3,0,IntPtr.Zero);
  if(h.IsInvalid){h.Dispose();throw Error("Cannot open DS4. Close other controller software and check USB.");} return h;
 }
 static bool IsUsbDs4(uint instance) {
  for(int i=0;i<12;i++){
   StringBuilder id=new StringBuilder(512);
   if(CM_Get_Device_ID(instance,id,512,0)!=0)return false;
   string text=id.ToString().ToUpperInvariant();
   if(text.StartsWith("USB\\VID_054C&PID_05C4") || text.StartsWith("USB\\VID_054C&PID_09CC"))return true;
   uint parent;if(CM_Get_Parent(out parent,instance,0)!=0)return false;instance=parent;
  }return false;
 }
 static int FeatureSize(SafeFileHandle device) {
  Attributes attr=new Attributes();attr.Size=Marshal.SizeOf(typeof(Attributes));
  if(!HidD_GetAttributes(device,ref attr))throw Error("Cannot identify controller");
  if(attr.Vendor!=0x054c || (attr.Product!=0x05c4 && attr.Product!=0x09cc))throw new InvalidOperationException("Only standard Sony DS4 USB IDs are supported.");
  IntPtr data;if(!HidD_GetPreparsedData(device,out data))throw Error("Cannot read HID capabilities");
  try {Caps caps;if(HidP_GetCaps(data,out caps)!=0x00110000)throw new InvalidOperationException("Invalid HID capabilities");
   if(caps.UsagePage!=1 || caps.Usage!=5 || caps.FeatureLength<23 || caps.FeatureLength>4096)throw new InvalidOperationException("Not a supported DS4 gamepad interface");
   return caps.FeatureLength;
  }finally{HidD_FreePreparsedData(data);}
 }
 public static byte[] ParseAddress(string value) {
  if(value==null)throw new ArgumentException("Choose pspgo_ds4_host.txt first.");
  string text=value.Trim();
  if(!System.Text.RegularExpressions.Regex.IsMatch(text,"\\A[0-9a-fA-F]{2}(:[0-9a-fA-F]{2}){5}\\z"))throw new ArgumentException("Expected one Bluetooth address, such as 02:17:3B:80:A5:FE.");
  string[] parts=text.Split(':');byte[] result=new byte[6];int any=0,all=255;
  for(int i=0;i<6;i++){result[i]=Convert.ToByte(parts[i],16);any|=result[i];all&=result[i];}
  if(any==0 || all==255)throw new ArgumentException("Empty/invalid Bluetooth address");return result;
 }
 public static string AddressText(byte[] buffer,int offset) {
  if(buffer==null || offset<0 || offset>buffer.Length-6)throw new ArgumentException("Short address buffer");
  string[] parts=new string[6];for(int i=0;i<6;i++)parts[i]=buffer[offset+5-i].ToString("X2");return String.Join(":",parts);
 }
 // BlueZ's zero-key USB cable-pairing method. This does not install a key on PSP.
 // No DS4 own-address report (0x80) is ever written.
 public static byte[] PairingReport(string host,int length) {
  if(length<23 || length>4096)throw new ArgumentException("Invalid feature length");
  byte[] address=ParseAddress(host),report=new byte[length];report[0]=0x13;
  for(int i=0;i<6;i++)report[i+1]=address[5-i];return report;
 }
 static Ds4PairingInfo Read(SafeFileHandle h,string path,int size) {
  byte[] report=new byte[size];report[0]=0x12;
  if(!HidD_GetFeature(h,report,size))throw Error("Cannot read DS4 pairing report 0x12");
  if(report[0]!=0x12)throw new InvalidOperationException("Unexpected pairing report");
  return new Ds4PairingInfo {Path=path,Controller=AddressText(report,1),Host=AddressText(report,10),FeatureLength=size};
 }
 public static Ds4PairingInfo[] Find() {
  Guid guid;HidD_GetHidGuid(out guid);IntPtr list=SetupDiGetClassDevs(ref guid,null,IntPtr.Zero,0x12);
  if(list==new IntPtr(-1))throw Error("Cannot enumerate HID devices");
  List<Ds4PairingInfo> found=new List<Ds4PairingInfo>();string lastError=null;
  try {
   for(uint i=0;;i++){
    InterfaceData data=new InterfaceData();data.Size=Marshal.SizeOf(typeof(InterfaceData));
    if(!SetupDiEnumDeviceInterfaces(list,IntPtr.Zero,ref guid,i,ref data)){
     if(Marshal.GetLastWin32Error()==259)break;throw Error("HID enumeration failed");}
    DeviceInfo info=new DeviceInfo();info.Size=Marshal.SizeOf(typeof(DeviceInfo));uint required;
    SetupDiGetDeviceInterfaceDetail(list,ref data,IntPtr.Zero,0,out required,ref info);
    if(required<8 || required>65536)continue;
    IntPtr detail=Marshal.AllocHGlobal((int)required);
    try {
     Marshal.WriteInt32(detail,IntPtr.Size==8?8:6);
     if(!SetupDiGetDeviceInterfaceDetail(list,ref data,detail,required,out required,ref info))continue;
     if(!IsUsbDs4(info.DevInst))continue;
     string path=Marshal.PtrToStringUni(IntPtr.Add(detail,4));
     try {using(SafeFileHandle h=Open(path)){int size=FeatureSize(h);found.Add(Read(h,path,size));}}
     catch(Exception ex){lastError=ex.Message;}
    }finally{Marshal.FreeHGlobal(detail);}
   }
  }finally{SetupDiDestroyDeviceInfoList(list);}
  if(found.Count==0 && lastError!=null)throw new InvalidOperationException(lastError);
  return found.ToArray();
 }
 public static Ds4PairingInfo SetHost(Ds4PairingInfo selected,string host) {
  if(selected==null)throw new ArgumentException("Select a USB controller first");
  string expected=String.Join(":",Array.ConvertAll(ParseAddress(host),delegate(byte b){return b.ToString("X2");}));
  using(SafeFileHandle h=Open(selected.Path)){
   int size=FeatureSize(h);Ds4PairingInfo before=Read(h,selected.Path,size);
   if(before.Controller!=selected.Controller)throw new InvalidOperationException("Controller changed; rescan before writing");
   byte[] report=PairingReport(host,size);
   if(!HidD_SetFeature(h,report,report.Length))throw Error("USB pairing write failed");
   Ds4PairingInfo after=Read(h,selected.Path,size);
   if(after.Host!=expected)throw new InvalidOperationException("Write was sent, but the controller did not confirm the requested host address. Do not assume pairing succeeded.");
   return after;
  }
 }
}
