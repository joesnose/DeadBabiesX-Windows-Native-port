#ifndef PATCH_PLAN_H
#define PATCH_PLAN_H
#include <stdint.h>
typedef struct {uint32_t entry[2],trampoline[4];} HookPlan;
static inline int mips_jump(uint32_t pc,uint32_t target,uint32_t *word){
 if(!word || (pc&3) || (target&3) || pc>0xfffffff8u ||
    ((pc+4)&0xf0000000u)!=(target&0xf0000000u))return -1;
 *word=0x08000000u|((target>>2)&0x03ffffffu);return 0;
}
/* These two displaced instructions contain no branch or PC-relative operation. */
static inline int registration_hook_plan(uint32_t entry,uint32_t hook,uint32_t trampoline,
                                        const uint32_t original[2],HookPlan *out){
 if(!original||!out||entry>0xfffffff0u||trampoline>0xfffffff0u||
    original[0]!=0x27bdfff0u||original[1]!=0x24860054u)return -1;
 HookPlan p={{0,0},{original[0],original[1],0,0}};
 if(mips_jump(entry,hook,&p.entry[0]) || mips_jump(trampoline+8,entry+8,&p.trampoline[2]))return -1;
 *out=p;return 0;
}
static inline int discovery_patch_allowed(uint32_t load_class,uint32_t compare){
 return load_class==0x240e0005u&&compare==0x104e0003u;
}
#endif
