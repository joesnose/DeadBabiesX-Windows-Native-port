#include <assert.h>
#include <stdio.h>
#include "event_wait_trace.h"
int main(void){
 uint32_t w[EVENT_WAIT_GUARDS]={0x27bdffd0,0xafb60028,0x0080b021,0xafb50024,0x00a0a821,0xafb40020,0x0100a021,0xafb3001c,0xafb20018,0x01209021};
 assert(event_wait_context(0x88239200,0xd000,0x88400000,w));
 for(unsigned i=0;i<EVENT_WAIT_GUARDS;i++){w[i]^=1;assert(!event_wait_context(0x88239200,0xd000,0x88400000,w));w[i]^=1;}
 assert(!event_wait_context(0x88239201,0xd000,0x88400000,w));
 assert(!event_wait_context(0x88239200,0x74ef,0x88400000,w));
 assert(!event_wait_context(0x88239200,0xd000,0x18400000,w));
 assert(!event_wait_context(0x88239200,0xd000,0x88400001,w));
 assert(!event_wait_context(0xfffff000,0xd000,0x88400000,w));
 puts("PASS: all10 event-receive prologue guards and native module/hook alignment/extent/branch restrictions");
}
