#define HCI_AUDIT_HOST_TEST
#include "../src/preflight_audit.c"
#include <assert.h>
#include <stdio.h>
static unsigned calls,fail_at;
static int scenario;
int pspSdkSetK1(int k){(void)k;return 0;}
void hci_log(const char *f,...){(void)f;}
static int fake(const Request *q,Response *r){
 const uint16_t *t=q->data;uint16_t *p=r->data;
 assert(q->id==0x70&&q->length==50&&r->id==0x170&&r->length==50);
 assert(t[0]==0&&t[1]==9); /* No write direction, reset or clear command. */
 assert(t[3]==0x2819||t[3]==0x3012||t[3]==0x3006||t[3]==0x3005||t[3]==0x7003);
 calls++;if(calls==fail_at){
  if(scenario==1)return -7;
  if(scenario==2){r->status=0x51;return 1;}
 }
 memcpy(p,t,50);p[0]=1;r->status=0;
 if(calls==fail_at&&scenario==3){p[2]++;return 1;}
 if(calls==fail_at&&scenario==4){p[4]=5;return 1;}
 if(calls==fail_at&&scenario==5){r->status=0x50;return 1;}
 if(t[3]==0x2819)p[5]=scenario==6?0x9999:0x1918;
 else if(t[3]==0x3012)p[6]=scenario==7?0:2;
 else if(t[3]==0x3006)p[6]=1;
 else if(t[3]==0x3005)p[7]=0;
 else if(t[3]==0x7003)p[8]=1;
 return 1;
}
int main(void){
 audit_native=fake;calls=fail_at=0;audit_session();assert(calls==AUDIT_QUERY_COUNT);
 for(scenario=1;scenario<=5;scenario++){
  calls=0;fail_at=3;audit_session();
  assert(calls==(scenario<=3?fail_at:AUDIT_QUERY_COUNT));
 }
 for(scenario=1;scenario<=5;scenario++){calls=0;fail_at=1;audit_session();assert(calls==1);}
 scenario=6;calls=0;fail_at=0;audit_session();assert(calls==1);
 scenario=7;calls=0;audit_session();assert(calls==2);
 puts("GET-only session: fixed envelopes/allowlist, no mutation requests, native/outer/malformed stops, inner/0050 continuation passed (mock radio)");
}
