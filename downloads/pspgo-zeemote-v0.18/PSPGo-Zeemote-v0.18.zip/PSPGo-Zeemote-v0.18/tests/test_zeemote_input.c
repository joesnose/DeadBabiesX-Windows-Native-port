#define ZEE_INPUT_HOST_TEST
#include "../src/zeemote_input.c"
#include <assert.h>
#include <stdio.h>
static uint64_t time_us;static unsigned patches;static int original_result=1;static unsigned physical;
static uint32_t native_words[0x2000/4];
static SceModule ctrl_module={0x880e6200,0x2850};
static int mutate_on_irq,alias_bad;static unsigned firmware=0x06060010;
uint64_t sceKernelGetSystemTimeWide(void){return time_us;}
int sceKernelCpuSuspendIntr(void){if(mutate_on_irq){native_words[0x1b40/4]^=1;mutate_on_irq=0;}return 0;}
void sceKernelCpuResumeIntr(int x){(void)x;}
void sceKernelDcacheWritebackAll(void){}void sceKernelIcacheInvalidateAll(void){}
SceModule *sceKernelFindModuleByName(const char *n){assert(!strcmp(n,"sceController_Service"));return &ctrl_module;}
unsigned sceKernelDevkitVersion(void){return firmware;}
uint32_t _lw(uint32_t a){assert(a>=ctrl_module.text_addr&&a<ctrl_module.text_addr+sizeof(native_words)&&!(a&3));return native_words[(a-ctrl_module.text_addr)/4];}
void _sw(uint32_t w,uint32_t a){assert(a>=ctrl_module.text_addr&&a<ctrl_module.text_addr+sizeof(native_words)&&!(a&3));native_words[(a-ctrl_module.text_addr)/4]=w;patches++;}
uint32_t zee_test_code_address(const void *p){
 for(unsigned i=0;i<4;i++)if(p==controller_trampolines[i])return 0x88301000+i*16;
 const Read hooks[]={peek_pos,peek_neg,read_pos,read_neg};
 for(unsigned i=0;i<4;i++)if(p==(void *)hooks[i])return 0x88300000+i*32;
 assert(!"unknown code pointer");return 0;
}
static void setup(void){
 installed=0;patches=0;alias_bad=0;firmware=0x06060010;mutate_on_irq=0;memset(native_words,0,sizeof(native_words));
 const unsigned offsets[]={0x1ae0,0x1b00,0x1b20,0x1b40},modes[]={0x3821,0x24070001,0x24070002,0x24070003};
 for(unsigned i=0;i<4;i++){uint32_t j;assert(!controller_jump(ctrl_module.text_addr+offsets[i]+12,ctrl_module.text_addr+0x1e70,&j));uint32_t w[]={0x27bdfff0,0x3021,0xafbf0000,j|0x04000000,modes[i],0x8fbf0000,0x03e00008,0x27bd0010};memcpy(&native_words[offsets[i]/4],w,sizeof(w));}
}
static int native_read(SceCtrlData *p,int n){if(original_result>0&&n>0){memset(p,0,sizeof(*p));p->Buttons=physical;p->Lx=128;p->Ly=128;}return original_result;}
uintptr_t sctrlHENFindFunction(const char *module,const char *library,uint32_t nid){
 assert(!strcmp(module,"sceController_Service"));
 const unsigned public_nids[]={0x3a622550,0xc152080a,0x1f803938,0x60b81f86};
 const unsigned driver_nids[]={0x2ba616af,0xe6085c33,0xbe30ced0,0x3a6a612a};
 const unsigned offsets[]={0x1ae0,0x1b00,0x1b20,0x1b40};
 for(unsigned i=0;i<4;i++)if((!strcmp(library,"sceCtrl")&&nid==public_nids[i])||(!strcmp(library,"sceCtrl_driver")&&nid==driver_nids[i]))return ctrl_module.text_addr+offsets[i]+((alias_bad&&!strcmp(library,"sceCtrl_driver"))?4:0);
 return 0;
}
int main(void){
 setup();assert(zee_input_install()==0&&patches==8);assert(zee_input_install()==0&&patches==8);
 const unsigned offsets[]={0x1ae0,0x1b00,0x1b20,0x1b40};
 for(unsigned i=0;i<4;i++)for(unsigned j=0;j<8;j++){setup();native_words[offsets[i]/4+j]^=1;assert(zee_input_install()<0&&patches==0&&!installed);}
 setup();alias_bad=1;assert(zee_input_install()<0&&patches==0);
 setup();firmware=0x06050010;assert(zee_input_install()<0&&patches==0);
 setup();mutate_on_irq=1;assert(zee_input_install()<0&&patches==0&&!installed);
 setup();assert(zee_input_install()==0&&patches==8);
 /* Host cannot execute MIPS trampolines; merge tests use a native API mock.
  * Emitted trampoline/whole-wrapper execution is tested separately. */
 for(unsigned i=0;i<4;i++)originals[i]=native_read;
 ZeeState s={.buttons=0x4000,.lx=0,.ly=255};zee_input_update(&s);SceCtrlData out;
 physical=8;assert(peek_pos(&out,1)==1&&out.Buttons==0x4008&&out.Lx==0&&out.Ly==255);
 physical=~8u;assert(read_neg(&out,1)==1&&out.Buttons==~0x4008u);
 s.lx=s.ly=128;zee_input_update(&s);physical=8;assert(read_pos(&out,1)==1&&out.Lx==128&&out.Ly==128);
 time_us=1000000;zee_input_keepalive();time_us=2000000;assert(read_pos(&out,1)==1&&out.Buttons==0x4008);
 time_us=2500000;assert(read_pos(&out,1)==1&&out.Buttons==8);time_us=0;zee_input_update(&s);zee_input_clear();assert(peek_pos(&out,1)==1&&out.Buttons==8);
 original_result=-7;assert(read_pos(&out,1)==-7);original_result=0;assert(read_pos(&out,1)==0);
 ZeeInputStats stats;zee_input_stats(&stats);assert(stats.installed&&!stats.active&&stats.seen_buttons==0x4000&&stats.motion_seen==9);assert(stats.min_lx==0&&stats.max_lx==128&&stats.min_ly==128&&stats.max_ly==255);
 puts("input adapter: atomic four-entry installation, every wrapper-word guard, alias/firmware/race rejection, positive/negative button merge, analog dead zone, live-session keepalive for unchanged reports, 1500ms monitor timeout, disconnect neutral and original-error preservation passed (mock calls)");return 0;
}
