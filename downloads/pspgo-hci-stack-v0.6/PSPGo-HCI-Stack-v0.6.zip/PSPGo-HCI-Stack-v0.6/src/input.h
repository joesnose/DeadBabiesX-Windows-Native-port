#ifndef PSPGO_INPUT_H
#define PSPGO_INPUT_H
#include "ds4_report.h"
int pspgo_input_install(void);
void pspgo_input_update(const Ds4State *state);
void pspgo_input_clear(void);
#endif
