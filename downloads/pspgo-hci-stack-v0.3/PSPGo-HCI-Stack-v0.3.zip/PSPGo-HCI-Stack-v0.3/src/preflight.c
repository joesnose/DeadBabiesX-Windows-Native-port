/* Read-only per-store mode-key inspection. Original code, MIT. */
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsdk.h>
#include <systemctrl.h>
#include "host.h"
#include "store_query.h"
typedef struct {uint16_t id,length;const void *data;} Request;
typedef struct {uint16_t id,length,status,reserved;void *data;} Response;
_Static_assert(sizeof(Request)==8&&sizeof(Response)==12,"native transaction ABI");
void pspgo_radio_preflight(void){
 SceModule *m=sceKernelFindModuleByName("sceBSMan");
 uint32_t r=sctrlHENFindFunction("sceBSMan","sceBSMan",0xed295515);
 uint32_t t=sctrlHENFindFunction("sceBSMan","sceBSMan",0xe1704dee);
 if(!m||!r||!t){hci_log("PREFLIGHT STOP: native management module unavailable\n");return;}
 uint32_t b=m->text_addr;if(m->text_size<0x5ebc||r!=b+0x5ea4||t!=b+0x385c){hci_log("PREFLIGHT STOP: management offsets differ\n");return;}
 uint32_t a[6],p[4];for(unsigned i=0;i<6;i++)a[i]=_lw(r+i*4);for(unsigned i=0;i<4;i++)p[i]=_lw(t+i*4);
 if(!radio_ready_guard(b,a)||!radio_transport_guard(b,p,_lw(b+0x3940),_lw(b+0x3944))){hci_log("PREFLIGHT STOP: management code guard mismatch\n");return;}
 int (*ready)(void)=(void *)(uintptr_t)r;int (*query)(const Request *,Response *)=(void *)(uintptr_t)t;
 for(unsigned i=0;i<30&&ready()!=1;i++)sceKernelDelayThread(1000000);
 if(ready()!=1){hci_log("PREFLIGHT STOP: management not ready\n");return;}
 hci_log("PREFLIGHT: mode-key GETs by store; no SET/reset/power change\n");
 const unsigned keys[]={0x03cc,0x03c0},stores[]={0,1,2,4,8};unsigned seq=1;
 for(unsigned k=0;k<2;k++)for(unsigned s=0;s<5;s++,seq++){
  uint16_t tx[25] __attribute__((aligned(4))),rx[25] __attribute__((aligned(4)));
  if(store_query_make(keys[k],stores[s],seq,tx)<0)return;memset(rx,0xa5,50);
  Request request={0x70,50,tx};Response response={0x170,50,0xffff,0,rx};
  hci_log("STORE GET key=%04x selector=%04x begin\n",keys[k],stores[s]);
  int k1=pspSdkSetK1(0);int result=query(&request,&response);pspSdkSetK1(k1);
  if(radio_query_skippable(result,response.status)){hci_log("STORE GET rejected outer=0050; continuing\n");continue;}
  if(result<0||response.status){hci_log("PREFLIGHT STOP: native=%08x outer=%04x\n",(unsigned)result,response.status);return;}
  unsigned status,value;int parsed=radio_query_parse(rx,50,0x7003,(uint16_t)keys[k],(uint16_t)seq,&status,&value);
  if(parsed<0){hci_log("PREFLIGHT STOP: malformed response\n");return;}
  if(parsed)hci_log("STORE GET key=%04x selector=%04x BCCMD_status=%04x\n",keys[k],stores[s],status);
  else hci_log("STORE GET key=%04x selector=%04x value=%04x reply_selector=%04x\n",keys[k],stores[s],value,rx[7]);
 }
 hci_log("PREFLIGHT DONE: reads only; HCI transition/recovery remains unverified\n");
}
