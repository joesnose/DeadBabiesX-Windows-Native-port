/* Bounded kernel formatting bridge, MIT. PSP kernel libc lacks vsnprintf. */
#include <pspsysclib.h>
#include <stdarg.h>
#include <stddef.h>
#include <limits.h>
typedef struct {char *out;size_t capacity,count;} Format;
static void emit(void *context,int ch){
 Format *f=context;if(ch==0x200){f->count=0;return;}if(ch<0||ch>255)return;
 if(f->out&&f->capacity&&f->count<f->capacity-1)f->out[f->count]=(char)ch;
 if(f->count<INT_MAX)f->count++;
}
int vsnprintf(char *out,size_t size,const char *format,va_list args){
 Format f={out,size,0};prnt(emit,&f,format,args);
 if(out&&size)out[f.count<size?f.count:size-1]=0;return (int)f.count;
}
