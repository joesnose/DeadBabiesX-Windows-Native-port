/* Experimental PSP Go native registration trace; no firmware binaries included. */
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsysmem_kernel.h>
#include <pspsysclib.h>
#include <pspsdk.h>
#include <systemctrl.h>
#include <stdarg.h>
#include <stdint.h>
#include <string.h>
#include "patch_plan.h"
PSP_MODULE_INFO("PSPGoDS4PairTest",PSP_MODULE_KERNEL,0,5);
#define LOG_PATH "ef0:/seplugins/pspgo_ds4_pair.log"
static STMOD_HANDLER previous_handler;
static uint32_t trampoline[3][4] __attribute__((aligned(16)));
static int (*original_register)(const void *,const void *);
static int (*original_no_pin)(const void *);
static int (*original_profile)(int,void *);
static int resident;
static unsigned profile_lines;
typedef struct {int seen,status,valid;unsigned flags,id;} ProfileState;
static ProfileState profile_states[8];
typedef struct {unsigned length;char data[256];} LogBuffer;
static void format_char(void *ctx,int ch){
 LogBuffer *b=ctx;if(ch==0x200)b->length=0;
 else if(ch>=0&&ch<256&&b->length<sizeof(b->data))b->data[b->length++]=(char)ch;
}
static void log_line(const char *fmt,...){
 int old=pspSdkSetK1(0);LogBuffer b={0,{0}};va_list args;
 va_start(args,fmt);prnt(format_char,&b,fmt,args);va_end(args);
 SceUID fd=sceIoOpen(LOG_PATH,PSP_O_CREAT|PSP_O_WRONLY|PSP_O_APPEND,0666);
 if(fd>=0){if(b.length)sceIoWrite(fd,b.data,b.length);sceIoClose(fd);}
 pspSdkSetK1(old);
}
static void reset_profile_cache(void){
 int irq=sceKernelCpuSuspendIntr();
 for(unsigned i=0;i<8;++i)profile_states[i].seen=0;
 sceKernelCpuResumeIntr(irq);
}
/* Arguments are forwarded unchanged. Never read/log PINs, link keys or device records. */
static int register_trace(const void *device,const void *pin){
 log_line("PIN_REGISTER begin\n");
 int result=original_register(device,pin);
 reset_profile_cache();
 log_line("PIN_REGISTER result=%08x\n",(unsigned)result);
 return result;
}
static void flush_code(void){sceKernelDcacheWritebackInvalidateAll();sceKernelIcacheInvalidateAll();}
static int no_pin_trace(const void *device_address){
 log_line("NO_PIN_REGISTER begin\n");
 int result=original_no_pin(device_address);
 reset_profile_cache();
 log_line("NO_PIN_REGISTER result=%08x\n",(unsigned)result);
 return result;
}
static int profile_trace(int index,void *record){
 int result=original_profile(index,record);
 if(index>=1 && index<=8){
  unsigned flags=0,id=0;int valid=0;
  uintptr_t address=(uintptr_t)record,physical=address&0x1fffffffu;
  unsigned alias=address&0xe0000000u;
  int irq=sceKernelCpuSuspendIntr();
  if(result>=0 && !(address&3) &&
     (alias==0 || alias==0x80000000u || alias==0xa0000000u) &&
     physical>=0x08000000u && physical<=0x0c000000u-80 && _lw(address)==0x50){
   const uint8_t *p=record;id=p[4]|((unsigned)p[5]<<8);
   flags=p[72]|((unsigned)p[73]<<8);valid=1;
  }
  ProfileState *old=&profile_states[index-1];
  int changed=!old->seen || old->status!=result || old->valid!=valid || old->flags!=flags || old->id!=id;
  old->seen=1;old->status=result;old->valid=valid;old->flags=flags;old->id=id;
  int emit=changed && profile_lines<64;if(emit)++profile_lines;
  sceKernelCpuResumeIntr(irq);
  if(emit)log_line("PROFILE slot=%d result=%08x metadata=%d id=%u flags=%04x\n",index,(unsigned)result,valid,id,flags);
 }
 return result;
}
static void install_trace(HookKind kind,uint32_t nid,uint32_t hook,const char *label){
 SceModule *mod=sceKernelFindModuleByName("sceBSMan");
 uint32_t entry=sctrlHENFindFunction("sceBSMan","sceBSMan",nid);
 if(!mod || !entry || mod->text_size<12 || entry<mod->text_addr ||
    entry-mod->text_addr>mod->text_size-12 || (entry&3)){
  log_line("%s hook skipped: export unavailable or outside module\n",label);return;
 }
 int irq=sceKernelCpuSuspendIntr();
 const uint32_t original[]={_lw(entry),_lw(entry+4)};HookPlan plan;
 int valid=native_hook_plan(entry,hook,(uint32_t)(uintptr_t)trampoline[kind],
                            original,kind,mod->text_addr,&plan)==0;
 if(valid){
  memcpy(trampoline[kind],plan.trampoline,sizeof(trampoline[kind]));
  if(kind==HOOK_PIN)original_register=(void *)trampoline[kind];
  else if(kind==HOOK_NO_PIN)original_no_pin=(void *)trampoline[kind];
  else original_profile=(void *)trampoline[kind];
  _sw(plan.entry[0],entry);_sw(plan.entry[1],entry+4);flush_code();resident=1;
 }
 sceKernelCpuResumeIntr(irq);
 if(valid)log_line("%s hook installed at module+%08x\n",label,entry-mod->text_addr);
 else log_line("%s hook skipped: prologue mismatch %08x %08x\n",label,original[0],original[1]);
}
static void patch_discovery(SceModule *mod){
 const unsigned load_offset=0x13d40,compare_offset=0x13d6c;
 if(mod->text_size<compare_offset+4){log_line("DISCOVERY skipped: module too small\n");return;}
 int irq=sceKernelCpuSuspendIntr();
 uint32_t first=_lw(mod->text_addr+load_offset),second=_lw(mod->text_addr+compare_offset);
 int valid=discovery_patch_allowed(first,second);
 if(valid){
  _sw(0x240effffu,mod->text_addr+load_offset);
  _sw(0x144e0003u,mod->text_addr+compare_offset);flush_code();
 }
 sceKernelCpuResumeIntr(irq);
 if(valid)log_line("DISCOVERY filter lifted in RAM; select only your DS4 for this test\n");
 else if(first==0x240effffu&&second==0x144e0003u)log_line("DISCOVERY filter already lifted\n");
 else log_line("DISCOVERY skipped: instruction mismatch %08x %08x\n",first,second);
}
static int module_started(SceModule *mod){
 if(mod&&!strcmp(mod->modname,"bluetooth_plugin_module"))patch_discovery(mod);
 return previous_handler?previous_handler(mod):0;
}
int module_start(SceSize args,void *argp){
 (void)args;(void)argp;
 unsigned fw=sceKernelDevkitVersion();int model=sceKernelGetModel();
 log_line("\nPSPGo DS4 native pairing test 0.5 model=%d devkit=%08x\n",model,fw);
 if(model!=4||(fw!=0x06060010&&fw!=0x06060110)){
  log_line("UNSUPPORTED model/firmware; no patches installed\n");return -1;
 }
 install_trace(HOOK_PIN,0x8ac2f7b8u,(uint32_t)(uintptr_t)register_trace,"PIN_REGISTER");
 install_trace(HOOK_NO_PIN,0x2d649923u,(uint32_t)(uintptr_t)no_pin_trace,"NO_PIN_REGISTER");
 install_trace(HOOK_PROFILE,0xcbd232d1u,(uint32_t)(uintptr_t)profile_trace,"PROFILE");
 previous_handler=sctrlHENSetStartModuleHandler(module_started);resident=1;
 SceModule *mod=sceKernelFindModuleByName("bluetooth_plugin_module");
 if(mod)patch_discovery((SceModule *)mod);
 log_line("READY: pairing experiment only; native report decoding unchanged\n");
 return 0;
}
int module_stop(SceSize args,void *argp){
 (void)args;(void)argp;
 /* Keep hook code resident. Disabling the entry and rebooting clears RAM patches. */
 if(resident)return -1;
 return 0;
}
