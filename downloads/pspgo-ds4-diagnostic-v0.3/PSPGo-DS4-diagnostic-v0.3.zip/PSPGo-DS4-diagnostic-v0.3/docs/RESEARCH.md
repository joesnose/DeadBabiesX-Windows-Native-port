# Research status — 8 November 2026

Goal: use a Sony DualShock 4 through the PSP Go's built-in Bluetooth on 6.61 ARK-5 cIPL, without an external Bluetooth/SIO board.

## Findings

- Sony's normal PSP Go path supports DualShock 3 / SIXAXIS. No verified, ready-to-use native PSP Go DS4 implementation was found in the sources examined. This is not proof that no unpublished implementation exists.
- `btfree` changes a Bluetooth VSH device-class filter. Accepting a device in the registration list does not establish controller compatibility or implement DS4 HID/report handling.
- The original PSP-Archive btfree source retains an old callback address in its 66x path. Hirador's ARK continuation documents fixing that issue and explicitly limits its scope to registration filtering. This project does not copy or install either patch.
- ste2425's controller project uses SIO plus external Bluetooth hardware. Its controller-input path is useful research but does not supply native PSP Go Bluetooth transport.
- PSP SDK does not provide a documented DS4 pairing/report API. PSPLibDoc lists native `sceBSMan`, `sceBSMan_driver`, and `sceHIDSvc_driver` exports largely as unnamed NIDs. An export's address is insufficient to call it: its ABI and state/lifetime requirements must be understood first.
- ARK-4's archived repository redirects to PSP-Arkfive/ARK-5, which was also inspected for this target. CIPL is the firmware loading mechanism; changing it does not itself add a Bluetooth HID driver.

## Remaining work

1. Confirm native modules on the actual Go and analyse their relevant APIs and calling conventions. The passive inventory PRX provides a first compatibility snapshot, not a Bluetooth traffic capture.
2. Reverse engineer the native DS3 authentication/connection path and determine how to establish DS4 authentication, SDP and HID control/interrupt channels through the native stack. Confirm radio/security-mode compatibility on hardware.
3. Implement native report reception, ownership, disconnect/suspend recovery and enabling the appropriate DS4 report mode. Do not treat a DS3-format input parser as a DS4 driver.
4. Integrate the tested decoder with kernel/controller input hooks, including positive and negative reads, multiple-sample semantics, preserving local controls, stale input timeouts and HOME handling.
5. Test initial pairing, reconnects, sleep/resume, XMB, PSP games and optional POPS on physical hardware, with both DS4 revisions if available.

No working controller-support PRX is claimed or included. Firmware binary analysis and hardware tests remain necessary; the diagnostic log alone cannot complete the driver.

## References inspected

- https://github.com/PSP-Arkfive/ARK-5 — commit 62f9936d65560c44973d2cec83d3e707d3dbe00f
- https://github.com/pspdev/psplibdoc — commit 5e15a3cff6c3642f3217b93aeb2f6b759cee1b02; especially PSPLibDoc/kd/bsman.csv and hidsvc.csv, and generated 6.61 exports.
- https://github.com/PSP-Archive/btfree
- https://github.com/Hirador/btfree-ark
- https://github.com/ste2425/PSP-Bluetooth-Plugin and https://github.com/ste2425/PSP-Bluetooth
- https://github.com/pspdev/pspsdk — kernel module inventory, Sysclib prnt and kernel export-table definitions.
- https://github.com/torvalds/linux/blob/master/drivers/hid/hid-playstation.c — DS4 Bluetooth report structure and input CRC conventions.

These are research references. Third-party plugin code, toolchain binaries and Sony firmware are not redistributed in this package.

## First v0.2 hardware result

The diagnostic ran on model 4 with devkit 06060010. It successfully read 216 sceBSMan exports (119 distinct code offsets), 3 sceHIDSvc exports, 56 controller-service exports, and 14 Bluetooth DUN exports. All those exported addresses lay inside their respective reported module code regions. scePadSvc, sceInput_Library and sceUsbBSMCDC_Driver were also loaded. No pairing or controller input was tested by this passive tool.

The logger passed an entry count where firmware expects a byte count. Exactly 64 IDs populated the 256-byte request while the reported module count was 66–72, causing empty-UID queries. v0.3 passes sizeof(ids), skips non-positive IDs, and expands metadata capture to the adjacent input/pad/USB modules. The byte-size contract is also visible in https://github.com/uofw/uofw/blob/master/src/kd/loadcore/module.c (sceKernelGetModuleIdListForKernel).

Opt-in v0.3 snapshots provide selected native driver code for offline ABI/control-flow analysis. This does not enable DS4 pairing and does not establish that the native stack can negotiate the needed connection. No user log or captured firmware binaries are included in the public diagnostic package.
