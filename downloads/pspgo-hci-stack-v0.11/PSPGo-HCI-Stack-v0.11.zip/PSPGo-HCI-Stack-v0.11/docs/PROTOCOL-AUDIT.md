# Independent CSR BCCMD response audit

Date: 2026-11-09. Offline review; no hardware operations or publication.

## Finding

The expected write-response type in the earlier RAM suite is wrong for the
documented CSR BCCMD protocol. CSR's own `BCCMD Commands`, bcore-sp-005Pe,
section 14.2 (printed page 69) and section 14.4 (page 71), show SETREQ type 2
receiving GETRESP type 1. The latter is specifically a PS-key write through
varid 0x7003, matching the command family used by our suite. Type 1 alone
therefore does not establish conversion of a write into a read.

Primary-document evidence was examined as the indexed text of the manufacturer's
manual hosted at [Manualzz](https://manualzz.com/doc/24213785/csr-bluecore-electronics-bccmd-commands-user-manual).
Direct page/PDF access through the web opener was unavailable. The finding is
independently corroborated by upstream source below; it does not depend only on
the document mirror's title or a search-result headline.

## Independent source checks

- [BlueZ 5.50 parser](https://github.com/bluez/bluez/blob/5.50/tools/parser/csr.c):
  `type2str` recognizes 0 as Get req, 1 as Get rsp, 2 as Set req, and treats
  other values as reserved. There is no recognized type-3 Set rsp.
- [BlueZ 5.50 HCI transport](https://github.com/bluez/bluez/blob/5.50/tools/csr_hci.c):
  `csr_write_hci` sends command 2 through the same response path as reads.
  That response path checks the channel and status, not a type-3 acknowledgement.
  This implementation is corroboration, not a model for relaxing our sequence,
  variable-ID, length, and bounds checks.
- [Upstream Scapy CSR implementation](https://github.com/secdev/scapy/blob/master/scapy/contrib/bluetooth_vsc_csr.py):
  its PDU-type table defines 0/1/2, and its response packet defaults to type 1.
  It cites BlueZ, so it is supporting implementation evidence rather than an
  entirely independent protocol specification.

## Re-evaluation of the existing v0.9 log

Reviewed the saved 13,361-byte combined log without changing it. The four SET
cases have the following returned header fields:

| Key | Declared words | Sequence | Type | Varid | BCCMD status |
| --- | --- | --- | --- | --- | --- |
| 03c0 | 9 | 000c | 0001 | 7003 | 0000 |
| 03c0 | 25 | 0015 | 0001 | 7003 | 0000 |
| 03cc | 9 | 001e | 0001 | 7003 | 0000 |
| 03cc | 25 | 0027 | 0001 | 7003 | 0000 |

Each also reports native outer status zero and matching PS key, length 1,
store 8, and data 1 in its saved first nine response words. These observations
are consistent with a successful BCCMD response header to SETREQ, rather than
four type errors. The previous `validated_ACK_mask=00` was produced by the
incorrect response-type requirement and is not an accurate protocol verdict.

The log explicitly says copied response extent is unknown. For the 25-word
form, only the first nine words are printed. This audit cannot retrospectively
establish the entire declared payload was delivered or validated.

## What remains unproven

Immediate store-8 reads returned native outer 0x0050, so they did not provide a
usable independently read RAM value. Default/PSI values stayed 1, which was also
the value requested by these same-value writes. Their stability cannot
distinguish a successful same-value write from an ineffective write. The log
does not prove either a failed write route or an effective RAM override.

Correct outcome: four protocol-consistent success headers, zero independently
confirmed RAM-value changes, and no evidence of standard HCI attachment or DS4
pairing. A parser correction and replay of the saved replies are justified;
changing radio mode or repeating writes is not required to prove this parser
error.
