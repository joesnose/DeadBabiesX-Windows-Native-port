#define ZEE_INPUT_HOST_TEST
#include "../src/zeemote_input.c"
#define main vsh_fixture_main
#include "test_vsh_input_plan.c"
#undef main
static uint64_t time_us;static unsigned syscall_patches,code_writes;
static int original_result=1,native_calls,mutate_on_irq,alias_bad,missing_bridge;
static unsigned physical,firmware=0x06060010;
static uint32_t bridge_words[0x6000/4];
static SceModule ctrl_module={0x880e6200,0x2850},bridge_module={0x88200000,0x6aa8};
uint64_t sceKernelGetSystemTimeWide(void){return time_us;}
int sceKernelCpuSuspendIntr(void){if(mutate_on_irq){bridge_words[0x25c/4]^=1;mutate_on_irq=0;}return 0;}
void sceKernelCpuResumeIntr(int x){(void)x;}
void sceKernelDcacheWritebackAll(void){}void sceKernelIcacheInvalidateAll(void){}
SceModule *sceKernelFindModuleByName(const char *n){if(!strcmp(n,"sceController_Service"))return &ctrl_module;assert(!strcmp(n,"sceVshBridge_Driver"));return missing_bridge?NULL:&bridge_module;}
unsigned sceKernelDevkitVersion(void){return firmware;}
uint32_t _lw(uint32_t a){assert(a>=vb&&a<vb+sizeof(bridge_words)&&!(a&3));return bridge_words[(a-vb)/4];}
void _sw(uint32_t w,uint32_t a){assert(a==vb+0x25c);bridge_words[(a-vb)/4]=w;code_writes++;}
uint32_t zee_test_code_address(const void *p){assert(p==(void *)vsh_read_pos);return hook_address;}
static int native_read(SceCtrlData *p,int n){native_calls++;if(original_result>0&&n>0){memset(p,0,sizeof(*p));p->Buttons=physical;p->Lx=128;p->Ly=128;}return original_result;}
uintptr_t sctrlHENFindFunction(const char *module,const char *library,uint32_t nid){
 if(!strcmp(module,"sceVshBridge_Driver")){assert(!strcmp(library,"sceVshBridge")&&nid==0xc6395c03);return vb+0x200;}
 assert(!strcmp(module,"sceController_Service"));
 const unsigned public_nids[]={0x3a622550,0xc152080a,0x1f803938,0x60b81f86},offsets[]={0x1ae0,0x1b00,0x1b20,0x1b40};
 for(unsigned i=0;i<4;i++)if(!strcmp(library,"sceCtrl")&&nid==public_nids[i])return ctrl_module.text_addr+offsets[i];
 assert(!strcmp(library,"sceCtrl_driver")&&nid==0xbe30ced0);return ctrl_read+(alias_bad?4:0);
}
void sctrlHENPatchSyscall(void *from,void *to){
 const unsigned offsets[]={0x1ae0,0x1b00,0x1b20,0x1b40};Read h[]={peek_pos,peek_neg,read_pos,read_neg};
 assert(syscall_patches<4&&(uintptr_t)from==ctrl_module.text_addr+offsets[syscall_patches]&&to==(void *)h[syscall_patches]);syscall_patches++;
}
static void setup(void){
 installed=vsh_installed=0;install_attempts=0;syscall_patches=code_writes=0;alias_bad=missing_bridge=mutate_on_irq=0;firmware=0x06060010;
 memset(bridge_words,0,sizeof(bridge_words));uint32_t c[34],s[2];fixture(c,s);memcpy(&bridge_words[0x200/4],c,sizeof(c));memcpy(&bridge_words[0x5608/4],s,sizeof(s));
}
int main(void){
 setup();uint32_t saved_stub[2];memcpy(saved_stub,&bridge_words[0x5608/4],sizeof(saved_stub));
 assert(zee_input_install()==0&&syscall_patches==4&&code_writes==1&&vsh_installed);
 assert(zee_input_install()==0&&syscall_patches==4&&code_writes==1);
 assert((uintptr_t)originals[4]==vb+0x5608&&!memcmp(saved_stub,&bridge_words[0x5608/4],sizeof(saved_stub)));
 for(unsigned i=0;i<34;i++){setup();bridge_words[0x200/4+i]^=1;assert(zee_input_install()<0&&syscall_patches==0&&code_writes==0);assert(install_attempts==4);}
 setup();alias_bad=1;assert(zee_input_install()<0&&!syscall_patches&&!code_writes);
 setup();firmware=0x06050010;assert(zee_input_install()<0&&!syscall_patches&&!code_writes);
 setup();mutate_on_irq=1;assert(zee_input_install()<0&&!syscall_patches&&!code_writes);
 setup();missing_bridge=1;for(unsigned i=0;i<6;i++)assert(zee_input_install()<0);assert(install_attempts==4&&!syscall_patches&&!code_writes);
 setup();assert(zee_input_install()==0);
 /* Host-native mock stands in for unchanged target functions/import stub. */
 for(unsigned i=0;i<5;i++)originals[i]=native_read;
 ZeeState state={.buttons=0x4000,.lx=0,.ly=255};zee_input_update(&state);SceCtrlData out;
 physical=8;native_calls=0;assert(vsh_read_pos(&out,1)==1&&native_calls==1&&out.Buttons==0x4008&&out.Lx==0&&out.Ly==255);
 physical=~8u;native_calls=0;assert(read_neg(&out,1)==1&&native_calls==1&&out.Buttons==~0x4008u);
 state.lx=state.ly=128;zee_input_update(&state);physical=8;assert(read_pos(&out,1)==1&&out.Lx==128&&out.Ly==128);
 time_us=1000000;zee_input_keepalive();time_us=2000000;assert(vsh_read_pos(&out,1)==1&&out.Buttons==0x4008);
 time_us=2500000;assert(vsh_read_pos(&out,1)==1&&out.Buttons==8);time_us=0;zee_input_update(&state);zee_input_clear();assert(peek_pos(&out,1)==1&&out.Buttons==8);
 original_result=-7;native_calls=0;assert(vsh_read_pos(&out,1)==-7&&native_calls==1);original_result=0;assert(read_pos(&out,1)==0);
 ZeeInputStats stats;zee_input_stats(&stats);assert(stats.vsh_installed&&stats.vsh_reads>=4);
 puts("PASS: four syscall-table redirects plus one verified VSH call write only; unchanged import/current-export chain, all-context/alias/firmware/race fail-closed guards, bounded attempts, fifth-route positive merge, once-only original errors and stale/disconnect neutral");
 return 0;
}
