/* Original PSP Go HCI transport. MIT. No firmware implementation included. */
#ifdef HCI_HOST_TEST
#include "mock_platform.h"
#else
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsysclib.h>
#include <pspsdk.h>
#include <systemctrl.h>
#endif
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include "pspgo_hci.h"
#ifndef HCI_HOST_TEST
#include "host.h"
#endif
PSP_MODULE_INFO("PSPGoHciTransport",PSP_MODULE_KERNEL,0,9);
#define HOST_MODULE "sceUSB_Host_Driver"
#define HOST_LIBRARY "sceUsbHost_driver"
#define LOG_PATH "ef0:/seplugins/pspgo_hci_transport.log"
typedef struct {unsigned count;char data[256];} LogBuffer;
static void format_char(void *context,int ch){LogBuffer *b=context;if(ch==0x200)b->count=0;else if(ch>=0&&ch<256&&b->count<sizeof(b->data))b->data[b->count++]=(char)ch;}
void hci_log(const char *fmt,...){
 LogBuffer b={0,{0}};va_list a;int old=pspSdkSetK1(0);va_start(a,fmt);prnt(format_char,&b,fmt,a);va_end(a);
 SceUID fd=sceIoOpen(LOG_PATH,PSP_O_CREAT|PSP_O_WRONLY|PSP_O_APPEND,0666);
 if(fd>=0){if(b.count)sceIoWrite(fd,b.data,b.count);sceIoClose(fd);}pspSdkSetK1(old);
}
typedef struct {uint32_t size;const char *name;int (*match)(uint32_t);int (*attach)(uint32_t);int (*detach)(uint32_t);int (*suspend)(void);} Driver;
typedef struct {uint8_t type,request;uint16_t value,index,length;} Setup;
#ifndef HCI_HOST_TEST
_Static_assert(sizeof(Driver)==24,"host class ABI");
#endif
_Static_assert(sizeof(Setup)==8,"USB setup ABI");
static int (*host_register)(Driver *);
static int (*host_info)(uint32_t,uint8_t,uint8_t,uint8_t,void *,unsigned);
static int (*host_open)(uint32_t,uint8_t);
static int (*host_close)(int);
static int (*host_cancel)(int);
typedef void (*Completion)(int,int,int,void *);
static int (*host_bulk)(int,void *,int,Completion,void *,int,uint16_t);
static int (*host_interrupt)(int,void *,int,Completion,void *,uint16_t);
static int (*host_control)(uint32_t,const Setup *,void *,int,uint16_t);
typedef struct {
 SceUID done_sem;int pipe;volatile int done,status,actual;int busy,poison,pending;
 unsigned generation;uint8_t data[1088] __attribute__((aligned(64)));
 HciStream stream;
} Channel;
static Channel channel[3]; /* event IN, ACL IN, ACL OUT */
static uint8_t command[320] __attribute__((aligned(64)));
static SceUID life=-1;
static int resident,registered,attached;
static uint32_t interface_id;
static unsigned generation;
static HciEndpoints endpoints;
static int lock(void){return sceKernelWaitSema(life,1,NULL);}
static void unlock(void){sceKernelSignalSema(life,1);}
static int descriptors(uint32_t id,HciEndpoints *ep){
 uint8_t d[9];memset(ep,0,sizeof(*ep));
 if(host_info(id,0x14,0,0,d,sizeof(d))!=9||!hci_match_interface(d,9))return HCI_ERR_UNSUPPORTED;
 ep->number=d[2];
 for(unsigned i=0;i<3;i++){uint8_t e[7];if(host_info(id,5,(uint8_t)i,0,e,7)!=7||hci_add_endpoint(ep,e,7)<0)return HCI_ERR_UNSUPPORTED;}
 return hci_endpoints_complete(ep)?0:HCI_ERR_UNSUPPORTED;
}
static int match(uint32_t id){HciEndpoints ep;return descriptors(id,&ep);}
static void completion(int pipe,int status,int actual,void *context){
 Channel *c=context;/* Never log, allocate, wait, or re-submit in completion context. */
 if(pipe!=c->pipe)return;
 c->status=status;c->actual=actual;
 int irq=sceKernelCpuSuspendIntr();c->done=1;sceKernelCpuResumeIntr(irq);
 sceKernelSignalSema(c->done_sem,1);
}
static int attach(uint32_t id){
 HciEndpoints ep;if(descriptors(id,&ep)<0)return HCI_ERR_UNSUPPORTED;
 if(lock()<0)return HCI_ERR_BUSY;
 if(attached){unlock();return HCI_ERR_BUSY;}
 for(unsigned i=0;i<3;i++)if(channel[i].busy||channel[i].poison){unlock();return HCI_ERR_BUSY;}
 uint8_t addresses[3]={ep.event_in,ep.acl_in,ep.acl_out};int result=0;
 for(unsigned i=0;i<3;i++){
  int p=host_open(id,addresses[i]);if(p<0){result=p;break;}channel[i].pipe=p;
 }
 if(result<0){for(unsigned i=0;i<3;i++)if(channel[i].pipe){host_close(channel[i].pipe);channel[i].pipe=0;}}
 else {interface_id=id;endpoints=ep;generation++;attached=1;for(unsigned i=0;i<3;i++)channel[i].stream.used=0;}
 unlock();/* No filesystem calls on the native USB host callback thread. */return result;
}
static int detach(uint32_t id){
 if(lock()<0)return HCI_ERR_BUSY;
 if(attached&&id==interface_id){
  attached=0;generation++;
  for(unsigned i=0;i<3;i++){
   Channel *c=&channel[i];if(c->pipe){
    int result=host_cancel(c->pipe);
    if(result<0||(c->pending&&!c->done)){c->poison=1;/* Keep storage resident if native cancellation cannot prove completion. */}
    else {if(host_close(c->pipe)<0)c->poison=1;else c->pipe=0;}
   }
  }
 }
 unlock();return 0;
}
static int suspend_driver(void){return 0;}
static Driver driver={24,"PSPGoHCI",match,attach,detach,suspend_driver};
static int resolve(void){
 SceModule *m=sceKernelFindModuleByName(HOST_MODULE);if(!m)return 0;
 const uint32_t nids[]={0xf8d5d089,0xf89bb575,0x8b47be52,0x922e6634,0x129d0f55,0x211e8e43,0x72b710d0,0xef9170c0};
 const uint32_t offsets[]={0x1eac,0x0d38,0x1364,0x14bc,0x155c,0x188c,0x1b84,0x1774};
 uintptr_t fn[8];if(m->text_size<0x1f00)return -1;
 for(unsigned i=0;i<8;i++){
  fn[i]=sctrlHENFindFunction(HOST_MODULE,HOST_LIBRARY,nids[i]);
  if(fn[i]!=m->text_addr+offsets[i])return -1;
  /* Refuse patched jump stubs. Exact entry-offset guards target official Go 6.61. */
  if((_lw(fn[i])>>26)==2||(_lw(fn[i])>>26)==3)return -1;
 }
 host_register=(void *)fn[0];host_info=(void *)fn[1];host_open=(void *)fn[2];host_close=(void *)fn[3];
 host_cancel=(void *)fn[4];host_bulk=(void *)fn[5];host_interrupt=(void *)fn[6];host_control=(void *)fn[7];return 1;
}
static int valid_context(unsigned timeout){return life>=0&&!sceKernelIsIntrContext()&&timeout>=1&&timeout<=1000;}
int pspgoHciGetState(void){
 if(life<0||sceKernelIsIntrContext())return HCI_ERR_ARGUMENT;
 if(lock()<0)return HCI_ERR_BUSY;int state=registered?attached:HCI_ERR_DISCONNECTED;unlock();return state;
}
/* Caller owns this channel (busy) until finish. life protects submit versus detach.
 * Native cancellation synchronously drains its pipe. Never recycle an unconfirmed
 * completion: poison instead, retaining all buffers until full reboot. */
static int transfer(Channel *c,unsigned index,unsigned size,unsigned timeout){
 if(lock()<0)return HCI_ERR_BUSY;
 if(!attached||c->generation!=generation){unlock();return HCI_ERR_DISCONNECTED;}
 while(sceKernelPollSema(c->done_sem,1)==0){}
 c->done=0;c->actual=0;c->status=0;c->pending=1;
 sceKernelDcacheWritebackInvalidateRange(c->data,sizeof(c->data));
 int result=index==0?host_interrupt(c->pipe,c->data,(int)size,completion,c,5):
  host_bulk(c->pipe,c->data,(int)size,completion,c,index==2?(int)timeout:-1,index==2?13:5);
 if(result<0){c->pending=0;unlock();return result;}unlock();
 SceUInt wait=timeout*1000;int waited=sceKernelWaitSema(c->done_sem,1,&wait);
 if(lock()<0)return HCI_ERR_BUSY;
 if(!c->done&&attached&&c->generation==generation){
  int cancelled=host_cancel(c->pipe);
  if(cancelled<0||!c->done){c->poison=1;attached=0;generation++;}
 }
 if(!c->done){c->poison=1;result=HCI_ERR_PROTOCOL;}
 else if(c->generation!=generation)result=HCI_ERR_DISCONNECTED;
 else if(waited<0)result=HCI_ERR_TIMEOUT;
 else if(c->status<0)result=c->status;
 else if(c->actual<0||(unsigned)c->actual>size)result=HCI_ERR_PROTOCOL;
 else result=c->actual;
 if(c->done)c->pending=0;
 /* A failed receive may have consumed an unknown prefix. Quarantine instead of
  * interpreting subsequent bytes at an unproven HCI packet boundary. */
 if(result<0&&index!=2&&(!c->done||c->actual!=0))c->poison=1;
 sceKernelDcacheInvalidateRange(c->data,sizeof(c->data));unlock();return result;
}
static int begin(unsigned index,Channel **out){
 if(lock()<0)return HCI_ERR_BUSY;Channel *c=&channel[index];
 int result=0;if(!attached)result=HCI_ERR_DISCONNECTED;else if(c->busy||c->poison)result=HCI_ERR_BUSY;
 else {c->busy=1;c->generation=generation;*out=c;}unlock();return result;
}
static int finish(Channel *c,int result){if(lock()<0)return HCI_ERR_BUSY;if(c->generation!=generation)c->stream.used=0;if(!c->poison)c->busy=0;unlock();return result;}
int pspgoHciSendCommand(const void *packet,unsigned length,unsigned timeout){
 if(!valid_context(timeout)||!hci_valid_command(packet,length))return HCI_ERR_ARGUMENT;
 if(lock()<0)return HCI_ERR_BUSY;if(!attached){unlock();return HCI_ERR_DISCONNECTED;}
 memcpy(command,packet,length);sceKernelDcacheWritebackInvalidateRange(command,sizeof(command));
 Setup setup={0x20,0,0,0,(uint16_t)length};
 int result=host_control(interface_id,&setup,command,(int)timeout,0);
 unlock();return result;
}
int pspgoHciSendAcl(const void *packet,unsigned length,unsigned timeout){
 if(!valid_context(timeout)||!hci_valid_acl(packet,length))return HCI_ERR_ARGUMENT;
 Channel *c;int result=begin(2,&c);if(result<0)return result;
 memcpy(c->data,packet,length);result=transfer(c,2,length,timeout);return finish(c,result);
}
static int read_packet(unsigned index,void *out,unsigned cap,unsigned timeout){
 if(!valid_context(timeout)||!out||cap<(index?4u:2u))return HCI_ERR_ARGUMENT;
 Channel *c;int result=begin(index,&c);if(result<0)return result;
 uint64_t deadline=sceKernelGetSystemTimeWide()+(uint64_t)timeout*1000;
 for(;;){
  result=hci_stream_take(&c->stream,index!=0,out,cap);
  if(result==HCI_ERR_PROTOCOL){lock();c->poison=1;unlock();}
  if(result)break;
  uint64_t now=sceKernelGetSystemTimeWide();if(now>=deadline){result=HCI_ERR_TIMEOUT;break;}
  unsigned remaining=((unsigned)(deadline-now)+999)/1000;
  unsigned receive=index?1024u:((HCI_MAX_EVENT+endpoints.event_mps-1)/endpoints.event_mps)*endpoints.event_mps;
  result=transfer(c,index,receive,remaining);if(result<0)break;
  if(hci_stream_feed(&c->stream,c->data,(unsigned)result)<0){c->stream.used=0;lock();c->poison=1;unlock();result=HCI_ERR_PROTOCOL;break;}
  if(result==0)sceKernelDelayThread(1000);
 }
 return finish(c,result);
}
int pspgoHciReadEvent(void *packet,unsigned cap,unsigned timeout){return read_packet(0,packet,cap,timeout);}
int pspgoHciReadAcl(void *packet,unsigned cap,unsigned timeout){return read_packet(1,packet,cap,timeout);}
static int worker(SceSize args,void *argp){
 (void)args;(void)argp;
 for(unsigned i=0;i<180;i++){
  int result=resolve();if(result<0){hci_log("STOP: USB host ABI guard mismatch; no registration\n");return 0;}
  if(result>0){result=host_register(&driver);if(result==0){lock();registered=1;unlock();hci_log("REGISTERED: stack v0.10 waiting for standard USB HCI interface\nRadio experiments disabled; host waits for actual HCI attachment\n");
#ifndef HCI_HOST_TEST
pspgo_host_run();
#endif
return 0;}
   /* Host module can exist before initialization. Retry boundedly. */
  }
  sceKernelDelayThread(1000000);
 }
 hci_log("STOP: native USB host not ready within 180 seconds\n");return 0;
}
int module_start(SceSize args,void *argp){
 (void)args;(void)argp;unsigned fw=sceKernelDevkitVersion();
 hci_log("\nPSP Go HCI stack 0.10 model=%d devkit=%08x\n",sceKernelGetModel(),fw);
 if(sceKernelGetModel()!=4||(fw!=0x06060010&&fw!=0x06060110)){hci_log("STOP: requires PSP Go reporting 6.60 or 6.61\n");return -1;}
 life=sceKernelCreateSema("HciLifecycle",0,1,1,NULL);if(life<0)return -1;
 for(unsigned i=0;i<3;i++){
  channel[i].done_sem=sceKernelCreateSema("HciCompletion",0,0,1,NULL);
  if(channel[i].done_sem<0){for(unsigned j=0;j<i;j++)sceKernelDeleteSema(channel[j].done_sem);sceKernelDeleteSema(life);life=-1;return -1;}
 }
 SceUID thread=sceKernelCreateThread("HciRegister",worker,0x30,32768,0,NULL);
 if(thread<0){for(unsigned i=0;i<3;i++)sceKernelDeleteSema(channel[i].done_sem);sceKernelDeleteSema(life);life=-1;return -1;}
 resident=1;int result=sceKernelStartThread(thread,0,NULL);
 if(result<0){resident=0;sceKernelDeleteThread(thread);for(unsigned i=0;i<3;i++)sceKernelDeleteSema(channel[i].done_sem);sceKernelDeleteSema(life);life=-1;return -1;}return 0;
}
int module_stop(SceSize args,void *argp){(void)args;(void)argp;return resident?-1:0;}
