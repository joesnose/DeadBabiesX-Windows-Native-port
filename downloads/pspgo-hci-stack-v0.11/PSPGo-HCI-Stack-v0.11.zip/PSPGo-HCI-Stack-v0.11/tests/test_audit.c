#include <assert.h>
#include <stdio.h>
#include "../src/audit_query.h"

static void test_allowlist(void) {
    size_t i,j;
    uint8_t b[52]; struct aq_query q; struct aq_value v;
    const uint16_t vars[16]={0x2819,0x3012,0x3006,0x3006,0x3006,0x3006,
        0x3006,0x3006,0x3006,0x3006,0x7003,0x7003,0x3005,0x3005,0x7003,0x7003};
    const uint16_t keys[16]={0,0,0x3c0,0x3c0,0x3c0,0x3c0,
        0x3cc,0x3cc,0x3cc,0x3cc,0x1fd,0x3cd,0x3bf,0x3cb,0x3c0,0x3cc};
    const uint16_t stores[16]={0,8,0,1,4,8,0,1,4,8,0,0,8,8,8,8};
    for(i=0;i<16;i++) {
        memset(b,0xcc,sizeof b);
        assert(aq_get_query(i,&q));
        assert(q.varid==vars[i] && q.key==keys[i] && q.store==stores[i]);
        assert(aq_build_request(i,0x1234,b+1,50));
        assert(b[0]==0xcc && b[51]==0xcc);
        assert(aq_u16(b+1)==0 && aq_u16(b+3)==9);
        assert(aq_u16(b+5)==0x1234 && aq_u16(b+7)==vars[i]);
        assert(aq_u16(b+9)==0);
        for(j=19;j<=50;j++) assert(b[j]==0);
        aq_put(b+1,1);
        switch(q.kind) {
        case AQ_BUILD: aq_put(b+11,6424); break;
        case AQ_MEMORY: aq_put(b+13,2); break;
        case AQ_SIZE: aq_put(b+13,1); break;
        case AQ_NEXT: aq_put(b+15,(uint16_t)(q.key+1)); break;
        case AQ_SCALAR: aq_put(b+17,1); break;
        }
        assert(aq_parse_response(i,0x1234,0,b+1,18,&v)==AQ_OK && v.valid);
        assert(v.value==(q.kind==AQ_BUILD?6424:q.kind==AQ_MEMORY?2:
                         q.kind==AQ_NEXT?q.key+1:1));
    }
    assert(!aq_get_query(16,&q)); assert(!aq_get_query((size_t)-1,&q));
    assert(!aq_get_query(0,NULL));
    assert(!aq_build_request(0,1,b,49));
    assert(!aq_build_request(16,1,b,50));
    assert(!aq_build_request(0,1,NULL,50));
}
static void test_validation(void) {
    uint8_t b[50]; size_t n; struct aq_value v;
    assert(aq_build_request(5,42,b,sizeof b)); aq_put(b,1); aq_put(b+12,1);
    /* PS_SIZE returns length in word6 even though request store was8. */
    assert(aq_parse_response(5,42,0,b,18,&v)==AQ_OK && v.value==1);
    for(n=0;n<18;n++) assert(aq_parse_response(5,42,0,b,n,&v)==AQ_INVALID && !v.valid);
    assert(aq_parse_response(5,42,0,NULL,50,&v)==AQ_INVALID);
    assert(aq_parse_response(5,42,0,b,50,NULL)==AQ_INVALID);
    assert(aq_parse_response(16,42,0,b,50,&v)==AQ_INVALID);
    assert(aq_parse_response(5,43,0,b,50,&v)==AQ_INVALID && !v.valid);
    aq_put(b,3); assert(aq_parse_response(5,42,0,b,50,&v)==AQ_INVALID);
    aq_put(b,1); aq_put(b+6,0x4002);
    assert(aq_parse_response(5,42,0,b,50,&v)==AQ_INVALID);
    aq_put(b+6,0x3006); aq_put(b+2,26);
    assert(aq_parse_response(5,42,0,b,50,&v)==AQ_INVALID);
    aq_put(b+2,25);
    assert(aq_parse_response(5,42,0,b,49,&v)==AQ_INVALID);
    assert(aq_parse_response(5,42,0,b,50,&v)==AQ_OK);
    aq_put(b+2,7);
    assert(aq_parse_response(5,42,0,b,14,&v)==AQ_OK && v.value==1);
    aq_put(b+2,6);
    assert(aq_parse_response(5,42,0,b,12,&v)==AQ_INVALID);
    aq_put(b+2,5); aq_put(b+8,5);
    assert(aq_parse_response(5,42,0,b,10,&v)==AQ_BCCMD_ERROR && v.status==5 && !v.valid);
    assert(aq_parse_response(5,42,0x50,NULL,0,&v)==AQ_OUTER_ERROR && !v.valid && !v.value && !v.status);
    aq_put(b+2,9); aq_put(b+8,0); aq_put(b+10,0x3cc);
    assert(aq_parse_response(5,42,0,b,50,&v)==AQ_INVALID && !v.valid);
    assert(aq_build_request(10,1,b,50)); aq_put(b,1); aq_put(b+12,2);
    assert(aq_parse_response(10,1,0,b,50,&v)==AQ_INVALID);
    aq_put(b+12,1); aq_put(b+14,8);
    assert(aq_parse_response(10,1,0,b,50,&v)==AQ_INVALID);
    assert(aq_build_request(12,1,b,50)); aq_put(b,1); aq_put(b+12,0);
    assert(aq_parse_response(12,1,0,b,50,&v)==AQ_INVALID);
}
int main(void) {
    uint16_t words[25],status,value;
    test_allowlist(); test_validation();
    assert(AUDIT_QUERY_COUNT==16);
    assert(audit_make(0,1,words)); aq_put((uint8_t *)words,1);
    assert(audit_parse(0,1,words,18,&status,&value)==0 && status==0);
    aq_put((uint8_t *)words+2,5); aq_put((uint8_t *)words+8,5);
    assert(audit_parse(0,1,words,10,&status,&value)==1 && status==5 && value==0);
    assert(audit_parse(0,2,words,18,&status,&value)==-1);
    puts("audit query tests passed"); return 0;
}
