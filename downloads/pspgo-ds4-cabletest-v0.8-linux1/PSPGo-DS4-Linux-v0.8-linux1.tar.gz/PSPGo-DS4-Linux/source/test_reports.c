#include <assert.h>
#include <stdio.h>
#include "pair_report.h"
int main(void){
 uint8_t address[6];uint8_t report[25];memset(report,0xa5,sizeof(report));
 assert(!parse_address("02:17:3b:80:A5:FE",address));
 pairing_report(address,report);
 const uint8_t prefix[]={0x13,0xfe,0xa5,0x80,0x3b,0x17,2};
 assert(!memcmp(report,prefix,sizeof(prefix)));
 for(unsigned i=7;i<23;i++)assert(report[i]==0);
 assert(report[23]==0xa5&&report[24]==0xa5);
 char text[20];memset(text,'!',sizeof(text));decode_address(report+1,text);
 assert(!strcmp(text,"02:17:3B:80:A5:FE"));assert(text[18]=='!');
 const char *bad[]={"","00:00:00:00:00:00","FF:FF:FF:FF:FF:FF","02-17-3B-80-A5-FE","02:17:3B:80:A5:FE extra","GG:17:3B:80:A5:FE","0:17:3B:80:A5:FE"};
 for(unsigned i=0;i<sizeof(bad)/sizeof(bad[0]);i++)assert(parse_address(bad[i],address));
 assert(parse_address(NULL,address));
 puts("PASS: report 13 ID, little-endian host address, zero key, buffer bounds, decoding and invalid-address rejection");
}
