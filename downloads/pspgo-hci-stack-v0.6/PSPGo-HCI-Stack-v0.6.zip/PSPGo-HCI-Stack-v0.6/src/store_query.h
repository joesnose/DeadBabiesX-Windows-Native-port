#ifndef STORE_QUERY_H
#define STORE_QUERY_H
#include "radio_query.h"
/* Read-only next-step preflight. Exactly two mode keys and explicit store
 * selectors. SET, warm/cold reset, address/link-key access are unrepresentable. */
static inline int store_query_allowed(unsigned key,unsigned store){
 return (key==0x03cc||key==0x03c0)&&(store==0||store==1||store==2||store==4||store==8);
}
static inline int store_query_make(unsigned key,unsigned store,unsigned seq,uint16_t out[25]){
 if(!out||!store_query_allowed(key,store)||seq>65535)return -1;
 memset(out,0,50);out[0]=0;out[1]=9;out[2]=(uint16_t)seq;out[3]=0x7003;out[5]=(uint16_t)key;out[6]=1;out[7]=(uint16_t)store;return 0;
}
#endif
