#ifndef REGISTRATION_POLICY_H
#define REGISTRATION_POLICY_H
#include <stdint.h>
#include <string.h>
#define PIN_STUB_WORDS 74
#define PIN_STUB_BYTES (PIN_STUB_WORDS*4)
typedef struct {uint32_t entry,pin_zero_delay,code[PIN_STUB_WORDS];} NativePinPlan;
/* One verified UI call site only. All offsets are from the examined UI module.
 * Names/classes are a selected-device heuristic, never authenticated identity. */
static inline int native_pin_context(uint32_t base,const uint32_t c[13]){
 uint32_t call,ctor,alloc,memset_call,branch;
 if(!c||base>0xfffdf48fu||mips_jump(base+0x13f1c,base+0x1427c,&call)||
 mips_jump(base+0x13f3c,base+0x13a84,&ctor)||mips_jump(base+0x13f2c,base+0x1abe0,&alloc)||
 mips_jump(base+0x13af8,base+0x1a9b8,&memset_call)||mips_jump(base+0x13f44,base+0x13f00,&branch))return 0;
 return c[0]==(call|0x04000000u)&&c[1]==0x02002821u&&c[2]==0x10400009u&&c[3]==0x02202021u&&
 c[4]==(alloc|0x04000000u)&&c[5]==0x24040078u&&c[6]==(ctor|0x04000000u)&&c[7]==0x00408021u&&
 c[8]==branch&&c[9]==0x02001821u&&c[10]==(memset_call|0x04000000u)&&c[11]==0x24060010u&&c[12]==base+0x13b28;
}
static inline int native_pin_plan(uint32_t base,uint32_t stub,const uint32_t context[13],NativePinPlan *out){
 if(!out||!native_pin_context(base,context)||stub>0xffffffffu-PIN_STUB_BYTES||(stub&3))return -1;
 NativePinPlan p;memset(&p,0,sizeof(p));uint32_t j;
 if(mips_jump(base+0x13f1c,stub,&j))return -1;
 p.entry=j|0x04000000u;
 /* Sole examined constructor caller allocates120 bytes; PIN at+88 fits32. */
 p.pin_zero_delay=0x24060020u;
 /* v0 reproduces the original predicate. Other written registers are caller
  * temporaries. a0/a1, saved registers, sp and ra remain untouched. */
 uint32_t code[]={
  0x90a20000u, /* lbu v0,0(a1) */
  0x30420020u, /* andi v0,v0,32 */
  0x14400023u,0, /* original true -> accept */
  0x8ca3ffb8u,0x24080054u,0x14680020u,0, /* record size84 */
  0x94a3ffbcu,0x1060001du,0, /* real discovery identifier */
  0x90a30002u,0x306300ffu,0x24080008u,0x14680018u,0, /* CoD bytes are high/middle/low; minor is byte2 */
  0x90a30001u,0x3063001fu,0x24080005u,0x14680013u,0, /* peripheral major */
  0x24a8ffbeu, /* addiu t0,a1,-66: name starts record+6 */
  0,0, /* t1 points at inline UTF16 name */
  0x950a0000u,0x952b0000u,0x154b000bu,0, /* compare exact UTF16 incl NUL */
  0x11400009u,0, /* NUL -> accept */
  0x25080002u,0x25290002u,0x1000fff7u,0,
  0,0,0,0, /* reserved, unreachable */
  0x24020001u,0x03e00008u,0, /* accept at index38 */
  0x00001021u,0x03e00008u,0 /* reject at index41 */
 };
 /* Patch branch targets from indices; all branch delay slots are NOP. */
 unsigned reject[]={6,9,14,19,26};
 for(unsigned i=0;i<sizeof(reject)/sizeof(reject[0]);i++){unsigned k=reject[i];code[k]=(code[k]&0xffff0000u)|(uint16_t)(41-(int)k-1);}
 code[2]=(code[2]&0xffff0000u)|(uint16_t)(38-2-1);
 code[28]=(code[28]&0xffff0000u)|(uint16_t)(38-28-1);
 code[32]=0x10000000u|(uint16_t)(24-32-1);
 uint32_t name=stub+256;code[22]=0x3c090000u|(name>>16);code[23]=0x35290000u|(name&0xffff);
 memcpy(p.code,code,sizeof(code));
 const char *name_text="Wireless Controller";
 for(unsigned i=0;name_text[i];i++){unsigned byte=256+i*2;p.code[byte/4]|=(uint32_t)(uint8_t)name_text[i]<<((byte%4)*8);}
 *out=p;return 0;
}
#endif
