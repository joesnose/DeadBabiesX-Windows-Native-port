/* Bounded GET-only radio audit. Original adapter, MIT. */
#ifdef HCI_AUDIT_HOST_TEST
#include "mock_platform.h"
#else
#include <pspkernel.h>
#include <psploadcore.h>
#include <pspsdk.h>
#include <systemctrl.h>
#endif
#include "host.h"
#include "radio_query.h"
#include "audit_query.h"
typedef struct {uint16_t id,length;const void *data;} Request;
typedef struct {uint16_t id,length,status,reserved;void *data;} Response;
#ifndef HCI_AUDIT_HOST_TEST
_Static_assert(sizeof(Request)==8&&sizeof(Response)==12,"native query ABI");
#endif
static int (*audit_native)(const Request *,Response *);
static void audit_session(void){
 unsigned completed=0,successful=0,outer_errors=0,inner_errors=0;
 hci_log("AUDIT v0.11: fixed GET-only batch; no SET, reset, power, clear or mode change\n");
 for(unsigned i=0;i<AUDIT_QUERY_COUNT;i++){
  uint16_t tx[25] __attribute__((aligned(4))),rx[25] __attribute__((aligned(4)));
  if(!audit_make(i,(uint16_t)(i+1),tx)){hci_log("AUDIT STOP: allowlist failure\n");return;}
  struct aq_query spec;aq_get_query(i,&spec);
  Request q={0x70,50,tx};Response r={0x170,50,0xffff,0,rx};memset(rx,0xa5,sizeof(rx));
  hci_log("AUDIT query=%u kind=%u varid=%04x key=%04x store=%04x words=%u seq=%u begin\n",i,(unsigned)spec.kind,spec.varid,spec.key,spec.store,tx[1],tx[2]);
  int k1=pspSdkSetK1(0),native=audit_native(&q,&r);pspSdkSetK1(k1);
  hci_log("AUDIT native=%08x outer=%04x capacity=50 copied_extent_unknown\n",(unsigned)native,r.status);
  if(native<0){hci_log("AUDIT STOP: native failure; no subsequent queries or retries\n");return;}
  completed++;
  if(r.status){outer_errors++;if(r.status==0x50&&i>=2)continue;hci_log("AUDIT STOP: unexpected outer error\n");return;}
  hci_log("AUDIT header=%04x %04x %04x %04x %04x fields=%04x %04x %04x %04x\n",rx[0],rx[1],rx[2],rx[3],rx[4],rx[5],rx[6],rx[7],rx[8]);
  uint16_t status=0,value=0;int parsed=audit_parse(i,(uint16_t)(i+1),rx,sizeof(rx),&status,&value);
  if(parsed<0){hci_log("AUDIT STOP: malformed or mismatched response\n");return;}
  if(parsed){inner_errors++;hci_log("AUDIT query=%u inner_error=%04x no_value_interpreted\n",i,status);if(i<2){hci_log("AUDIT STOP: metadata prerequisite unavailable\n");return;}}
  else {successful++;hci_log("AUDIT query=%u value=%04x\n",i,value);
   if((i==0&&value!=0x1918)||(i==1&&value!=2)){hci_log("AUDIT STOP: known build/RAM metadata differs\n");return;}
  }
 }
 hci_log("AUDIT DONE count=%u values=%u outer_errors=%u inner_errors=%u; no write-effect or HCI claim\n",completed,successful,outer_errors,inner_errors);
}
#ifndef HCI_AUDIT_HOST_TEST
void pspgo_radio_preflight(void){
 SceModule *m=sceKernelFindModuleByName("sceBSMan");
 uint32_t ready_addr=sctrlHENFindFunction("sceBSMan","sceBSMan",0xed295515);
 uint32_t query_addr=sctrlHENFindFunction("sceBSMan","sceBSMan",0xe1704dee);
 if(!m||!ready_addr||!query_addr){hci_log("AUDIT STOP: native module unavailable\n");return;}
 uint32_t b=m->text_addr;
 if(m->text_size<0x5ebc||ready_addr!=b+0x5ea4||query_addr!=b+0x385c){hci_log("AUDIT STOP: module offsets differ\n");return;}
 uint32_t state[6],code[4];for(unsigned i=0;i<6;i++)state[i]=_lw(ready_addr+i*4);for(unsigned i=0;i<4;i++)code[i]=_lw(query_addr+i*4);
 if(!radio_ready_guard(b,state)||!radio_transport_guard(b,code,_lw(b+0x3940),_lw(b+0x3944))){hci_log("AUDIT STOP: code guard mismatch\n");return;}
 int (*ready)(void)=(void *)(uintptr_t)ready_addr;
 for(unsigned i=0;i<30&&ready()!=1;i++)sceKernelDelayThread(1000000);
 if(ready()!=1){hci_log("AUDIT STOP: native management not ready\n");return;}
 audit_native=(void *)(uintptr_t)query_addr;audit_session();
}
#endif
