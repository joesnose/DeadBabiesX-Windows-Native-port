#include "controller_entry_plan.h"
#include <assert.h>
#include <stdio.h>
static const uint32_t base=0x880e6200,hook=0x88300000,tramp=0x88301000;
static void execute(unsigned index,int result,int preempted){
 const unsigned offsets[]={0x1ae0,0x1b00,0x1b20,0x1b40},modes[]={0x3821,0x24070001,0x24070002,0x24070003};
 uint32_t entry=base+offsets[index],j;
 assert(!controller_jump(entry+12,base+0x1e70,&j));
 uint32_t stock[]={0x27bdfff0,0x3021,0xafbf0000,j|0x04000000u,modes[index],0x8fbf0000,0x03e00008,0x27bd0010};
 ControllerEntryPlan p;assert(!controller_entry_plan(index,base,0x2850,entry,entry,hook,tramp,stock,&p));
 assert(p.entry[1]==0x00003021);
 uint32_t words[8];memcpy(words,stock,sizeof(words));memcpy(words,p.entry,sizeof(p.entry));
 uint32_t r[32]={0},stack[8]={0};r[4]=0x09000000;r[5]=4;r[6]=0x1234;r[7]=0x5678;r[29]=0x09010020;r[31]=0x08801234;
 uint32_t pc=preempted?entry+4:entry,saved_ra=0;unsigned core_calls=0,hook_calls=0,returns=0;
 if(preempted)r[29]-=16; /* Old first instruction ran before installation. */
 for(unsigned step=0;step<40;step++){
  if(pc==hook){hook_calls++;assert(r[4]==0x09000000&&r[5]==4);saved_ra=r[31];r[31]=hook+0x100;pc=tramp;continue;}
  if(pc==base+0x1e70){core_calls++;assert(r[4]==0x09000000&&r[5]==4&&r[6]==0&&r[7]==index);assert(r[29]==0x09010010);r[2]=(uint32_t)result;pc=r[31];continue;}
  if(pc==hook+0x100){returns++;assert(r[31]==hook+0x100&&r[29]==0x09010020);assert((int32_t)r[2]==result);r[31]=saved_ra;break;}
  if(pc==0x08801234&&preempted){returns++;assert(r[29]==0x09010020&&(int32_t)r[2]==result);break;}
  uint32_t w,delay=0;
  if(pc>=entry&&pc<entry+32){w=words[(pc-entry)/4];if(pc+4<entry+32)delay=words[(pc-entry)/4+1];}
  else {assert(pc>=tramp&&pc<tramp+16);w=p.trampoline[(pc-tramp)/4];if(pc+4<tramp+16)delay=p.trampoline[(pc-tramp)/4+1];}
  unsigned op=w>>26,rs=(w>>21)&31,rt=(w>>16)&31;int32_t imm=(int16_t)w;
  if(op==2||op==3||w==0x03e00008){
   uint32_t target=w==0x03e00008?r[31]:((pc+4)&0xf0000000)|((w&0x3ffffff)<<2);
   if(op==3)r[31]=pc+8;
   if(delay==0x27bd0010)r[29]+=16;
   else if(delay==0x3021)r[6]=0;
   else if(delay==0x3821)r[7]=0;
   else if((delay&0xffff0000u)==0x24070000u)r[7]=delay&0xffff;
   else assert(delay==0);
   pc=target;continue;
  }
  if(op==9)r[rt]=r[rs]+imm;
  else if(w==0x3021)r[6]=0;
  else if(w==0xafbf0000){assert(r[29]==0x09010010);stack[0]=r[31];}
  else if(w==0x8fbf0000)r[31]=stack[0];
  else assert(!"unexpected emitted/stock instruction");
  pc+=4;
 }
 assert(hook_calls==(preempted?0u:1u)&&core_calls==1&&returns==1&&r[31]==0x08801234);
 for(unsigned k=0;k<8;k++){stock[k]^=1;assert(controller_entry_plan(index,base,0x2850,entry,entry,hook,tramp,stock,&p)<0);stock[k]^=1;}
 assert(controller_entry_plan(index,base,0x2850,entry,entry+4,hook,tramp,stock,&p)<0);
 assert(controller_entry_plan(index,base,0x2850,entry,entry,0x08300000,tramp,stock,&p)<0);
}
int main(void){
 for(unsigned i=0;i<4;i++)for(int preempted=0;preempted<2;preempted++){
  execute(i,1,preempted);execute(i,0,preempted);execute(i,-7,preempted);execute(i,(int32_t)0x80000103u,preempted);
 }
 puts("PASS: emitted entry/trampoline plus complete stock wrapper execution, SP/RA/argument preservation, once-only core calls, all four modes and exact negative returns; all instruction/alias/region guards");
}
