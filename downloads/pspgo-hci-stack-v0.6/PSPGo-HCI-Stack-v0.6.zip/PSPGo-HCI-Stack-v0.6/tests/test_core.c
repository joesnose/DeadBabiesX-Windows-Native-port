#include "../src/hci_core.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void){
 uint8_t iface[]={9,4,0,0,3,0xe0,1,1,0};assert(hci_match_interface(iface,9));iface[5]=2;assert(!hci_match_interface(iface,9));iface[5]=0xe0;iface[2]=1;assert(!hci_match_interface(iface,9));assert(!hci_match_interface(NULL,9));
 HciEndpoints ep={0};uint8_t e[]={7,5,0x81,3,16,0,1};assert(!hci_add_endpoint(&ep,e,7));assert(hci_add_endpoint(&ep,e,7)<0);e[2]=0x82;e[3]=2;e[4]=64;assert(!hci_add_endpoint(&ep,e,7));e[2]=2;assert(!hci_add_endpoint(&ep,e,7));assert(hci_endpoints_complete(&ep));e[2]=0;assert(hci_add_endpoint(&ep,e,7)<0);
 uint8_t out[HCI_MAX_ACL],event[]={14,3,1,2,3,15,0};
 for(unsigned split=0;split<=5;split++){HciStream s={0};assert(!hci_stream_feed(&s,event,split));if(split<5)assert(!hci_stream_take(&s,0,out,sizeof(out)));assert(!hci_stream_feed(&s,event+split,sizeof(event)-split));assert(hci_stream_take(&s,0,out,4)==HCI_ERR_ARGUMENT);assert(hci_stream_take(&s,0,out,sizeof(out))==5);assert(!memcmp(out,event,5));assert(hci_stream_take(&s,0,out,sizeof(out))==2);assert(!s.used);}
 uint8_t acl[HCI_MAX_ACL]={1,0,0,4};assert(hci_valid_acl(acl,sizeof(acl)));
 for(unsigned split=0;split<=sizeof(acl);split++){HciStream s={0};assert(!hci_stream_feed(&s,acl,split));if(split<sizeof(acl))assert(!hci_stream_take(&s,1,out,sizeof(out)));assert(!hci_stream_feed(&s,acl+split,sizeof(acl)-split));assert(hci_stream_take(&s,1,out,sizeof(out))==HCI_MAX_ACL);}
 HciStream s={0};uint8_t bad[]={1,0,255,255};assert(!hci_stream_feed(&s,bad,4));assert(hci_stream_take(&s,1,out,sizeof(out))==HCI_ERR_PROTOCOL&&!s.used);assert(hci_stream_feed(&s,acl,sizeof(s.data)+1)==HCI_ERR_PROTOCOL);
 puts("core: descriptor rejection, endpoints, all event/maximum-ACL split boundaries, coalescing, capacity retention and malformed/overflow lengths passed");return 0;
}
